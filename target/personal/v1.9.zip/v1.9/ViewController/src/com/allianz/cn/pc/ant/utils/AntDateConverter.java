package com.allianz.cn.pc.ant.utils;


import com.allianz.cn.pc.utils.Beans;

import com.thoughtworks.xstream.converters.basic.DateConverter;

import java.sql.Timestamp;

import java.util.Date;
import java.util.TimeZone;


public class AntDateConverter extends DateConverter {
    
    public final static String default_format = "yyyyMMddHHmmss";
    
    public AntDateConverter() { 
            super(default_format, new String[] { default_format },TimeZone.getTimeZone("GMT+8"));
        }
    
    
    public AntDateConverter(String dateFormat) {
    
          super(dateFormat, new String[] { dateFormat },TimeZone.getTimeZone("GMT+8"));
      }
    
    public java.lang.Object fromString(java.lang.String p1) { 
            if(Beans.isNotEmpty(p1) && !"false".equalsIgnoreCase(p1))
                return super.fromString(p1);
            else
                return null;
        }

       public java.lang.String toString(java.lang.Object p1) { 
           
            if(p1 != null)
               return super.toString(p1);
            else
                return null;
           }
       
       public boolean canConvert(Class clazz){
            return (clazz.equals(Date.class) || clazz.equals(Timestamp.class));
       }
}

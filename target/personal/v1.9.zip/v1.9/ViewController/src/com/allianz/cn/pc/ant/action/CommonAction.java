package com.allianz.cn.pc.ant.action;


import com.allianz.cn.pc.ant.dto.AntTransDto;
import com.allianz.cn.pc.ant.exceptions.AntException;
import com.allianz.cn.pc.ant.services.AntService;
import com.allianz.cn.pc.ant.services.impl.AntJDBCServiceImpl;
import com.allianz.cn.pc.ant.xmlbean.ant.CommonResponse;

import org.apache.log4j.Logger;

import org.dom4j.Element;


public abstract class CommonAction {

    private static Logger log = Logger.getLogger(CommonAction.class);
    protected AntService service = AntJDBCServiceImpl.getNewInstance();
    
    public CommonResponse doProcess(Element node) throws AntException{
        return null;    
    } 
    
    public static boolean validateRequestId(String reqId) throws AntException {
        try {
            return AntJDBCServiceImpl.getInstance().isDuplicateRequestId(reqId);
        } catch (Exception e) {
            throw new AntException("1000",e.toString());
        }
    }
    
    public static void saveTrans(AntTransDto dto) throws Exception {
        AntJDBCServiceImpl.getInstance().saveTrans(dto);
    }
    
    public static void updateTrans(AntTransDto dto) throws Exception {
        AntJDBCServiceImpl.getInstance().updateTrans(dto);
    }
}

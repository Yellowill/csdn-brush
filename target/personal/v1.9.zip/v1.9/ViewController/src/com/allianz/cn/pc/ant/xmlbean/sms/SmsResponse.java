package com.allianz.cn.pc.ant.xmlbean.sms;



import com.thoughtworks.xstream.annotations.XStreamAlias;
import java.io.Serializable;


@XStreamAlias("Response")
public class SmsResponse implements Serializable{
   
    @XStreamAlias("Result")
    private String result;
    
    @XStreamAlias("Message")
    private String message;

    public void setResult(String result) {
        this.result = result;
    }

    public String getResult() {
        return result;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }
}

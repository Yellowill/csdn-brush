package com.allianz.cn.pc.ant.utils;

import com.allianz.cn.pc.ant.action.UnderWriteAction;

import java.lang.reflect.Field;

import org.apache.log4j.Logger;

public class AntUtil {
    static Logger logger = Logger.getLogger(AntUtil.class);
    
    public AntUtil() {
        super();
    }
    
    
    /**
     * 打印第一层的属性，如果属性为对象，则不能递归
     */
    public static String toString(Object obj, Class<?> clazz) {  
      if(obj == null){  
        return "";  
      }  
      
      Field[] fields = clazz.getDeclaredFields();// 根据Class对象获得属性 私有的也可以获得  
      String s = "";  
      try {  
        for (Field f : fields) {  
          f.setAccessible(true); // 设置些属性是可以访问的  
          Object val = f.get(obj); // 得到此属性的值  
          String name = f.getName(); // 得到此属性的名称  
          s += name + ":" + val + ",";  
        }  
      } catch (IllegalAccessException e) {  
        logger.info("获取bean的值出错！",e);  
      }  
      return s;  
    }  
}

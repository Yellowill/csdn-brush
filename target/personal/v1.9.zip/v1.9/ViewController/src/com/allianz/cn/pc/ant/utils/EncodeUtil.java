package com.allianz.cn.pc.ant.utils;


import java.io.UnsupportedEncodingException;

import java.security.Key;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.security.spec.AlgorithmParameterSpec;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;


public class EncodeUtil {
    
    /**将二进制转换成16进制
     * @param buf
     * @return
     */
    public static String byte2hex(byte[] buf) {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < buf.length; i++) {
            String hex = Integer.toHexString(buf[i] & 0xFF);
            if (hex.length() == 1) {
                hex = '0' + hex;
            }
            sb.append(hex.toUpperCase());
        }
        return sb.toString();
    }

    /**将16进制转换为二进制
     * @param hexStr
     * @return
     */
    public static byte[] hex2byte(String hexStr) {
        if (hexStr.length() < 1)
            return null;
        byte[] result = new byte[hexStr.length() / 2];
        for (int i = 0; i < hexStr.length() / 2; i++) {
            int high = Integer.parseInt(hexStr.substring(i * 2, i * 2 + 1), 16);
            int low = Integer.parseInt(hexStr.substring(i * 2 + 1, i * 2 + 2), 16);
            result[i] = (byte)(high * 16 + low);
        }
        return result;
    }

    //------------------------------------------DES 加密 begin-------------------------------------------

    public static final String ALGORITHM_DES = "DES/CBC/PKCS5Padding";

    /**
     * DES算法，加密
     *
     * @param data 待加密字符串
     * @param key  加密私钥，长度不能够小于8位
     * @return 加密后的字节数组，一般结合Base64编码使用
     * @throws InvalidAlgorithmParameterException
     * @throws Exception
     */
    public static String desEncrypt(String data, String key) {
        key=key+"12345678";//key的长度不能够小于8位字节
        if (data == null)
            return null;
        try {
            DESKeySpec dks = new DESKeySpec(key.getBytes());
            SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("DES");
            Key secretKey = keyFactory.generateSecret(dks);
            Cipher cipher = Cipher.getInstance(ALGORITHM_DES);
            IvParameterSpec iv = new IvParameterSpec("12345678".getBytes());
            AlgorithmParameterSpec paramSpec = iv;
            cipher.init(Cipher.ENCRYPT_MODE, secretKey, paramSpec);
            byte[] bytes = cipher.doFinal(data.getBytes());
            return byte2hex(bytes);
        } catch (Exception e) {
            e.printStackTrace();
            return data;
        }
    }

    /**
     * DES算法，解密
     *
     * @param data 待解密字符串
     * @param key  解密私钥，长度不能够小于8位
     * @return 解密后的字节数组
     * @throws Exception 异常
     */
    public static String desDecrypt(String data, String key) {
        key=key+"12345678";//key的长度不能够小于8位字节
        if (data == null)
            return null;
        try {
            DESKeySpec dks = new DESKeySpec(key.getBytes());
            SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("DES");
            //key的长度不能够小于8位字节
            Key secretKey = keyFactory.generateSecret(dks);
            Cipher cipher = Cipher.getInstance(ALGORITHM_DES);
            IvParameterSpec iv = new IvParameterSpec("12345678".getBytes());
            AlgorithmParameterSpec paramSpec = iv;
            cipher.init(Cipher.DECRYPT_MODE, secretKey, paramSpec);
            return new String(cipher.doFinal(hex2byte(new String(data.getBytes()))));
        } catch (Exception e) {
            e.printStackTrace();
            return data;
        }
    }

    //------------------------------------------DES 加密 end-------------------------------------------

    //------------------------------------------AES 加密 begin-------------------------------------------
    private static final String KEY_ALGORITHM = "AES";
    private static final String CHARSET = "utf-8";

    /**
     * 加密
     *
     * @param content 需要加密的内容
     * @param password  加密密码
     * @return
     */
    public static String aesEncrypt(String content, String password) {
        String result = null;
        try {
            KeyGenerator kgen = KeyGenerator.getInstance(KEY_ALGORITHM);
            kgen.init(128, new SecureRandom(password.getBytes()));
            SecretKey secretKey = kgen.generateKey();
            byte[] enCodeFormat = secretKey.getEncoded();
            SecretKeySpec key = new SecretKeySpec(enCodeFormat, KEY_ALGORITHM);
            Cipher cipher = Cipher.getInstance(KEY_ALGORITHM); // 创建密码器
            byte[] byteContent = content.getBytes(CHARSET);
            cipher.init(Cipher.ENCRYPT_MODE, key); // 初始化
            byte[] bytes = cipher.doFinal(byteContent);
            result = byte2hex(bytes);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    /**解密
     * @param content  待解密内容
     * @param password 解密密钥
     * @return
     */
    private static String aesDecrypt(String content, String password) {
        String result = null;
        byte[] contentByte = hex2byte(content);
        try {
            KeyGenerator kgen = KeyGenerator.getInstance(KEY_ALGORITHM);
            kgen.init(128, new SecureRandom(password.getBytes()));
            SecretKey secretKey = kgen.generateKey();
            byte[] enCodeFormat = secretKey.getEncoded();
            SecretKeySpec key = new SecretKeySpec(enCodeFormat, KEY_ALGORITHM);
            Cipher cipher = Cipher.getInstance(KEY_ALGORITHM); // 创建密码器
            cipher.init(Cipher.DECRYPT_MODE, key); // 初始化
            byte[] bytes = cipher.doFinal(contentByte);
            result = new String(bytes); // 加密
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }


    //------------------------------------------AES 加密 end-------------------------------------------

    //------------------------------------------MD5 加密 begin-------------------------------------------

    /**
     * @param plainText  明文
     * @return 32位密文
     */
    public static String md5_32EncString(String plainText) {
        String result = null;
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(plainText.getBytes("UTF-8"));
            byte b[] = md.digest();
            int i;
            StringBuffer buf = new StringBuffer("");
            for (int offset = 0; offset < b.length; offset++) {
                i = b[offset];
                if (i < 0)
                    i += 256;
                if (i < 16)
                    buf.append("0");
                buf.append(Integer.toHexString(i));
            }
            result = buf.toString();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }
    //------------------------------------------MD5 加密 end-------------------------------------------

    //------------------------------------------BASE64 加密 begin-------------------------------------------
    // 加密

    public static String base64Encode(String str) {
        byte[] b = null;
        String s = null;
        try {
            b = str.getBytes("utf-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        if (b != null) {
            s = new BASE64Encoder().encode(b);
        }
        return s;
    }

    // 解密

    public static String base64Decode(String s) {
        byte[] b = null;
        String result = null;
        if (s != null) {
            BASE64Decoder decoder = new BASE64Decoder();
            try {
                b = decoder.decodeBuffer(s);
                result = new String(b, "utf-8");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return result;
    }

    //------------------------------------------BASE64 加密 end-------------------------------------------

    public static void main(String[] args) throws Exception {
        String enCode1 = EncodeUtil.desEncrypt("crm201604", "Taobao");
        System.out.println(enCode1);
        String deCode1 = EncodeUtil.desDecrypt(enCode1, "Taobao");
        System.out.println(deCode1);

        //        String enCode = EncodeUtil.aesEncrypt("crm201604", "TaobaoAL1");
        //        System.out.println(enCode);
        //        String deCode = EncodeUtil.aesDecrypt(enCode,"TaobaoAL1");
        //        System.out.println(deCode);

        //        System.out.println(base64Encode("&hK牴抏莾軕H?"));
        //        System.out.println(base64Decode("JmhL54m0HeaKj+iOvhQQ6LuVSD8="));
        //        System.out.println("测试".getBytes());
        //        System.out.println(new String("测试".getBytes()));
    }


}

package com.allianz.cn.pc.ant.test;

import com.allianz.cn.pc.ant.xmlbean.ant.CommonHeader;
import com.allianz.cn.pc.ant.xmlbean.ant.policyconfirm.request.PolicyConfirmRequest;
import com.allianz.cn.pc.utils.XmlUtil;


public class Test {
    public static void main(String[] args) {
        String xml=" <request> \n" + 
        "    <!--  报文头，系统参数  -->  \n" + 
        "    <head> \n" + 
        "      <!--  版本号  -->  \n" + 
        "      <version>3.0</version>  \n" + 
        "      <!--  接口代码  -->  \n" + 
        "      <function>ant.bxcloud.core.issue</function>  \n" + 
        "      <!--  报文发送时间 格式：yyyyMMddHHmmss  -->  \n" + 
        "      <transTime>20141230112716</transTime>  \n" + 
        "      <!--  请求发起系统所在时区 可选  -->  \n" + 
        "      <transTimeZone>UTC+8</transTimeZone>  \n" + 
        "      <!--  唯一编码，由发起方生成，应答方原样返回  -->  \n" + 
        "      <reqMsgId>cff6105b-081b-466e-aee8-7aac06f9cfb5</reqMsgId>  \n" + 
        "      <!--  数据格式 xml/json  -->  \n" + 
        "      <format>xml</format>  \n" + 
        "      <!--  签名类型 RSA  -->  \n" + 
        "      <signType>RSA</signType>  \n" + 
        "      <!--  保险公司同步返回还是异步返回 默认同步返回 0：同步；1：异步  -->  \n" + 
        "      <asyn>0</asyn>  \n" + 
        "      <!--  合作伙伴ID  -->  \n" + 
        "      <cid/> \n" + 
        "    </head>  \n" + 
        "    <!--  报文体，业务参数  -->  \n" + 
        "    <body> \n" + 
        "      <!--  订单基本信息  -->  \n" + 
        "      <policy>\n" + 
        "                <!--  保险订单号  -->\n" + 
        "                <policyNo>10000</policyNo>\n" + 
        "                <!--  产品编号  -->\n" + 
        "                <prodNo>CIINFAP2</prodNo>\n" + 
        "                <!--  机构产品编号  -->\n" + 
        "                <outProdNo>CIINFAP2</outProdNo>\n" + 
        "                <!--  总括订单号  -->\n" + 
        "                <summaryPolicyNo/>\n" + 
        "                <!--  订单类型 0：总括，1：子保单，2：单一保单  -->\n" + 
        "                <policyType/>\n" + 
        "                <!--  保费  -->\n" + 
        "                <premium>10000</premium>\n" + 
        "                <!--  实际保费  -->\n" + 
        "                <actualPremium>7000</actualPremium>\n" + 
        "                <!--  保额  -->\n" + 
        "                <sumInsured>100000000</sumInsured>\n" + 
        "                <!--  投保时间  -->\n" + 
        "                <insuredTime>20160505000001</insuredTime>\n" + 
        "                <!--  投保时间  -->\n" + 
        "                <issueTime>20160505000001</issueTime>\n" + 
        "                <!--  保险起期  -->\n" + 
        "                <effectStartTime>20160505000001</effectStartTime>\n" + 
        "                <!--  保险止期  -->\n" + 
        "                <effectEndTime>20160506000001</effectEndTime>\n" + 
        "                <!--  投保份数  -->\n" + 
        "                <applyNum>1</applyNum>\n" + 
        "                <extendInfos>\n" + 
        "                    <extendInfo key=\"xxx\" value=\"yyy\"/>\n" + 
        "                </extendInfos>\n" + 
        "            </policy>  \n" + 
        "      <!--  账单信息，可能存在多条  -->  \n" + 
        "      <bills> \n" + 
        "        <bill> \n" + 
        "          <!--  机构资金账户信息  -->  \n" + 
        "          <!--  账户类型 1：支付宝账户；2： 银行卡  -->  \n" + 
        "          <merchantAccountType>1</merchantAccountType>  \n" + 
        "          <!--  账户Id  -->  \n" + 
        "          <merchantAccountId/>  \n" + 
        "          <!--  对方资金账户信息  -->  \n" + 
        "          <!--  账户类型 1：支付宝账户；2： 银行卡  -->  \n" + 
        "          <otherAccountType>1</otherAccountType>  \n" + 
        "          <!--  账户Id  -->  \n" + 
        "          <otherAccountId/>  \n" + 
        "          <!--  发生时间  -->  \n" + 
        "          <payTime>20160505000001</payTime>  \n" + 
        "          <!--  发生金额  -->  \n" + 
        "          <fee>7000</fee>  \n" + 
        "          <!--  交易流水号  -->  \n" + 
        "          <payFlowId/> \n" + 
        "        </bill> \n" + 
        "      </bills>  \n" + 
        "      <!--  可选 投保单信息  -->  \n" + 
        "      <proposal> \n" + 
        "        <!--  核保时，保险公司返回的投保单号  -->  \n" + 
        "        <proposalNo/> \n" + 
        "      </proposal>  \n" + 
        "      <insObject> \n" + 
        "        <type>99</type>  \n" + 
        "        <extendInfos> \n" + 
        "          <extendInfo key=\"xxx\" value=\"yyy\" /> \n" + 
        "        </extendInfos> \n" + 
        "      </insObject>  \n" + 
        "      <!--  干系人信息  -->  \n" + 
        "      <!--  投保人  -->  \n" + 
        "     <holder>\n" + 
        "                <!--  编号  -->\n" + 
        "                <personNo/>\n" + 
        "                <!--  渠道账户类型  -->\n" + 
        "                <accountType/>\n" + 
        "                <!--  渠道账户ID  -->\n" + 
        "                <accountNo/>\n" + 
        "                <!--  渠道账户名称  -->\n" + 
        "                <accountName>coffee</accountName>\n" + 
        "                <!--  证件类型  -->\n" + 
        "                <certType>1</certType>\n" + 
        "                <!--  证件号  -->\n" + 
        "                <certNo>123</certNo>\n" + 
        "                <!--  证件姓名 , 如果是公司则是公司名称  -->\n" + 
        "                <certName>coffee</certName>\n" + 
        "                <!--  扩展信息  -->\n" + 
        "                <extendInfos>\n" + 
        "                    <!--  投保人电话  -->\n" + 
        "                    <extendInfo key=\"birthday\" value=\"19980101\"/>\n" + 
        "                </extendInfos>\n" + 
        "            </holder>  \n" + 
        "      <!--  被保人 单被保人  -->  \n" + 
        "       <insureds>\n" + 
        "                <insured>\n" + 
        "                    <!--  是否同投保人 如果是同投保人下面信息就不传 1：同人；0：不同人 -->\n" + 
        "                    <sameWithHolder>1</sameWithHolder>\n" + 
        "                    <!--  编号  -->\n" + 
        "                    <personNo/>\n" + 
        "                    <!--  渠道账户类型  -->\n" + 
        "                    <accountType/>\n" + 
        "                    <!--  渠道账户ID  -->\n" + 
        "                    <accountNo/>\n" + 
        "                    <!--  渠道账户名称  -->\n" + 
        "                    <accountName/>\n" + 
        "                    <!--  证件类型  -->\n" + 
        "                    <certType/>\n" + 
        "                    <!--  证件号  -->\n" + 
        "                    <certNo>123</certNo>\n" + 
        "                    <!--  证件姓名 , 如果是公司则是公司名称  -->\n" + 
        "                    <certName>coffee</certName>\n" + 
        "                    <!--  与投保人关系  -->\n" + 
        "                    <relationWithHolder/>\n" + 
        "                    <!--  扩展信息  -->\n" + 
        "                    <extendInfos>\n" + 
        "                        <!--  被保人电话  -->\n" + 
        "                        <extendInfo key=\"phone\" value=\"15920135190\"/>\n" + 
        "                        <extendInfo key=\"birthday\" value=\"20000101\"/>\n" + 
        "                    </extendInfos>\n" + 
        "                </insured>\n" + 
        "            </insureds> \n" + 
        "    </body> \n" + 
        "  </request>";
        try {
            PolicyConfirmRequest obj = XmlUtil.fromXml(PolicyConfirmRequest.class, xml);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

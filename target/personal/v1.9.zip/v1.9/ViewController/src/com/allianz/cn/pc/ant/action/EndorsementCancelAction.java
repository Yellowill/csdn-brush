package com.allianz.cn.pc.ant.action;

import com.allianz.cn.pc.ant.Const;
import com.allianz.cn.pc.ant.Const.AccountType;
import com.allianz.cn.pc.ant.dto.BillDto;
import com.allianz.cn.pc.ant.dto.OrderDto;
import com.allianz.cn.pc.ant.exceptions.AntException;
import com.allianz.cn.pc.ant.utils.DateUtil;
import com.allianz.cn.pc.ant.utils.MailUtil;
import com.allianz.cn.pc.ant.xmlbean.ant.CommonResponse;
import com.allianz.cn.pc.ant.xmlbean.ant.CommonResponseBody;
import com.allianz.cn.pc.ant.xmlbean.ant.policyconfirm.request.InsBillDTO;
import com.allianz.cn.pc.ant.xmlbean.ant.policyconfirm.request.PolicyEndorsementRequest;
import com.allianz.cn.pc.ant.xmlbean.ant.policyconfirm.request.PolicyEndorsementRequestBody;

import com.allianz.cn.pc.utils.Beans;

import com.allianz.cn.pc.utils.XmlUtil;

import com.allianz.oti.common.EtravelConst;
import com.allianz.oti.model.dto.commonsearch.endorsement.EndorsementInfo;

import com.allianz.oti.model.thirdparty.vo.ResponseBigObject;

import java.math.BigDecimal;

import java.math.RoundingMode;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import java.util.Map;

import org.apache.log4j.Logger;

import org.dom4j.Element;

public class EndorsementCancelAction extends CommonAction{
    private static Logger log = Logger.getLogger(EndorsementCancelAction.class);
    private static Map<String,Object> emailMap = new HashMap<String,Object>();
    
    public CommonResponse doProcess(Element node) throws AntException{
        log.debug("start PolicyEndorsementCancel doProcess !!!");
        PolicyEndorsementRequest request = XmlUtil.fromXml(PolicyEndorsementRequest.class, node.asXML());
        //获取返回报文体
        CommonResponse rep = new CommonResponse();
        PolicyEndorsementRequestBody requestBody = request.getBody();
        EndorsementInfo info = new EndorsementInfo();
        try {
            //退保要确认保单存在且生效70的保单
            String outPolicyRef = requestBody.getPolicy().getOutPolicyNo();//报文中外部保单号--理论上为安联保单号
            OrderDto oldOrderDto = service.findOrderByOrderNo(requestBody.getPolicy().getOrder_no());
            BigDecimal orderAllPrem = oldOrderDto.getPremium();
            String ordPolicyRef = oldOrderDto.getPolicy_ref();//根据蚂蚁订单关联的安联保单号
            String realPolicyRef = outPolicyRef;
            if(Beans.isEmpty(outPolicyRef)){
                realPolicyRef = ordPolicyRef;
            } else {
                if(!outPolicyRef.equals(ordPolicyRef)){//两者保单号不同
                    rep.setBody(getFailResult(request.getBody(),"外部保单号与订单对应的保单号存在差异，操作失败！"));
                    log.info(rep.toString());
                    return rep;
                }
            }
            String policyStatus = service.getNewPolicyStatus(realPolicyRef).toString();
            if(!Const.PolicyStatus.InForce.value.equals(policyStatus) 
               && !Const.PolicyStatus.Cancelled.value.equals(policyStatus)){//除70(生效)80(已退)外的其他单均不能退
                //返回错误提示
                rep.setBody(getFailResult(request.getBody(),"核心保单为非生效状态，操作失败！"));
                return rep;
            }
            //取消流程代码Start---
            OrderDto cancleOrderDto = null;
            String cancleOrderNo  = requestBody.getPolicy().getOrder_no();//退保单号  Const.CANCLE_FLAG
            boolean isExitFlag = false;
            try {
                cancleOrderDto = service.findOrderByOrderNo(cancleOrderNo + Const.CANCLE_FLAG);//查询退保记录
                if(Beans.isNotEmpty(cancleOrderDto.getOrder_no())){
                    isExitFlag = true;//是否存在
                    //状态校验
                    if(Const.AntOrderStatus.CancelFail.value != cancleOrderDto.getStatus()){//成功或者进行中均直接返回结果
                        log.info("endorse-cancel retry, orderNo="+cancleOrderDto.getOrder_no());
                        finishResponse(rep,cancleOrderDto,requestBody);
                        return rep;
                    }
                } else {
                    cancleOrderDto = service.findOrderByOrderNo(cancleOrderNo);//查询退保记录
                    cancleOrderDto.setOrder_no(cancleOrderNo + Const.CANCLE_FLAG);
                }
            } catch (Exception e) {
                if(e instanceof AntException) throw (AntException)e;
                log.error("findOrder order_no:" + cancleOrderNo + Const.CANCLE_FLAG);
                log.error("findOrder error "+e);
                throw new AntException("1000",e.toString());
            }
            //标识--保费校验
            BigDecimal realFee = new BigDecimal(requestBody.getEndorseFee()).divide(new BigDecimal(100), 2, RoundingMode.HALF_UP);
            if(orderAllPrem.compareTo(realFee) == -1){//退保保费一定要小于保单全保费否则返回错误
                rep.setBody(getFailResult(request.getBody(),"退保金额大于原保单保费，操作不通过！"));
                return rep;
            }
            String isCheckFee = service.getConfigValueByKey(Const.ANT_APPNAME,"ant.isCheck.fee");//获取标识，判断是否进行保费比较
            Date startDate = service.getPolicyStartDate(realPolicyRef);//起保时间
            Date endDate = service.getPolicyEndDate(realPolicyRef);//终保日期
            Date endorseCancelDate = requestBody.getEndorseTime();
            if(startDate.getTime() >= endorseCancelDate.getTime()){//如果生效前退保
                endorseCancelDate = startDate;
            }
            if(endorseCancelDate.getTime() >= endDate.getTime()){//如果退保时间在终保时间之后，默认终保日期作为退保日期
                endorseCancelDate = endDate;
            }
            if(Const.TRUE.equals(isCheckFee)){
                //调用后台先计算当前单的退单保费
                BigDecimal centerFee = service.getCancelFee(cancleOrderNo,endorseCancelDate);//安联保费单位（元），支付宝（分）
                if(Beans.isEmpty(centerFee)){
                    rep.setBody(getFailResult(request.getBody(),"保费计算异常，操作失败！"));
                    return rep;
                }
                //若核心保费不存在需要做异常处理----
                if(centerFee.compareTo(realFee) != 0){//配置了标识，退保金额和核心保费不等
                    //返回错误提示
                    rep.setBody(getFailResult(request.getBody(),"退保金额与核心系统存在差异，操作失败！"));                
                    return rep;
                }
            }
            cancleOrderDto.setStatus(Const.AntOrderStatus.WaitCancel.value);//异常失败或者第一次退保，入值为wait
            //数据处理 cancleOrderDto---
            //转换账单
            List<BillDto> billDtoList = new ArrayList<BillDto>();
            String bankAccount = null;
            for(InsBillDTO bill:requestBody.getBillList()){
                bankAccount = bill.getInAlipayAccount();
                BillDto billDto = new BillDto();
                Beans.copy(billDto, bill);
                billDto.setMerchantaccounttype(AccountType.alipay.value);//默认暂时给1
                billDto.setOtheraccounttype(AccountType.alipay.value);
                billDto.setPaytime(bill.getPayTime());
                billDto.setOrder_no(cancleOrderDto.getOrder_no());
                billDto.setMerchantaccountid(bill.getOutAlipayAccount()); //此两个ID对应关系待最后确认bill.getInAlipayAccount()
                billDto.setOtheraccountid(bill.getInAlipayAccount());
                billDto.setPayflowid(bill.getPayFlowId());
                billDtoList.add(billDto);
            }
            //相关校验
            try {
                log.debug("保存账单信息--------------");
                for(BillDto billDto:billDtoList){
                    if(Beans.isNotEmpty(service.findBill(billDto.getOrder_no(), billDto.getPayflowid()).getOrder_no())){
                        service.updateBill(billDto);
                    } else {
                        service.saveBill(billDto);
                    }
                }
                log.debug("保存订单信息--------------");
                if(isExitFlag){//查询结果存在，作更新
                    service.updateOrder(cancleOrderDto); //update
                } else {//初次退保，
                    service.saveOrderForCancel(cancleOrderDto);
                }
                
                String user = service.getConfigValueByKey(Const.ANT_APPNAME,"endorse.user");//获取user
                Integer contractId = service.getContractIdByPolicyRef(realPolicyRef);
                info.setContractId(contractId);
                info.setEndorCode(EtravelConst.EndorsementType.cancle.value);
                info.setEffectiveDate(new java.sql.Timestamp(startDate.getTime()));//入值起保时间
                info.setBankAccount(bankAccount);
                info.setBankName(null);
                info.setReason(requestBody.getEndorseReasonDesc());
                info.setUserName(user);
                info.setCancelDate(new java.sql.Timestamp(endorseCancelDate.getTime()));
                if(!Const.TRUE.equals(isCheckFee)){
                    //lopProdType 用其保留原保费
                    info.setLopProdType(realFee.toString());
                }
                
                Integer install_No = service.getInstallmentNo(contractId.toString());
                //核心退保方法
                Object p_result = service.endorsementCancellation(info);
                if (Beans.isNotEmpty(p_result) && EtravelConst.ErrorCode.success.value.equals(p_result)) {
                    final String refundAccount = service.getConfigValueByKey(Const.ANT_APPNAME,"refund.accout");//获取refund.accout
                    final List<ResponseBigObject> installList = service.getinstallList(contractId.toString(), install_No);
                    //do settlement
                    new Thread() {
                        public void run() {
                            try {
                                for (ResponseBigObject obj : installList) {
                                    service.settlementForPolicyCancel(Integer.parseInt(obj.getContractId()),
                                                                      Integer.parseInt(obj.getVersionNo()),
                                                                      obj.getAmount(),
                                                                      obj.getPremium(), refundAccount, "PREM");
                                }
                            } catch (Exception e) {
                                log.error("settlementForPolicyCancel fail : ", e);
                            } 
                        }
                    }.start();
                    cancleOrderDto.setStatus(Const.AntOrderStatus.CancelSuccess.value);
                    service.updateOrder(cancleOrderDto);
                } else {
                    //更新状态cancleOrderDto
                    cancleOrderDto.setStatus(Const.AntOrderStatus.CancelFail.value);
                    service.updateOrder(cancleOrderDto);
                    rep.setBody(getFailResult(request.getBody(),"退保操作失败！"));
                    return rep;
                }
            } catch (Exception e) {
                cancleOrderDto.setStatus(Const.AntOrderStatus.CancelFail.value);//异常也算失败
                service.updateOrder(cancleOrderDto);
                service.endTransaction();
                if(e instanceof AntException) throw (AntException)e;
                e.printStackTrace();
                log.error("saveRequest error "+e);
                throw new AntException("1000",e.toString());
            }
            finishResponse(rep,cancleOrderDto,requestBody);
            long startTime = System.currentTimeMillis();
            log.info("response cost "+(System.currentTimeMillis()-startTime));
            return rep;
        } catch (Exception e) {
            e.printStackTrace();
        } 
    return rep;
}
    
    //返回结果组装
    private void finishResponse(CommonResponse rep,OrderDto orderDto,PolicyEndorsementRequestBody requestBody) {
        CommonResponseBody body = new CommonResponseBody();
        if(Const.AntOrderStatus.CancelSuccess.value == orderDto.getStatus()){//success
            body.setInstEndorsementNo(requestBody.getEndorseNo());
            body.setResultCode(Const.ResponseStatus.successCode.value);
            body.setResultDesc("退保成功！");
            body.setResultStatus(Const.ResponseStatus.success.value);
            body.setInstSerialNo(requestBody.getInstSerialNo());
            body.setInstBizInfo(new Object());//返回相关属性
            rep.setBody(body);
        } else {
            body.setInstEndorsementNo(requestBody.getEndorseNo());
            body.setResultCode(Const.ResponseStatus.failCode.value);
            body.setResultDesc("受理中！");
            body.setResultStatus(Const.ResponseStatus.fail.value);
            body.setInstSerialNo(requestBody.getInstSerialNo());
            body.setInstBizInfo(new Object());//返回相关属性
            rep.setBody(body);
        }
    }
    
    public CommonResponseBody getFailResult(PolicyEndorsementRequestBody requestBody, String errorStr){
        String policyRef = requestBody.getPolicy().getOutPolicyNo();
        if(checkEmailIsSend(policyRef)){//判断是否发送
            if(sendEmail(getEmailContent(policyRef,errorStr))){//成功则将计划put
                emailMap.put(policyRef,policyRef);
            }
        }
        CommonResponseBody body = new CommonResponseBody();
        body.setInstEndorsementNo(requestBody.getEndorseNo());
        body.setResultCode(Const.ResponseStatus.failCode.value);
        body.setResultDesc(errorStr);
        body.setResultStatus(Const.ResponseStatus.fail.value);
        body.setInstSerialNo(requestBody.getInstSerialNo());
        body.setInstBizInfo(new Object());//返回相关属性
        return body;
    }
    
    /**
     *邮件发送
     * @param emailContent
     * @return
     */
    private boolean sendEmail(String emailContent){
        MailUtil mailUtil = MailUtil.getInstance("ePolicy");//Weihuang.extern@allianz.cn
        String mailAddr = service.getConfigValueByKey(Const.ANT_APPNAME,Const.FUNCTION_CODE_ENDORSEMENT+".mail");
        boolean isSuccess = mailUtil.sendHtmlMail(mailAddr, null, "蚂蚁退保邮件提醒", emailContent);
        if(isSuccess){
            log.info("邮件发送成功!" + "Content -" + emailContent);
        } else {
            log.info("邮件发送失败!" + "Content -" + emailContent);
        }
        return isSuccess;
    }
    
    /**
     *判断是否发送邮件-当天一个计划仅发一次
     * @param planCode
     * @return
     */
    private boolean checkEmailIsSend (String policyRef){
        boolean reFlag = false;
        //时间为空或者时间不同天
        if(Beans.isEmpty(emailMap.get("currentDate")) || !DateUtil.sameDate((Date)emailMap.get("currentDate"), new Date())){
            emailMap = new HashMap<String,Object>();
            emailMap.put("currentDate", new Date());
            reFlag = true;
        }
        if(Beans.isEmpty(emailMap.get(policyRef))){//同计划当天只发送一次
             reFlag = true;
        } else{
             reFlag = false;
        }
        return reFlag;
    }
    
    /**
     *邮件内容拼接
     * @param planCode
     * @param cancleOrderDto
     * @param centerFee
     * @return
     */
    private String getEmailContent(String policyRef,String reasonStr) {
          StringBuffer content = new StringBuffer();
          content.append("<br/>");
          content.append("【订单号为：").append(policyRef).append("】退保失败");
          content.append("<br/>");
          content.append("【原因：").append(reasonStr).append("】");
          content.append("<br/>");
          content.append(" 注意：同一保单当天只会通知一次！");
          content.append("<br/>");
          content.append("<br/>");
          content.append("<br/>");
          content.append(" 该邮件为系统通知邮件，无需回复。");
          return content.toString();
      }

}

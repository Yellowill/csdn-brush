package com.allianz.cn.pc.ant.utils;


import com.thoughtworks.xstream.converters.MarshallingContext;
import com.thoughtworks.xstream.converters.UnmarshallingContext;
import com.thoughtworks.xstream.converters.collections.AbstractCollectionConverter;
import com.thoughtworks.xstream.io.ExtendedHierarchicalStreamWriterHelper;
import com.thoughtworks.xstream.io.HierarchicalStreamReader;
import com.thoughtworks.xstream.io.HierarchicalStreamWriter;
import com.thoughtworks.xstream.mapper.Mapper;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;


public class AntMapConverter extends AbstractCollectionConverter {  
  
    /** 
     * @param mapper 
     */  
    public AntMapConverter(Mapper mapper) {  
        super(mapper);  
    }  
  
    public boolean canConvert(Class type) {  
        return type.equals(HashMap.class)  
                || type.equals(Hashtable.class)  
                || type.equals(LinkedHashMap.class)  
                || type.equals(Map.class)
                || type.getName().equals("sun.font.AttributeMap") 
                ;  
    }  
  
    public void marshal(Object source, HierarchicalStreamWriter writer, MarshallingContext context) {  
        Map map = (Map) source;  
        for (Iterator iterator = map.entrySet().iterator(); iterator.hasNext();) {  
            Entry entry = (Entry) iterator.next();  
            ExtendedHierarchicalStreamWriterHelper.startNode(writer, "extendInfo", Entry.class);  
  
            writer.addAttribute("key",  entry.getKey().toString());  
            writer.addAttribute("value", entry.getValue().toString());  
            writer.endNode();  
        }  
    }  
  
    public Object unmarshal(HierarchicalStreamReader reader, UnmarshallingContext context) {  
        Map map = (Map) createCollection(context.getRequiredType());  
        populateMap(reader, context, map);  
        return map;  
    }  
  
    protected void populateMap(HierarchicalStreamReader reader, UnmarshallingContext context, Map map) {  
        while (reader.hasMoreChildren()) {  
            reader.moveDown();  
            Object key = reader.getAttribute("key");  
            Object value = reader.getAttribute("value");  
            map.put(key, value);  
            reader.moveUp();  
        }  
    }  
}  
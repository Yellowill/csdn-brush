package com.allianz.cn.pc.ant.xmlbean.ant.policyconfirm.request;


import com.allianz.cn.pc.ant.utils.AllianzBigDecimalConverter;
import com.allianz.cn.pc.ant.utils.AntDateConverter;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamConverter;

import java.math.BigDecimal;

import java.util.Date;


@XStreamAlias("bill")
public class Bill {
   
    @XStreamAlias("merchantAccountType")
    private Integer merchantAccountType;
    
    @XStreamAlias("merchantAccountId")
    private String merchantAccountId;
    
    @XStreamAlias("otherAccountType")
    private Integer otherAccountType;
    
    @XStreamAlias("otherAccountId")
    private String otherAccountId;
    
    @XStreamConverter(value=AntDateConverter.class)
    @XStreamAlias("payTime")
    private Date payTime;
    
    @XStreamAlias("payFlowId")
    private String payFlowId;
    
    @XStreamConverter(value=AllianzBigDecimalConverter.class)
    @XStreamAlias("fee")
    private BigDecimal fee;


    public void setMerchantAccountType(Integer merchantAccountType) {
        this.merchantAccountType = merchantAccountType;
    }

    public Integer getMerchantAccountType() {
        return merchantAccountType;
    }

    public void setMerchantAccountId(String merchantAccountId) {
        this.merchantAccountId = merchantAccountId;
    }

    public String getMerchantAccountId() {
        return merchantAccountId;
    }

    public void setOtherAccountType(Integer otherAccountType) {
        this.otherAccountType = otherAccountType;
    }

    public Integer getOtherAccountType() {
        return otherAccountType;
    }

    public void setOtherAccountId(String otherAccountId) {
        this.otherAccountId = otherAccountId;
    }

    public String getOtherAccountId() {
        return otherAccountId;
    }

    public void setPayTime(Date payTime) {
        this.payTime = payTime;
    }

    public Date getPayTime() {
        return payTime;
    }

    public void setPayFlowId(String payFlowId) {
        this.payFlowId = payFlowId;
    }

    public String getPayFlowId() {
        return payFlowId;
    }

    public void setFee(BigDecimal fee) {
        this.fee = fee;
    }

    public BigDecimal getFee() {
        return fee;
    }
}

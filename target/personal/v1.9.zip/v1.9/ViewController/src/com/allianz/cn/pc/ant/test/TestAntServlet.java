/**
 * http://127.0.0.1:7101/AntPolicyService/test
 */
package com.allianz.cn.pc.ant.test;


import com.allianz.cn.pc.ant.Const;
import com.allianz.cn.pc.ant.action.CommonAction;
import com.allianz.cn.pc.ant.action.EndorsementCancelAction;
import com.allianz.cn.pc.ant.action.PolicyConfirmAction;
import com.allianz.cn.pc.ant.action.UnderWriteAction;
import com.allianz.cn.pc.ant.dto.AntTransDto;
import com.allianz.cn.pc.ant.utils.BusinessUtil;
import com.allianz.cn.pc.ant.xmlbean.ant.CommonHeader;
import com.allianz.cn.pc.ant.xmlbean.ant.CommonResponse;
import com.allianz.cn.pc.ant.xmlbean.ant.DocumentNode;
import com.allianz.cn.pc.ant.xmlbean.ant.policyconfirm.request.PolicyConfirmRequest;
import com.allianz.cn.pc.utils.Beans;
import com.allianz.cn.pc.utils.XmlUtil;

import java.io.IOException;
import java.io.PrintWriter;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;


public class TestAntServlet extends HttpServlet {
    static Logger log = Logger.getLogger(TestAntServlet.class);
    public final static String UTF8 = "utf-8";
    public final static String GBK = "gbk";
    
    private static Map<String, Class> RequestTypeMap = new HashMap() {
        {
            put(Const.FUNCTION_CODE_UNDERWRITE, PolicyConfirmRequest.class);
            put(Const.FUNCTION_CODE_POLICYCONFIRM, PolicyConfirmRequest.class);
        }
    };
    
    private static Map<String, Class> ActionTypeMap = new HashMap() {
        {
            put(Const.FUNCTION_CODE_UNDERWRITE, UnderWriteAction.class);
            put(Const.FUNCTION_CODE_POLICYCONFIRM, PolicyConfirmAction.class);
            put(Const.FUNCTION_CODE_ENDORSEMENT, EndorsementCancelAction.class);
        }
    };

    public void init(ServletConfig config) throws ServletException {
        super.init(config);
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setCharacterEncoding(GBK);
        PrintWriter out = response.getWriter();
        log.error("Error request type");
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding(UTF8);
        response.setCharacterEncoding(UTF8);
        response.setContentType("application/xml;charset=utf-8");

        PrintWriter out = response.getWriter();
        
        String baseString = IOUtils.toString(request.getInputStream(),UTF8);
        
        String result = new MyAction().test(baseString);
        
        out.print(result);
    }
    
    class MyAction {
        public String test(String baseString) {
            boolean isChangeHeadFlag = false;//承保头部标签为<head>,退保头部标签为<header>
            if(baseString.indexOf("<header>") != -1){//存在<header>的即为退保，做标记并替换
                isChangeHeadFlag = true;
                baseString = baseString.replace("<header>", "<head>");//替换退保的标签使逻辑可以正常
                baseString = baseString.replace("</header>", "</head>");
            }
            long startTime = System.currentTimeMillis();
            DocumentNode document = new DocumentNode();
            CommonResponse rep = new CommonResponse();
            String sinature = null;
            String headXml = null;
            String bodyXml = null;
            CommonHeader head = null;
            AntTransDto transDto = new AntTransDto();
            String orderNo = null;

            try {
                log.debug("request xml is \n" +
                        baseString);
                Document doc = null;
                SAXReader reader = new SAXReader();
                reader.setEncoding(GBK);

                doc = reader.read(IOUtils.toInputStream(baseString), GBK);
                Element root = doc.getRootElement();

                //获取RSA加密串
                Element signatureNode = root.element("signature");
                String signatureStr = null;
                if (null != signatureNode)
                    signatureStr = signatureNode.getText().trim();

                //获取请求报文头和报文体
                Element requestNode = root.element("request");
                if (null != requestNode) {
                    headXml = requestNode.element("head").asXML();
                    bodyXml = requestNode.element("body").asXML();
                }

                head = XmlUtil.fromXml(CommonHeader.class, headXml);
                //获取返回报文头
                rep.setHead(head);

                //校验RSA加密内容
                String requestStr =
                    baseString.substring(baseString.indexOf("<request>"), baseString.indexOf("</request>"));
                requestStr = requestStr.replace("<request>", "");
                if (null != requestStr)
                    log.debug("RSA vilidate pass !");

                //转换报文头
                Beans.copy(transDto, head);
                log.info(requestNode);
                log.info(requestNode.toString());
                log.info(requestNode.element("body").toString());
                log.info(requestNode.element("body").element("policy").toString());
                Element policyNo = requestNode.element("body").element("policy").element("policyNo");
                transDto.setOrder_no(policyNo.getText());
                transDto.setOrder_status(Const.AntOrderStatus.NoRecord.value);
                orderNo = policyNo.getText();

                //获取返回报文体
                CommonAction action = null;
                Class actionClazz = null;
                if (null != requestStr) {
                    actionClazz = ActionTypeMap.get(head.getFunction_code());
                    action = (CommonAction)actionClazz.newInstance();
                    CommonResponse temp = action.doProcess(requestNode);
                    rep.setBody(temp.getBody());
                    log.info("t-1");
                    log.info(rep.toString());
                }
                //更新trans表
                //            updateTrans(transDto, rep.getBody());

            } catch (Exception e) {
                log.error(e.getMessage(),e);
                rep = BusinessUtil.createErrorResponse(head, e);
                //更新trans表
                //            try {
                //                updateTrans(transDto, rep.getBody());
                //            } catch (Exception f) {
                //                f.printStackTrace();
                //                rep = BusinessUtil.createErrorResponse(head, f);
                //            }
            } finally {
                String resXml = XmlUtil.toXml(rep,"utf-8");
                log.debug("###response xml is ### " + resXml);
                rep = BusinessUtil.convertAntError(rep, orderNo);
                resXml = XmlUtil.toXml(rep,"utf-8");
                bodyXml = XmlUtil.toXml(rep.getBody(), "utf-8");
                bodyXml = bodyXml.substring(bodyXml.indexOf("<body>"));
                log.debug("###response body xml is ### " + bodyXml);
                if(isChangeHeadFlag){
                    resXml = resXml.replace("<head>", "<header>");
                    resXml = resXml.replace("</head>", "</header>");
                }
                System.err.println("cost " + (System.currentTimeMillis() - startTime));
                return resXml;
            }
        }
    }

}

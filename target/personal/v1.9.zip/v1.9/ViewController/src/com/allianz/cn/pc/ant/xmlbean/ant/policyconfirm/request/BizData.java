package com.allianz.cn.pc.ant.xmlbean.ant.policyconfirm.request;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("bizData")
public class BizData {
    public BizData() {
        super();
    }
    @XStreamAlias("hesitationType")
    private String hesitationType;

    public void setHesitationType(String hesitationType) {
        this.hesitationType = hesitationType;
    }

    public String getHesitationType() {
        return hesitationType;
    }
}

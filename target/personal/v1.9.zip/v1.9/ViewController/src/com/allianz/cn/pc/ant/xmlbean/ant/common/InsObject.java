package com.allianz.cn.pc.ant.xmlbean.ant.common;


import com.allianz.cn.pc.ant.utils.AntMapConverter;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamConverter;

import java.util.HashMap;
import java.util.Map;

@XStreamAlias("insObject")
public class InsObject {
    
    @XStreamAlias("type")
    private Integer type;

    @XStreamConverter(value=AntMapConverter.class)
    @XStreamAlias("extendInfos")
    private Map<String,String> extendInfos=new HashMap<String,String>();

    public void setType(Integer type) {
        this.type = type;
    }

    public Integer getType() {
        return type;
    }


    public void setExtendInfos(Map<String, String> extendInfos) {
        this.extendInfos = extendInfos;
    }

    public Map<String, String> getExtendInfos() {
        return extendInfos;
    }
}

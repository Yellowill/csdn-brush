package com.allianz.cn.pc.ant.xmlbean.ant;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("response")
public class CommonResponse {
    
    @XStreamAlias("head")
    private CommonHeader head = new CommonHeader();
    
    @XStreamAlias("body")
    private CommonResponseBody body = new CommonResponseBody();

    public void setHead(CommonHeader head) {
        this.head = head;
    }

    public CommonHeader getHead() {
        return head;
    }

    public void setBody(CommonResponseBody body) {
        this.body = body;
    }

    public CommonResponseBody getBody() {
        return body;
    }
}

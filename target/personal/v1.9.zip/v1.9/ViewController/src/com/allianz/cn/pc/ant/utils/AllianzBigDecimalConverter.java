package com.allianz.cn.pc.ant.utils;


import com.allianz.cn.pc.utils.Beans;

import com.thoughtworks.xstream.converters.basic.BigDecimalConverter;

import java.math.BigDecimal;

public class AllianzBigDecimalConverter extends BigDecimalConverter{
    public AllianzBigDecimalConverter() {
        super();
    }
    
    public Object fromString(String p) { 
    
        BigDecimal value = null;
        if(Beans.isNotEmpty(p)){
            BigDecimal v = new BigDecimal(p);
            return v;
        }
        return value;
    }
    
    
    public String toString(BigDecimal p) { 
        if(p == null)
            return "";
        
        return p.setScale(2, BigDecimal.ROUND_HALF_UP).toString();
    }
   
}

package com.allianz.cn.pc.ant.utils;

import java.security.GeneralSecurityException;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;

import org.apache.commons.codec.binary.Base64;


//import org.codehaus.xfire.util.Base64;


/**
 *
 *
 * @author garnett.xx
 * @version $Id: SignatureUtil.java, v 0.1 2016��4��29�� ����11:12:07 garnett.xx Exp $
 */
public class RsaSignatureUtil {

    /** ���� */
    private static final String NEW_LINE = "\n";

    /** �㷨 */
    private static final String ALGORITHM = "SHA256withRSA";

    public static void main(String[] args) {
        String public_key =
            "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQClYD660+13ETVEnuVufIgdggi7f8CnC88idkokWrCVTlYNtCOMtHPcMsaejy+5Ry47bUkPT6NjsnOnKTQ+WY9+BVFtK50S77ITcAuDb8nGs/+4plrkRvGP6akuyUXGzUv7ymQirBHxpzkPigVRPPfdgAN0OxsT0f9luX2K8KZ3sQIDAQAB";
        System.err.println("MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQClYD660+13ETVEnuVufIgdggi7f8CnC88idkokWrCVTlYNtCOMtHPcMsaejy+5Ry47bUkPT6NjsnOnKTQ+WY9+BVFtK50S77ITcAuDb8nGs/+4plrkRvGP6akuyUXGzUv7ymQirBHxpzkPigVRPPfdgAN0OxsT0f9luX2K8KZ3sQIDAQAB");
        String private_key =
        "MIICdQIBADANBgkqhkiG9w0BAQEFAASCAl8wggJbAgEAAoGBAKVgPrrT7XcRNUSe5W58iB2CCLt/wKcLzyJ2SiRasJVOVg20I4y0c9wyxp6PL7lHLjttSQ9Po2Oyc6cpND5Zj34FUW0rnRLvshNwC4Nvycaz/7imWuRG8Y/pqS7JRcbNS/vKZCKsEfGnOQ+KBVE8992AA3Q7GxPR/2W5fYrwpnexAgMBAAECgYBts8SpBoCV5XJijM1BV5arjGDikEJqDWlgQPu51fchdA+dk4upgOMChSRAdleAHnnKrhoy7+9A6VXS44Bmg96s8iXeRk2uaVFHnozD/UV9Vuya8cX1NzpxPVz72z2+4UnR97418p/ZiBtVpmv+u5oAuZY9ijBgvL/GzGJfkuodKQJBAPl36wcTO76rLk5HzlH4MCfCGH4AR8+bsMhcVbCew3jY1pCHx4CSKlo71/XxMNZpCgyXxLVsWPY/V7uv3qwXR2MCQQCptLDEePKsawHScW3aSqRQGFoIwyazDDDjYulG20R8nhbcR0hhZIBwF3tJZtqxqxPTw4xga4wtzHJnCYNMneLbAkA++aa7An/yggQOftH2n1CIuNa1+BworITUD3sSOwHdX9/KXHxgWIWYgcLisyBBAAMpaqadpdxPTW44Uw1DJB1BAkAq2bkYowGDj7FyFboLOHWs07lIJR6MbzOY9sy4W307ih9zl3wrO1lC9Gro6dOmsO/ctK+pWP6YQdtRMRG6MtOpAkAtkAZ6gX1ztW3iTepbZF4PFJVsFe/oUpPTmeV2LoQK1tGOvEsi0lhMDOijkEPkfkqFLIkfA8m5CaOTrUQlkrE8";
        
        String source = "coffee test";
        System.out.println("source="+source);
        
        String signed = sign(source,private_key);
        System.out.println();
        System.out.println("signed="+signed);
                
//        String signed2 = "UjKq1CBKKTIeaQBehQUemoiP77sMvgQPQLlaLVHERQ7G5cZyTqabAD523KUuMHxrBW2w+2Dip6XpzzXsUCkX/uZ5l1VkJZ+zyvs11/S6qsSOwcW+5eopg+LsEdd1djgg7DBe3CTE7eavV4cpAOp6Zl5/OOKuzbrJ6ay6BbOjNgQZQ+XgFkaf9Q22XOPZP+/oTQycv3/JU7pVBvdNh1CYBq0nTr9l0zSF1j1/UT4BZxpWo1M18Zg5YeeLYqALdX0fGn+Bhrxa8Holg5b/wbkyTUghk1fPxRbIDhM40x07OpEQ56Ys2i0X1/WT3ZDiQ0U7uAkFUV0XEVj3J6Rtuwf9lw==";
        String source2 = "coffee test";
        System.out.println();
        System.out.println(verify(source2, signed, public_key));
    }

    /**
     * ��ǩ
     *
     * @param text
     *            ���ǩ�ı�
     * @param privateKey
     *            ��ǩ˽Կ
     * @return
     */
    public static String sign(String text, String privateKey) {
        try {
            byte[] signBytes = sign(new Base64().encode(text.getBytes("utf-8")), new Base64().decode(privateKey), ALGORITHM);
            return new String(new Base64().encode(signBytes)).replace(NEW_LINE, "");
            //return (new Base64()).encodeBuffer(signBytes).replace(NEW_LINE, "");
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     *
     * @param text
     * @param privateKeyData
     * @param algorithm
     * @return
     * @throws GeneralSecurityException
     */
    private static byte[] sign(final byte[] text, final byte[] privateKeyData,
                               final String algorithm) throws GeneralSecurityException {
        PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(privateKeyData);
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        PrivateKey privateKey = keyFactory.generatePrivate(keySpec);
        Signature signatureChecker = Signature.getInstance(algorithm);
        signatureChecker.initSign(privateKey);
        signatureChecker.update(text);
        return signatureChecker.sign();
    }

    /**
     * ��ǩ
     *
     * @param text
     *            ����ǩ�ַ�
     * @param signedText
     *            ��ǩ��
     * @param publicKey
     *            ��ǩ��Կ
     * @return
     */
    public static boolean verify(String text, String signedText, String publicKey) {
        try {
            return verify(new Base64().encode(text.getBytes("utf-8")), new Base64().decode(signedText),
                          new Base64().decode(publicKey), ALGORITHM);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static boolean verify3(String text, String signedText, String publicKey) {
        try {
            return verify(text.getBytes(), new Base64().decode(signedText), new Base64().decode(publicKey), ALGORITHM);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * ��ǩ
     *
     * @param text
     *            ����ǩ�ַ�
     * @param signedText
     *            ��ǩ��
     * @param publicKey
     *            ��ǩ��Կ
     * @return
     */
    public static boolean verify2(String text, String signedText, String publicKey) {
        try {
            return verify(org.apache.commons.codec.binary.Base64.encodeBase64(text.getBytes()),
                          org.apache.commons.codec.binary.Base64.decodeBase64(signedText.getBytes()),
                          org.apache.commons.codec.binary.Base64.decodeBase64(publicKey.getBytes()), ALGORITHM);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     *
     * @param text
     * @param signedText
     * @param publicKeyData
     * @param algorithm
     * @return
     * @throws GeneralSecurityException
     */
    private static boolean verify(final byte[] text, final byte[] signedText, final byte[] publicKeyData,
                                  final String algorithm) throws GeneralSecurityException {
        X509EncodedKeySpec keySpec = new X509EncodedKeySpec(publicKeyData);
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        PublicKey publicKey = keyFactory.generatePublic(keySpec);
        Signature signatureChecker = Signature.getInstance(algorithm);
        signatureChecker.initVerify(publicKey);
        signatureChecker.update(text);
        // System.out.println("signedText is "+signedText.toString());
        return signatureChecker.verify(signedText);
    }

}

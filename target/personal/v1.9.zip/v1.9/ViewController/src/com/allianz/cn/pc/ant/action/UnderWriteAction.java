package com.allianz.cn.pc.ant.action;


import com.allianz.cn.pc.ant.Const;
import com.allianz.cn.pc.ant.Const.RegionCode;
import com.allianz.cn.pc.ant.dto.GroupPlanInfoDto;
import com.allianz.cn.pc.ant.dto.HolderDto;
import com.allianz.cn.pc.ant.dto.InsObjectDto;
import com.allianz.cn.pc.ant.dto.InsuredDto;
import com.allianz.cn.pc.ant.dto.OrderDto;
import com.allianz.cn.pc.ant.dto.PlanInfoDto;
import com.allianz.cn.pc.ant.exceptions.AntException;
import com.allianz.cn.pc.ant.utils.DateUtil;
import com.allianz.cn.pc.ant.utils.IDUtil;
import com.allianz.cn.pc.ant.utils.IDUtil.IDInfo;
import com.allianz.cn.pc.ant.vo.PolicyInfoVo;
import com.allianz.cn.pc.ant.xmlbean.ant.CommonResponse;
import com.allianz.cn.pc.ant.xmlbean.ant.CommonResponseBody;
import com.allianz.cn.pc.ant.xmlbean.ant.common.Insured;
import com.allianz.cn.pc.ant.xmlbean.ant.underwrite.request.UnderWriteRequest;
import com.allianz.cn.pc.utils.Beans;
import com.allianz.cn.pc.utils.XmlUtil;

import com.allianz.oti.common.EtravelConst;

import java.math.BigDecimal;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import java.util.Map;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import org.dom4j.Element;


public class UnderWriteAction extends CommonAction {

    static Logger log = Logger.getLogger(UnderWriteAction.class);

    public CommonResponse doProcess(Element node) throws AntException {
        log.debug("start UnderWrite doProcess !!!");
        CommonResponse rep = new CommonResponse();
        UnderWriteRequest request = XmlUtil.fromXml(UnderWriteRequest.class, node.asXML());
        //重发校验处理
        try {
            OrderDto orderDto = service.findOrder(request.getBody().getPolicy().getOrder_no());
            if (Beans.isNotEmpty(orderDto.getOrder_no())) { //如果是重发的订单，直接查找订单信息即可
                log.info("underWrite retry, orderNo="+orderDto.getOrder_no());
                finishUW(rep,orderDto); //coffee
                return rep;
            }
        } catch (Exception e) {
            if(e instanceof AntException)
                throw (AntException)e;
            log.error("findOrder order_no:"+request.getBody().getPolicy().getOrder_no());
            log.error("findOrder error "+e);
            throw new AntException("1000",e.toString());
        }
        
        //转换请求
        //订单及标的信息
        OrderDto orderDto = new OrderDto();
        Beans.copy(orderDto, request.getBody().getPolicy());
        orderDto.setApplynum(request.getBody().getPolicy().getApplynum());
        orderDto.setExtendInfos(request.getBody().getPolicy().getExtendInfos());
        if(Beans.isNotEmpty(orderDto.getExtendInfos())){
            orderDto.setPost_address(orderDto.getExtendInfos().get(Const.PolicyExtendInfoKey.address.value));
            orderDto.setIs_renewal(orderDto.getExtendInfos().get(Const.PolicyExtendInfoKey.isRenewal.value)); //续保标记
            orderDto.setOld_out_policy_no(orderDto.getExtendInfos().get(Const.PolicyExtendInfoKey.oldOutPolicyNo.value)); //老外部（机构）保单号
        }
        
        InsObjectDto objDto = new InsObjectDto();
        Beans.copy(objDto, request.getBody().getInsObject());
        objDto.setType(request.getBody().getInsObject().getType());
        objDto.setExtendInfos(request.getBody().getInsObject().getExtendInfos());
        if(Beans.isNotEmpty(objDto.getExtendInfos())){
            orderDto.setAddress_code(objDto.getExtendInfos().get(Const.InsObjectExtendInfoKey.addressCode.value));
            orderDto.setEhome_address(objDto.getExtendInfos().get(Const.InsObjectExtendInfoKey.addressDetail.value));
            orderDto.setDestination(objDto.getExtendInfos().get(Const.InsObjectExtendInfoKey.destination.value));
        }
        
        orderDto.setInsObjectDto(objDto);
        //投保人信息
        HolderDto holderDto = new HolderDto();
        Beans.copy(holderDto, request.getBody().getHolder());
        holderDto.setExtendInfos(request.getBody().getHolder().getExtendInfos());
        if(Const.AntCardType.IDCard.value.endsWith(holderDto.getCerttype()))
            holderDto.setBirth_day(DateUtil.getBirthdayFromIDCard(holderDto.getCertno()));
        if(Beans.isEmpty(holderDto.getBirth_day()))
            holderDto.setBirth_day(DateUtil.stringToDate(holderDto.getExtendInfos().get(Const.CustomerExtendInfoKey.birthday.value),Const.ANT_DATE_FORMAT));
        holderDto.setAddress(holderDto.getExtendInfos().get(Const.CustomerExtendInfoKey.address.value));
        holderDto.setSex(Const.genderMap.get(holderDto.getExtendInfos().get(Const.CustomerExtendInfoKey.gender.value)));
        holderDto.setNameEn(holderDto.getExtendInfos().get(Const.CustomerExtendInfoKey.englishName.value));
        holderDto.setPhone(holderDto.getExtendInfos().get(Const.CustomerExtendInfoKey.phone.value));
        holderDto.setEmail(holderDto.getExtendInfos().get(Const.CustomerExtendInfoKey.email.value));
        if(Const.AntCardType.IDCard.value.equals(holderDto.getCerttype()))
            holderDto.setCerttype(Const.CardType.IDCard.value);
        else if(Const.AntCardType.Passport.value.equals(holderDto.getCerttype()))
            holderDto.setCerttype(Const.CardType.Passport.value);
        else 
            holderDto.setCerttype(Const.CardType.Other.value);
        //投保人信息校验
        validateCertno(holderDto.getCertno(),holderDto.getCerttype(),holderDto.getBirth_day());
        
        //被保险人信息
        List<InsuredDto> insuredDtoList = new ArrayList<InsuredDto>();
        for(Insured insured:request.getBody().getInsureds().getInsuredList()){
            InsuredDto insuredDto = new InsuredDto();
            if(Const.TRUE.equals(insured.getSameWithHolder().toString())){
                Beans.copy(insuredDto, holderDto);
                insuredDto.setExtendInfos(holderDto.getExtendInfos());
                insuredDto.setSameWithholder(insured.getSameWithHolder());
                insuredDto.setRelationWithholder(Const.ANT_RELATIONSHIP_SELF);
            }else{
                Beans.copy(insuredDto, insured);
                insuredDto.setExtendInfos(insured.getExtendInfos());
                insuredDto.setSameWithholder(insured.getSameWithHolder());
                insuredDto.setRelationWithholder(insured.getRelationWithHolder());
                if(Const.AntCardType.IDCard.value.endsWith(insuredDto.getCerttype()))
                    insuredDto.setBirth_day(DateUtil.getBirthdayFromIDCard(insuredDto.getCertno()));
                if(Beans.isEmpty(insuredDto.getBirth_day()))
                    insuredDto.setBirth_day(DateUtil.stringToDate(insuredDto.getExtendInfos().get(Const.CustomerExtendInfoKey.birthday.value),Const.ANT_DATE_FORMAT));
                insuredDto.setAddress(holderDto.getExtendInfos().get(Const.CustomerExtendInfoKey.address.value));
                insuredDto.setSex(Const.genderMap.get(insuredDto.getExtendInfos().get(Const.CustomerExtendInfoKey.gender.value)));
                insuredDto.setPhone(insuredDto.getExtendInfos().get(Const.CustomerExtendInfoKey.phone.value));
                insuredDto.setEmail(insuredDto.getExtendInfos().get(Const.CustomerExtendInfoKey.email.value));
                insuredDto.setNameEn(insuredDto.getExtendInfos().get(Const.CustomerExtendInfoKey.englishName.value));
                if(Const.AntCardType.IDCard.value.equals(insuredDto.getCerttype()))
                    insuredDto.setCerttype(Const.CardType.IDCard.value);
                else if(Const.AntCardType.Passport.value.equals(insuredDto.getCerttype()))
                    insuredDto.setCerttype(Const.CardType.Passport.value);
                else 
                    insuredDto.setCerttype(Const.CardType.Other.value);
            }

            //把拼音加到名字后边
            if(Beans.isNotEmpty(insuredDto.getNameEn()))
                insuredDto.setCertname(insuredDto.getCertname()+insuredDto.getNameEn());
            
            //20180608旅行险可以用护照投保，在<insObject> - <extendInfos>节点增加护照号码信息<extendInfo key="passportNo" value="E123456"/>
            //扩展信息中有护照信息，则更新被保险人的证件类型（护照），证件号码
            if(Beans.isNotEmpty(objDto.getExtendInfos())){
                String passportNo = objDto.getExtendInfos().get(Const.InsObjectExtendInfoKey.passportNo.value);
                log.info("从扩展信息中获取被保险人护照信息，passportNo=" + passportNo);
                if(Beans.isNotEmpty(passportNo)){
                    //本人关系，把投保人证件信息更新
                    if(Const.TRUE.equals(insured.getSameWithHolder().toString())){
                        holderDto.setCerttype(Const.CardType.Passport.value);
                        holderDto.setCertno(passportNo);
                    }
                    insuredDto.setCerttype(Const.CardType.Passport.value);
                    insuredDto.setCertno(passportNo);
                }
            }
            //不同证件类型-对应校验
            validateCertno(insuredDto.getCertno(),insuredDto.getCerttype(),insuredDto.getBirth_day());
            insuredDtoList.add(insuredDto);
        }
        //根据mapping表获取被保险人性别对应的计划
        Integer age = DateUtil.getAge(insuredDtoList.get(0).getBirth_day(),orderDto.getInsuredtime());//年龄计算修改2019年9月6日
        String planCode = service.getPlanCodeFromMapping(orderDto.getOut_product_code(),insuredDtoList.get(0).getSex(),age);
        if(Beans.isNotEmpty(planCode)){
            orderDto.setOut_product_code(planCode);
        }
        //计算insuredType
        for(InsuredDto insuredDto : insuredDtoList){
            if(Beans.isNotEmpty(insuredDto.getBirth_day())){
                insuredDto.setInsuredType(getInsuredType(insuredDto.getBirth_day(), orderDto.getOut_product_code(), orderDto.getInsuredtime(), orderDto.getEffectstarttime()));
            }
        }
        //非空校验
        validateNullRequest(orderDto,holderDto,insuredDtoList);
        //逻辑校验
        validateRequest(orderDto,holderDto,insuredDtoList);
        String coreFlag = service.getConfigValueByKey("INTERFACE", "ig.interface.invoke");//是否走原流程
//        coreFlag = "Y";
        if("Y".equals(coreFlag)){//调用核心接口
            underWriteByAPI(orderDto,holderDto,insuredDtoList);
        }
        //保存订单  
        try {
            saveRequest(orderDto,holderDto,insuredDtoList);
        } catch (Exception e) {
            service.endTransaction();
            if(e instanceof AntException)
                throw (AntException)e;
            e.printStackTrace();
            log.error("saveRequest error "+e);
            throw new AntException("1000",e.toString());
        }
        
        finishUW(rep,orderDto);
            
        return rep;
    }
    
    private void finishUW(CommonResponse rep,OrderDto orderDto) {
        CommonResponseBody body = new CommonResponseBody();
        body.setIs_success(Const.TRUE);
        body.setError_message(Const.allianzErrorMap.get("0000"));
        body.setErrorcode("0000");
        body.setOrder_no(orderDto.getOrder_no());
        body.setProposalNo("");
        
        rep.setBody(body);
    }

    private void saveRequest(OrderDto orderDto, HolderDto holderDto, List<InsuredDto> insuredDtoList) throws Exception {
        service.beginTransaction();
        log.debug("Save Request Data");
        //保存订单
        orderDto.setUnderwrite_flag(Const.UnderWriteStatus.success.value);
        orderDto.setStatus(Const.AntOrderStatus.UWSuccess.value);
        service.saveOrder(orderDto);
        //保存投保人
        holderDto.setOrder_no(orderDto.getOrder_no());
        service.saveHolder(holderDto);
        //保存被保人
        for(InsuredDto insuredDto:insuredDtoList){
            insuredDto.setOrder_no(orderDto.getOrder_no());
            service.saveInsured(insuredDto);
        }
        service.endTransaction();
    }

    /**
     *公共核保
     * @param orderDto
     * @param holderDto
     * @param insuredDtoList
     * @throws AntException
     */
    private void underWriteByAPI(OrderDto orderDto, HolderDto holderDto, List<InsuredDto> insuredDtoList) throws AntException {
        Map<String, Object> resMap = service.underWriteByAPI(orderDto,holderDto,insuredDtoList);
        String errorMsg = (String)resMap.get("errorMsg");
        String responseCode = (String)resMap.get("responseCode");
        String errorCode = (String)resMap.get("errorCode");
        //有返回，且返回失败
        if(Beans.isNotEmpty(responseCode)){
              if(EtravelConst.ResponseCode.fail.value.equals(responseCode)){//返回失败
                  if(Beans.isNotEmpty(errorCode) && !"0000".equals(errorCode)){//0000-成功的ErrorCode
                      throw new AntException("1444",errorMsg);//不重复做errorcode传入
                  }
              }
        } else {
            throw new AntException("1000",errorMsg);
        }
    }
    /**
     *证件号及证件类型校验
     * @param certNo
     * @param certType
     * @param birthDay
     * @throws AntException
     */
    private void validateCertno(String certNo, String certType, Date birthDay) throws AntException {
        if(Const.CardType.IDCard.value.equals(certType)){
            //身份证
            IDInfo idInfo = new IDUtil().IDCardValidate(certNo);
            log.info("idCard validate errMsg: "+idInfo.getErrMsg());
            if(Beans.isNotEmpty(idInfo.getErrMsg())){//身份证号码不合法
                throw new AntException("1444", "被保险人/投保人证件号不合法，请重新确认!");//error.msg.1101=被保险人证件号【%s】不合法，请重新确认!
            }else{
                log.info("birthday in idCard: "+idInfo.getBirthdayStr());
                if(Beans.isNotEmpty(birthDay)){
                    if(!DateUtil.DateToString(birthDay, "yyyyMMdd").equals(idInfo.getBirthdayStr())){//身份证号码中的出生日期和传过来的出生日期不一致
                        throw new AntException("1444","被保险人/投保人证件号中的出生日期和报文中的出生日期不一致，请重新确认!");
                    }
                }
            }
        }else if(Const.CardType.Passport.value.equals(certType)){
            //护照
            if(!checkPassportAndOtherIdNo(certNo)) {
                log.info("idNo(Passport or Others) validate error:" + certNo);
                throw new AntException("1444", "被保险人/投保人证件号不合法，请重新确认!");
            }
        }
    }
    
    /**
     *true--符合，false不符合
     * @param IdNo
     * @return
     */
    private boolean checkPassportAndOtherIdNo(String IdNo) {
        boolean flag = false;
        String passportAndOhterIdNoRegex = service.getConfigValueByKey("ePolicy", EtravelConst.AppAarameterKey.RegExPassport.value);
        try{
            if(Beans.isEmpty(passportAndOhterIdNoRegex)) {
                return true;
            }
            Pattern regex = Pattern.compile(passportAndOhterIdNoRegex);
            Matcher matcher = regex.matcher(IdNo);
            flag = matcher.matches();
        }catch(Exception e){
            flag = false;
        }
        return flag;
    }
    /**
     * 校验xml
     * @param request
     * @throws AntException
     */
    private void validateRequest(OrderDto orderDto, HolderDto holderDto, List<InsuredDto> insuredDtoList) throws AntException {
        
        //获取保险计划
        PlanInfoDto planinfo;
        //校验保险计划
        try {
            planinfo = service.findPlanInfoByPlanCode(orderDto.getOut_product_code(),orderDto.getEffectstarttime());
        } catch (Exception e) {
            if(e instanceof AntException)
                throw (AntException)e;
            e.printStackTrace();
            log.error("findPlanInfoByPlanCode product_code:"+orderDto.getOut_product_code());
            log.error("findPlanInfoByPlanCode error "+e);
            throw new AntException("1000",e.toString());
        }
        validatePlan(planinfo,orderDto);
        //如果不是航空相关产品，终保时间不能为空
        if(!Const.FLIGHT_SUBPRODUCT.contains(planinfo.getSubProduct())){
            if (Beans.isEmpty(orderDto.getEffectendtime()))
                throw new AntException("1102");
        }else{
            if(Beans.isEmpty(orderDto.getEffectendtime())){
                orderDto.setEffectendtime(DateUtil.getDateTimeBeforeOrAfter(orderDto.getEffectstarttime(), Calendar.DAY_OF_MONTH, 1));
                log.info("航空相关产品,终保时间为空，设置终保日期" + orderDto.getEffectendtime());
            }
        }
        //校验保单信息
        validatePolicy(orderDto);
        //校验投保人
        validateHolder(holderDto);
        //校验被保险人
        validateInsureds(insuredDtoList,orderDto,planinfo);
//        //校验保费
        if(service.isCheckOTIPremium(false)){
            log.info("开启新单校验保费...validatePremium...");
            //家财险不做此校验
            if(!service.isHomePlan(orderDto.getOut_product_code(), orderDto.getEffectstarttime())){
                validatePremium(orderDto,insuredDtoList,planinfo,false);
            }
        }
        //特殊计划的投保次数校验(成功出单，不看承保区间，只针对该接口出的单)
        validateLimitTimes(orderDto, holderDto);
        //一些公共的业务逻辑校验
        this.validateCommonLimit(orderDto, holderDto, insuredDtoList, planinfo);
        
        //续保校验
        if(service.openRenewal()){
            validateRenewal(orderDto, insuredDtoList, planinfo);
        }
        
        //家财险-校验
        if(service.isHomePlan(orderDto.getOut_product_code(), orderDto.getEffectstarttime())){
            validateHome(orderDto, insuredDtoList, planinfo);
        }
    }
    
    //特殊计划的投保次数校验(成功出单，不看承保区间，只针对该接口出的单)
    private void validateLimitTimes(OrderDto orderDto, HolderDto holderDto) throws AntException {
        if(service.overLimitTimes(orderDto.getOut_product_code(), holderDto.getCertno())){
            throw new AntException("9901");
        }
    }
    
    //一些公共的业务逻辑校验        
    private void validateCommonLimit(OrderDto orderDto, HolderDto holderDto, List<InsuredDto> insuredDtoList, PlanInfoDto planinfo) throws AntException {
        String returnCode = service.validateCommonLimit(orderDto, holderDto, insuredDtoList, planinfo);
        //超过投保次数
        if("overTimeLimit".equals(returnCode)){
            throw new AntException("1023");
        }else if("overInsurantTimeLimit".equals(returnCode)){
            throw new AntException("1024");
        }
    }
    
    
    private void validatePremium(OrderDto orderDto,List<InsuredDto> insuredDtoList,PlanInfoDto planinfo, boolean isRenewalFlag) throws AntException {
        Integer period = null;
        //if(!Const.FLIGHT_SUBPRODUCT.contains(planinfo.getSubProduct()))
            period = DateUtil.getBetweenDay(orderDto.getEffectstarttime(), orderDto.getEffectendtime())+1;
        BigDecimal premium = BigDecimal.ZERO;
        //BigDecimal sumInsured = null;
        BigDecimal premiumTemp = null;
        for(InsuredDto dto:insuredDtoList){
            try {
                log.info("getPlanPremium planCode="+orderDto.getOut_product_code()+" period="+period+" insuredType="+dto.getInsuredType());
                premiumTemp = service.getPlanPremium(orderDto.getOut_product_code(), orderDto.getEffectstarttime(), orderDto.getEffectendtime(), period,dto.getInsuredType());
                premium = premium.add(Beans.isEmpty(premiumTemp) ? BigDecimal.ZERO : premiumTemp);
                //sumInsured = service.getPlanSumInsured(orderDto.getOut_product_code());
            } catch (Exception e) {
                if(e instanceof AntException)
                    throw (AntException)e;
                e.printStackTrace();
                log.error("getPlanPremium planCode="+orderDto.getOut_product_code()+" period="+period+" insuredType="+dto.getInsuredType());
                log.error("getPlanPremium error "+e);
                throw new AntException("1000",e.toString());
            }
        }
        if(Beans.isEmpty(premium)||orderDto.getPremium().divide(new BigDecimal(100)).compareTo(premium)!=0){
            log.info("报文保费:" + orderDto.getPremium()+"/分, 系统计算保费:" + premium);
            //配置白名单计划忽略保费校验
            if(service.isCheckOTIPremiumWhiteList(orderDto.getOut_product_code())){
                log.info("保费不符!! 该计划配置了白名单，忽略保费校验。 planCode=" + orderDto.getOut_product_code());
                return;
            }
            if(isRenewalFlag){
                throw new AntException("2009");//续保保费错误
            }else{
                throw new AntException("1014");
            }
            
        } 
//        if(Beans.isEmpty(sumInsured)||orderDto.getSum_insured().divide(new BigDecimal(100)).compareTo(sumInsured)!=0)
//            throw new AntException("1015");
    }

    private void validateNullRequest(OrderDto orderDto,HolderDto holderDto,List<InsuredDto> insuredDtoList) throws AntException {
        try {
            if (Beans.isEmpty(orderDto.getEffectstarttime()))
                throw new AntException("1101");
            if (Beans.isEmpty(orderDto.getOut_product_code()))
                throw new AntException("1102");
            if (Beans.isEmpty(orderDto.getPremium()))
                throw new AntException("1103");
            if (Beans.isEmpty(orderDto.getOrder_no()))
                throw new AntException("1108");
            
            if (Beans.isEmpty(holderDto.getCertno()))
                throw new AntException("1104");
            if (Beans.isEmpty(holderDto.getBirth_day()))
                throw new AntException("1113");
            
            for(InsuredDto insuredDto:insuredDtoList){
                if (Beans.isEmpty(insuredDto.getCertno()))
                    throw new AntException("1104");
                if (Beans.isEmpty(insuredDto.getCerttype()))
                    throw new AntException("1011");
                if (Beans.isEmpty(insuredDto.getCertname()))
                    throw new AntException("1105");
                if (Beans.isEmpty(insuredDto.getBirth_day()))
                    throw new AntException("1114");
            }
           
        } catch (Exception ae) {
            if(ae instanceof AntException)
                throw (AntException)ae;
            ae.printStackTrace();
            log.error("validateNullRequest error:"+ae);
            throw new AntException("1000",ae.toString());
        }
    }
    
    private void validatePolicy(OrderDto orderDto) throws AntException {
        if((new Date()).after(orderDto.getEffectstarttime()))
            throw new AntException("1013");
        if(Beans.isNotEmpty(orderDto.getEffectendtime())&&orderDto.getEffectstarttime().after(orderDto.getEffectendtime()))
            throw new AntException("1107");
    }
    
    private void validatePlan(PlanInfoDto planinfo,OrderDto orderDto) throws AntException {
        if(Beans.isEmpty(planinfo.getPlanCode()))
            throw new AntException("1004");    
        
//        if(Beans.isNotEmpty(planinfo.getEndDate()))
//            if(orderDto.getEffectendtime().after(planinfo.getEndDate()))
//                throw new AntException("1005");
        
        if(!Const.TRUE.equals(planinfo.getStatus()))
            throw new AntException("1006");
        
        //2017-09 增加校验计划是否授权该渠道(配置开关)
        if(!service.checkPlanAssignment(planinfo.getPlanId(), planinfo.getPlanCode(), orderDto.getEffectstarttime())){
            throw new AntException("1022");
        }
    }

    /**
     * 校验投保人信息
     * @param order
     * @return
     */
    private boolean validateHolder(HolderDto holderDto) throws AntException {
        if(service.personInBlacklist(Long.parseLong(holderDto.getCerttype()),holderDto.getCertno(),holderDto.getCertname()))
            throw new AntException("1021");
        //投保人年龄校验，须满18周岁
        Integer age = DateUtil.getAge(holderDto.getBirth_day(),new Date());
        if(age<18)
            throw new AntException("1007");
        
        return true;    
    }
    
    /**
     * 校验被保险人信息
     * @param order
     * @return
     */
    private boolean validateInsureds(List<InsuredDto> insuredDtoList,OrderDto orderDto,PlanInfoDto planinfo) throws AntException {
        //被保险人年龄校验，须在计划的年龄限制范围内
        for(InsuredDto insuredDto:insuredDtoList){
            if(service.personInBlacklist(Long.parseLong(insuredDto.getCerttype()),insuredDto.getCertno(),insuredDto.getCertname()))
                throw new AntException("1021");
            Integer age = DateUtil.getAge(insuredDto.getBirth_day(),orderDto.getEffectstarttime());
            if(planinfo.getStartAge()!=null && planinfo.getStartAge()==0.16){
                if(lessthan60Days(insuredDto.getBirth_day(),orderDto.getEffectstarttime()))
                    throw new AntException("1008");
            }
            else if(planinfo.getStartAge()!=null && planinfo.getStartAge()>age)
                throw new AntException("1008");
            //续保单不校验计划配置中的最大年龄；续保最大年龄校验在续保校验中
            if(!Const.IsRenewal.Renewal.value.equals(orderDto.getIs_renewal()) && planinfo.getEndAge()!=null&& planinfo.getEndAge()>0 && planinfo.getEndAge()<age)
                throw new AntException("1008");
        }
        return true;    
    }

    /**
     * 设置被保险人类型
     * @param prlTaobaoInfOrderInsured
     */
    private String getInsuredType(Date birthDay, String planCode,Date insuredDate, Date effStartDate) {
        Integer age = DateUtil.getAge(birthDay, insuredDate);
        String insuredType = service.getOTIInsuredType(planCode, age, effStartDate);
        if(Beans.isNotEmpty(insuredType)){
            return insuredType;
        }
        log.info("年龄范围不在计划配置范围内的，使用基本规则. planCode: " + planCode + ", age: " + age);
        if(0<=age && age<=17)
            return Const.InsuredType.child.value;
        else if (18<=age && age<=64)
            return Const.InsuredType.adult.value;
        else if (65<=age)
            return Const.InsuredType.aged.value;
        return null;
    }
    
    private boolean lessthan60Days(Date birthDay, Date startDate) throws AntException {
        Calendar cal = Calendar.getInstance();

        if (cal.before(birthDay)) {
            throw new IllegalArgumentException("The birthDay is before Now.It's unbelievable!");
        }
        if(DateUtil.getBetweenDay(birthDay,startDate)<60)
            return true;
       
        return false;
    }

    private void validateHome(OrderDto orderDto, List<InsuredDto> insuredDtoList, PlanInfoDto planinfo) throws AntException {
        log.info("validateHome... order_no="+orderDto.getOrder_no());
        if(Beans.isEmpty(insuredDtoList) || insuredDtoList.size() > 1){
            log.info("被保人数量只能为1");
            throw new AntException("3001");
        }
        if(Beans.isEmpty(orderDto.getAddress_code()) || Beans.isEmpty(orderDto.getEhome_address())){
            log.info("城市代码与详细地址必填");
            throw new AntException("3002");
        }
        //获取对应的地区代码
        Map<String, String> rcMap = null;
        try{
            rcMap = service.getRegionCodeMap(orderDto.getAddress_code());
        } catch (Exception e) {
            log.error("getRegionCodeMap error "+e);
            throw new AntException("1000",e.toString());
        }
        
        if(Beans.isEmpty(rcMap)){
            log.error("获取地区信息失败! address_code="+orderDto.getAddress_code());
            log.info("获取地区信息错误，请联系客服");
            throw new AntException("3003");
        }
        //限制地区
        String regionLimitStr = service.getRegionLimit(orderDto.getOut_product_code());
        log.info("checkaddress="+rcMap.get(RegionCode.ProvinceCode.value)+"/"+rcMap.get(RegionCode.CityCode.value));
        log.info("regionLimitStr="+regionLimitStr); //format: SH/SH,BJ/BJ,CQ/CQ,TJ/TJ ...
        if(Beans.isNotEmpty(regionLimitStr)){
            regionLimitStr = ","+regionLimitStr+",";
            String checkStr = ","+rcMap.get(RegionCode.ProvinceCode.value)+"/"+rcMap.get(RegionCode.CityCode.value)+",";
            if(!regionLimitStr.contains(checkStr)){
                log.info("该地区不在承保范围");
                throw new AntException("3004");
            }
        }  
        //注：安联保费以元为单位，蚂蚁平台保费以分为单位
        if(Beans.isEmpty(planinfo.getPremium()) || 
           Beans.isEmpty(orderDto.getPremium()) || 
           (planinfo.getPremium().multiply(new BigDecimal(100))).compareTo(orderDto.getPremium()) != 0){
            log.info("与系统计算保费不符");
            throw new AntException("3005");
        }
        //保险计划投保时间不能超过一年
        Date nextYearTime = com.allianz.oti.common.util.DateUtils.getTimeOfNextYear(orderDto.getEffectstarttime());
        if (Beans.isNotEmpty(orderDto.getEffectendtime()) && orderDto.getEffectendtime().after(nextYearTime)) {
            log.info("保险计划投保时间不能超过一年");
            throw new AntException("3006");
        }
        
    }
    
   
    /**
     * 续保校验
     * 触发校验条件： 1-续保
     */
    private void validateRenewal(OrderDto orderDto, List<InsuredDto> insuredDtoList, PlanInfoDto planinfo) throws AntException {
        log.info("validateRenewal for underWritr...order_no: " +  orderDto.getOrder_no());
        if(Const.IsRenewal.Renewal.value.equals(orderDto.getIs_renewal())){
            //是否校验保费
            if(service.isCheckOTIPremium(true)){
                log.info("开启续保校验保费...validatePremium...");
                validatePremium(orderDto,insuredDtoList,planinfo, true);
            }else{
                log.info("关闭续保校验保费...");   
            }
            
            if(Beans.isEmpty(orderDto.getOld_out_policy_no())){
                throw new AntException("2000");//原保单号不能为空
            }
            //获取原保单信息
            PolicyInfoVo policyInfo = service.getPolicyInfoByPolicyNo(orderDto.getOld_out_policy_no());
            //没有原保单记录
            if(Beans.isEmpty(policyInfo)){
                throw new AntException("2001");
            }
            //是否续保产品
            /*if(!Const.YES.equals(policyInfo.getRenewableFlag())){
                throw new AntException("2002");
            }*/
            //是否一年期产品(原保单的承保区间)
            String expireDate = DateUtil.DateToString(policyInfo.getExpireDate(),"yyyy-MM-dd HH:mm");
            Date nextYearTime = DateUtil.getDateTimeBeforeOrAfter(policyInfo.getEffectiveDate(), Calendar.YEAR, 1); //TimeOfNextYear
            String expireDateNotZero = DateUtil.DateToString(DateUtil.getDateTimeBeforeOrAfter(nextYearTime, Calendar.MINUTE, -1),"yyyy-MM-dd HH:mm"); //getDateTimeBefore
            String expireDateZero = DateUtil.DateToString(nextYearTime, "yyyy-MM-dd HH:mm");
            if (!expireDate.equals(expireDateNotZero) && !expireDate.equals(expireDateZero)) {
                throw new AntException("2003");
            }
            //是否一年期产品(计划配置)
            if(!Const.CalMethod.Year.value.equals(policyInfo.getPremCalMethod())){
                throw new AntException("2003");
            }
            //原保单是否生效状态
            if(!Const.PolicyStatus.InForce.value.equals(policyInfo.getPolicyStatus())){
                throw new AntException("2004");
            }
            //续保宽限期(在宽限期内进行投保即可)
            /*if(Beans.isNotEmpty(policyInfo.getRenewableGracePeriod()) && DateUtil.addDay(policyInfo.getExpireDate(), policyInfo.getRenewableGracePeriod()).compareTo(new Date()) < 0 ){
                throw new AntException("2005");
            }*/
            //续保起保时间必须大于原保单的结束时间
            if(orderDto.getEffectstarttime().compareTo(policyInfo.getExpireDate()) < 0){
                throw new AntException("2006");
            }
            //原保单已续保
            if(Beans.isNotEmpty(service.getOldContractStatus(policyInfo.getContractId()))){
                throw new AntException("2007");
            }
            GroupPlanInfoDto groupPlanInfo = service.getGroupPlanInfo(planinfo.getGroupPlanCode());
            //被保险人续保校验 
            for(InsuredDto insuredDto : insuredDtoList){
                //风险客户
                if(service.validateRiskCustomer(orderDto, insuredDto, policyInfo.getContractId())){
                    throw new AntException("2008");
                }
                //续保最大年龄
                if(Beans.isNotEmpty(groupPlanInfo) && Beans.isNotEmpty(groupPlanInfo.getRenewableMaxAge()) && groupPlanInfo.getRenewableMaxAge() > 0){
                    Integer age = DateUtil.getAge(insuredDto.getBirth_day(), orderDto.getEffectstarttime());
                    log.info("GroupPlanCode:" + planinfo.getGroupPlanCode() + ", RenewableMaxAge:" + groupPlanInfo.getRenewableMaxAge() + ", age:" + age);
                    if(age > groupPlanInfo.getRenewableMaxAge()){
                        throw new AntException("1008");
                    }
                }
            }
        }
    }
    
}

/**
 * 数据库配置更新接口
 */

 package com.allianz.cn.pc.ant.servlet;


import com.allianz.cn.pc.ant.services.Config;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;


public class ConfigUpdateServlet extends HttpServlet {
    static Logger logger = Logger.getLogger(ConfigUpdateServlet.class);
    
    public final static String UTF8 = "UTF-8";
    public final static String GBK = "GBK";
    private final static String RSP_CONTENT_TYPE = "text/html; charset=UTF-8";
    private static final String ERROR_RSP_CONTENT_TYPE = "text/html; charset=UTF-8";

    public void init(ServletConfig config) throws ServletException {
        super.init(config);
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        doPost(request,response);
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        request.setCharacterEncoding(UTF8);
        response.setCharacterEncoding(UTF8);
        response.setContentType(RSP_CONTENT_TYPE);

        PrintWriter out = response.getWriter();
        String res = null;
        
        try {
            Config.getInstance().updateConfig();
            res = "数据库配置更新成功";
            logger.info(res);
            out.print("");
        } catch (Exception e) {
            logger.error(e.getMessage(),e);
            
        }finally{
            out.flush();
            out.close();
        }
    }

}

package com.allianz.cn.pc.ant.xmlbean.ant.underwrite.request;


import com.allianz.cn.pc.ant.xmlbean.ant.CommonHeader;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("request")
public class UnderWriteRequest {
    
    @XStreamAlias("head")
    private CommonHeader head = new CommonHeader();
    
    @XStreamAlias("body")
    private UnderWriteRequestBody body = new UnderWriteRequestBody();

    public void setHead(CommonHeader head) {
        this.head = head;
    }

    public CommonHeader getHead() {
        return head;
    }


    public void setBody(UnderWriteRequestBody body) {
        this.body = body;
    }

    public UnderWriteRequestBody getBody() {
        return body;
    }
}

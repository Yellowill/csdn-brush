
package com.allianz.cn.pc.ant.test;


import com.allianz.cn.pc.ant.Const;
import com.allianz.cn.pc.ant.Const.AntOrderStatus;
import com.allianz.cn.pc.ant.action.CommonAction;
import com.allianz.cn.pc.ant.action.PolicyConfirmAction;
import com.allianz.cn.pc.ant.action.UnderWriteAction;
import com.allianz.cn.pc.ant.dto.AntTransDto;
import com.allianz.cn.pc.ant.exceptions.AntException;
import com.allianz.cn.pc.ant.services.Config;
import com.allianz.cn.pc.ant.utils.BusinessUtil;
import com.allianz.cn.pc.ant.utils.RsaSignatureUtil;
import com.allianz.cn.pc.ant.xmlbean.ant.CommonHeader;
import com.allianz.cn.pc.ant.xmlbean.ant.CommonResponse;
import com.allianz.cn.pc.ant.xmlbean.ant.CommonResponseBody;
import com.allianz.cn.pc.ant.xmlbean.ant.DocumentNode;
import com.allianz.cn.pc.ant.xmlbean.ant.policyconfirm.request.PolicyConfirmRequest;
import com.allianz.cn.pc.utils.Beans;
import com.allianz.cn.pc.utils.XmlUtil;

import java.io.IOException;
import java.io.PrintWriter;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;


public class CoffeeUWTestServlet extends HttpServlet {
    static Logger log = Logger.getLogger(CoffeeUWTestServlet.class);
    public final static String UTF8 = "utf-8";
    public final static String GBK = "gbk";
    private static volatile Long orderno = 201606030000000001L;

    private static Map<String, Class> RequestTypeMap = new HashMap() {
        {
            put(Const.FUNCTION_CODE_UNDERWRITE, PolicyConfirmRequest.class);
            put(Const.FUNCTION_CODE_POLICYCONFIRM, PolicyConfirmRequest.class);
        }
    };

    private static Map<String, Class> ActionTypeMap = new HashMap() {
        {
            put(Const.FUNCTION_CODE_UNDERWRITE, UnderWriteAction.class);
            put(Const.FUNCTION_CODE_POLICYCONFIRM, PolicyConfirmAction.class);
        }
    };

    public void init(ServletConfig config) throws ServletException {
        super.init(config);
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding(UTF8);
        response.setCharacterEncoding(UTF8);
        response.setContentType("application/xml;charset=utf-8");

        PrintWriter out = response.getWriter();

        final Integer threadNum = Integer.parseInt(request.getParameter("num"));
        String key = request.getParameter("key");

        try {
            if ("Coffeetest".equals(key)) {
                Thread t = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        for (int i = 0; i < threadNum; i++) {
                            Thread t = new Thread(new Runnable() {
                                public void run() {
                                    try {
                                        long temp = orderno++;
                                        System.err.println(temp);
                                        new MyAction().test(xml.replace("3388100000000000000166",
                                                                        String.valueOf(temp)));
                                    } catch (Exception e) {
                                    }
                                }
                            });
                            t.start();
                        }
                    }
                });
                t.start();
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            out.close();
        }

    }

    class MyAction {
        public void test(String baseString) {
            long startTime = System.currentTimeMillis();
            DocumentNode document = new DocumentNode();
            CommonResponse rep = new CommonResponse();
            String sinature = null;
            String headXml = null;
            String bodyXml = null;
            CommonHeader head = null;
            AntTransDto transDto = new AntTransDto();
            String orderNo = null;

            try {
                log.debug("request xml is \n" +
                        baseString);
                Document doc = null;
                SAXReader reader = new SAXReader();
                reader.setEncoding(GBK);

                doc = reader.read(IOUtils.toInputStream(baseString), GBK);
                Element root = doc.getRootElement();

                //获取RSA加密串
                Element signatureNode = root.element("signature");
                String signatureStr = null;
                if (null != signatureNode)
                    signatureStr = signatureNode.getText().trim();

                //获取请求报文头和报文体
                Element requestNode = root.element("request");
                if (null != requestNode) {
                    headXml = requestNode.element("head").asXML();
                    bodyXml = requestNode.element("body").asXML();
                }

                head = XmlUtil.fromXml(CommonHeader.class, headXml);
                //获取返回报文头
                rep.setHead(head);

                //校验RSA加密内容
                String requestStr =
                    baseString.substring(baseString.indexOf("<request>"), baseString.indexOf("</request>"));
                requestStr = requestStr.replace("<request>", "");
                if (null != requestStr)
                    log.debug("RSA vilidate pass !");

                //转换报文头
                Beans.copy(transDto, head);
                Element policyNo = requestNode.element("body").element("policy").element("policyNo");
                transDto.setOrder_no(policyNo.getText());
                transDto.setOrder_status(Const.AntOrderStatus.NoRecord.value);
                orderNo = policyNo.getText();

                //获取返回报文体
                CommonAction action = null;
                Class actionClazz = null;
                if (null != requestStr) {
                    actionClazz = ActionTypeMap.get(head.getFunction_code());
                    action = (CommonAction)actionClazz.newInstance();
                    CommonResponse temp = action.doProcess(requestNode);
                    rep.setBody(temp.getBody());
                }
                //更新trans表
                //            updateTrans(transDto, rep.getBody());

            } catch (Exception e) {
                log.error(e.getMessage(),e);
                rep = BusinessUtil.createErrorResponse(head, e);
                //更新trans表
                //            try {
                //                updateTrans(transDto, rep.getBody());
                //            } catch (Exception f) {
                //                f.printStackTrace();
                //                rep = BusinessUtil.createErrorResponse(head, f);
                //            }
            } finally {
                String resXml = XmlUtil.toXml(rep,"utf-8");
                log.debug("###response xml is ### " + resXml);
                rep = BusinessUtil.convertAntError(rep, orderNo);
                bodyXml = XmlUtil.toXml(rep.getBody(), "utf-8");
                bodyXml = bodyXml.substring(bodyXml.indexOf("<body>"));
                log.debug("###response body xml is ### " + bodyXml);
                sinature = headXml + bodyXml; //需要加密的内容,将格式化为一行
                sinature = sinature.replaceAll("\\s+", " "); //所有换行和空白，都换成一个空白
                sinature = sinature.replace("> <", "><"); //节点间的空白去掉
                sinature = RsaSignatureUtil.sign(sinature, Config.getInstance().getPrivateKey()); //加密
                document.setSignature(sinature);
                document.setResponse(rep);
                resXml = XmlUtil.toXml(document, "utf-8");
                resXml = resXml.replaceAll("\\s+", " "); //所有换行和空白，都换成一个空白
                resXml = resXml.replace("> <", "><"); //节点间的空白去掉
                log.debug("###response xml is ### " + resXml);

                System.err.println("uw cost " + (System.currentTimeMillis() - startTime));
            }
        }

        private void updateTrans(AntTransDto transDto, CommonResponseBody repbody) throws Exception {
            Beans.copy(transDto, repbody);
            if (Const.FUNCTION_CODE_UNDERWRITE.equals(transDto.getFunction_code())) {
                if (Beans.isNotEmpty(transDto.getErrorcode()) || "0000".equals(transDto.getErrorcode()))
                    transDto.setOrder_status(AntOrderStatus.UWSuccess.value);
                else
                    transDto.setOrder_status(AntOrderStatus.UWFail.value);
            }
            if (Const.FUNCTION_CODE_POLICYCONFIRM.equals(transDto.getFunction_code())) {
                if (Beans.isNotEmpty(transDto.getErrorcode()) && Beans.isNotEmpty(transDto.getPolicyNo()))
                    transDto.setOrder_status(AntOrderStatus.IssueSuccess.value);
                else
                    transDto.setOrder_status(AntOrderStatus.IssueFail.value);
            }
            CommonAction.updateTrans(transDto);
        }

        private void saveTrans(AntTransDto transDto) throws Exception {
            if (Const.FUNCTION_CODE_UNDERWRITE.equals(transDto.getFunction_code())) {
                transDto.setOrder_status(AntOrderStatus.WaitUW.value);
            }
            if (Const.FUNCTION_CODE_POLICYCONFIRM.equals(transDto.getFunction_code())) {
                transDto.setOrder_status(AntOrderStatus.WaitIssue.value);
            }
            CommonAction.saveTrans(transDto);
        }

        private void validateSinature(String sinature, String content) throws AntException {
            try {
                if (RsaSignatureUtil.verify(content, sinature, Config.getInstance().getPublicKey()))
                    return;
            } catch (Exception e) {
                e.printStackTrace();
                log.error("validateSinature error sinature:" + sinature);
                e.printStackTrace();
            }
            throw new AntException("1200");
        }

        private void validateHead(CommonHeader head) throws AntException {
            if (!CommonAction.validateRequestId(head.getReqmsgid()))
                throw new AntException("1003");
            if (Beans.isEmpty(head.getFunction_code()) || !Const.functionTypeList.contains(head.getFunction_code()))
                throw new AntException("1002");
        }
    }
    
    public static void main(String[] args) {
        System.err.println(xml);
    }

    private static String xml =
        "<?xml version=\"1.0\" encoding=\"utf-8\"?> " + "<document> " + "    <signature>Os/j3YhnEjfQyvIAQt0iA8IQSFALyNsNx7vx4BzmnwU7VI9pXl7zPpgkWZUFEGJ1jWCDtR7q0UNmMpif/xYeuAXvuGSoUVXhyTNmcmT06AJD0Z33Vjmtj7nJHMjAdxM3ahXOoL5eurwYb5Qt/j+GGbTMuXznRpNQydz4kgnZ+RxnjbmNMhcY6SSd7wPLZM3uGvwAUY3Ey9IcTfOBCZocw9s3Dhe8Thk3MLIIkoN+ZshixHuVyTzH4KRheGSYWAjvJIqckf8EPCvSFvtXDNt5T25YZfc41CmeQ0t7JbI1BG0OAVVyrxguZAeHPHXGCPGuWQHxnmRzqZE4Nlm7l4lpsg==</signature> " +
        "    <request> " + "        <head> " + "            <version>3.0</version> " +
        "            <function>ant.bxcloud.core.underwrite</function> " +
        "            <transTime>20160512163444</transTime> " + "            <transTimeZone>UTC+8</transTimeZone> " +
        "            <reqMsgId>20160512110400030001151050561800</reqMsgId> " + "            <format>xml</format> " +
        "            <signType>RSA</signType> " + "            <asyn>0</asyn> " +
        "            <cid>238810000096864268346</cid> " + "        </head> " + "        <body> " +
        "            <policy> " + "                <policyNo>3388100000000000000166</policyNo> " +
        "                <prodNo>6677-10</prodNo> " + "                <outProdNo>ant-health-m</outProdNo> " +
        "                <summaryPolicyNo></summaryPolicyNo> " + "                <policyType>2</policyType> " +
        "                <premium>20000</premium> " + "                <actualPremium>10000</actualPremium> " +
        "                <sumInsured>10000000</sumInsured> " +
        "                <insuredTime>20160512163436</insuredTime> " + "                <issueTime></issueTime> " +
        "                <effectStartTime>20160914000000</effectStartTime> " +
        "                <effectEndTime>20160916235959</effectEndTime> " + "                <applyNum>1</applyNum> " +
        "                <extendInfos> " + "                    <extendInfo key=\"xxx\" value=\"yyy\"/> " +
        "                </extendInfos> " + "            </policy> " + "            <insObject> " +
        "                <type>99</type> " + "            </insObject> " + "            <holder> " +
        "                <personNo>12345</personNo> " + "                <accountType>1</accountType> " +
        "                <accountNo>7999465</accountNo> " + "                <accountName>张三</accountName> " +
        "                <certType>102</certType> " + "                <certNo>510522197811020417</certNo> " +
        "                <certName>张三</certName> " + "                <extendInfos> " +
        "                    <extendInfo key=\"englishName\" value=\"null\"/> " +
        "                    <extendInfo key=\"birthday\" value=\"19760519\"/> " +
        "                    <extendInfo key=\"email\" value=\"coffeexie.sino@allianz.cn\"/> " +
        "                    <extendInfo key=\"phone\" value=\"15920135190\"/> " +
        "                    <extendInfo key=\"gender\" value=\"F\"/> " + "                </extendInfos> " +
        "            </holder> " + "            <insureds> " + "                <insured> " +
        "                    <sameWithHolder>1</sameWithHolder> " + "                </insured> " +
        "            </insureds> " + "        </body> " + "    </request> " + "</document>";

}

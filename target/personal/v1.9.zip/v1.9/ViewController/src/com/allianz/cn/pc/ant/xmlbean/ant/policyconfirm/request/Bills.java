package com.allianz.cn.pc.ant.xmlbean.ant.policyconfirm.request;


import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import java.util.ArrayList;
import java.util.List;

@XStreamAlias("bills")
public class Bills {
    @XStreamImplicit(itemFieldName="bill")
    private List<Bill> billList = new ArrayList<Bill>();

    public void setBillList(List<Bill> illList) {
        this.billList = illList;
    }

    public List<Bill> getBillList() {
        return billList;
    }
}

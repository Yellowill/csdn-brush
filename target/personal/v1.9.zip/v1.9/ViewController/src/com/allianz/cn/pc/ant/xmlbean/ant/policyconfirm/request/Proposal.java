package com.allianz.cn.pc.ant.xmlbean.ant.policyconfirm.request;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("proposal")
public class Proposal {
   
    @XStreamAlias("proposalNo")
    private String proposalNo;
    
   

    public void setProposalNo(String proposalNo) {
        this.proposalNo = proposalNo;
    }

    public String getProposalNo() {
        return proposalNo;
    }

 
}

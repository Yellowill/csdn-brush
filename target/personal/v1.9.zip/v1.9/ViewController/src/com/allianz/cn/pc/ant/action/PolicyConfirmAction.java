package com.allianz.cn.pc.ant.action;


import com.allianz.cn.pc.ant.Const;
import com.allianz.cn.pc.ant.Const.AccountType;
import com.allianz.cn.pc.ant.Const.PolicyStatus;
import com.allianz.cn.pc.ant.dto.BillDto;
import com.allianz.cn.pc.ant.dto.HolderDto;
import com.allianz.cn.pc.ant.dto.InsuredDto;
import com.allianz.cn.pc.ant.dto.OrderDto;
import com.allianz.cn.pc.ant.dto.PlanInfoDto;
import com.allianz.cn.pc.ant.exceptions.AntException;
import com.allianz.cn.pc.ant.services.AntService;
import com.allianz.cn.pc.ant.services.Config;
import com.allianz.cn.pc.ant.utils.DateUtil;
import com.allianz.cn.pc.ant.utils.EncodeUtil;
import com.allianz.cn.pc.ant.vo.PolicyInfoVo;
import com.allianz.cn.pc.ant.xmlbean.ant.CommonResponse;
import com.allianz.cn.pc.ant.xmlbean.ant.CommonResponseBody;
import com.allianz.cn.pc.ant.xmlbean.ant.policyconfirm.request.Bill;
import com.allianz.cn.pc.ant.xmlbean.ant.policyconfirm.request.PolicyConfirmRequest;
import com.allianz.cn.pc.utils.Beans;
import com.allianz.cn.pc.utils.XmlUtil;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;

import org.dom4j.Element;


public class PolicyConfirmAction extends CommonAction{

    private static Logger log = Logger.getLogger(PolicyConfirmAction.class);
    private static ExecutorService executor = Executors.newFixedThreadPool(Config.getInstance().getThreadPoolSize());
  
    public CommonResponse doProcess(Element node) throws AntException {
        log.debug("start PolicyConfirm doProcess !!!");
        CommonResponse rep = new CommonResponse();
        PolicyConfirmRequest request = XmlUtil.fromXml(PolicyConfirmRequest.class, node.asXML());
        //查找并校验订单
        OrderDto uwOrderDto = null;
        String inOrderNo = null;
        OrderDto dbOrderDto = null;
        HolderDto dbHolderDto = null;
        List<InsuredDto> dbInsuredDtoList = null;
        PlanInfoDto planinfo = null;
        try {
            inOrderNo = request.getBody().getPolicy().getOrder_no();
            uwOrderDto = service.findOrder(inOrderNo);
            validateUWOrder(uwOrderDto, inOrderNo);
            //如果不是核保成功状态，直接返回结果
            if(Const.AntOrderStatus.UWSuccess.value!=uwOrderDto.getStatus()){
                log.info("issue retry, orderNo="+uwOrderDto.getOrder_no());
                finishIssue(rep,uwOrderDto);
                return rep;
            }
            
            dbOrderDto = service.findOrderByOrderNo(inOrderNo);
            dbHolderDto = service.findHolderByOrderNo(inOrderNo);
            dbInsuredDtoList = service.findInsuredListByOrderNo(inOrderNo);
            planinfo = service.findPlanInfoByPlanCode(dbOrderDto.getOut_product_code(), dbOrderDto.getEffectstarttime());
        } catch (Exception e) {
            if(e instanceof AntException)
                throw (AntException)e;
            e.printStackTrace();
            log.error("findOrder order_no:"+inOrderNo);
            log.error("findOrder error "+e);
            throw new AntException("1000",e.toString());
        }
        
        //转换账单
        List<BillDto> billDtoList = new ArrayList<BillDto>();
        for(Bill bill:request.getBody().getBills().getBillList()){
            BillDto billDto = new BillDto();
            Beans.copy(billDto, bill);
            billDto.setMerchantaccounttype(bill.getMerchantAccountType());
            billDto.setOtheraccounttype(bill.getOtherAccountType());
            billDto.setPaytime(bill.getPayTime());
            billDto.setOrder_no(uwOrderDto.getOrder_no());
            billDto.setMerchantaccountid(bill.getMerchantAccountId()); //2018-05补录AccountId，PayFlowId 3个字段值到DB
            billDto.setOtheraccountid(bill.getOtherAccountId());
            billDto.setPayflowid(bill.getPayFlowId());
            billDtoList.add(billDto);
        }
        
        //校验账单
        validateRequest(billDtoList,uwOrderDto);
        
        //特殊计划的投保次数校验(成功出单，不看承保区间，只针对该接口出的单)
        if(Beans.isNotEmpty(request.getBody().getPolicy()) && Beans.isNotEmpty(request.getBody().getHolder())){
            validateLimitTimes(request.getBody().getPolicy().getOut_product_code(), request.getBody().getHolder().getCertno());
        }
        //一些公共的业务逻辑校验
        this.validateCommonLimit(dbOrderDto, dbHolderDto, dbInsuredDtoList, planinfo);
        //续保校验
        if(service.openRenewal()){
            validateRenewal(uwOrderDto);
        }

        //保存账单
        try {
            log.debug("保存账单信息--------------");
            for(BillDto billDto:billDtoList){
                service.saveBill(billDto);
            }
            log.info("保存投保人手机号--------------");//转换阿里通讯号后，核保时不传holder.extendinfos.extendinfo.phone，调整到出单时传
            Map<String, String> extendInfos = request.getBody().getHolder().getExtendInfos();
            String phone = extendInfos.get(Const.CustomerExtendInfoKey.phone.value);
            service.updateHolder(uwOrderDto.getOrder_no(), extendInfos.toString(), phone);
        } catch (Exception e) {
            if(e instanceof AntException)
                throw (AntException)e;
            e.printStackTrace();
            log.error("saveBill error "+e);
            throw new AntException("1000",e.toString());
        }
        
        //出单
        try {
            final String orderNo = uwOrderDto.getOrder_no();
            final CyclicBarrier barrier = new CyclicBarrier(2, new Thread() {
                    @Override
                    public void run() {
                    }
                });
            executor.execute(new IssueThread(barrier,orderNo,service));//独立线程跑出单
            try {
                barrier.await(Config.getInstance().getTimeOut(), TimeUnit.MILLISECONDS); //出单时间过长，先返回出单中
            }catch (Exception te) {
                log.error("issue time longer than "+Config.getInstance().getTimeOut());  
            } 
            OrderDto repOrderDto = service.findOrder(request.getBody().getPolicy().getOrder_no());
            finishIssue(rep,repOrderDto);
        } catch (Exception e) {
            if(e instanceof AntException)
                throw (AntException)e;
            e.printStackTrace();
            log.error("issue order_no:"+uwOrderDto.getOrder_no());
            log.error("issue error "+e);
            throw new AntException("1000",e.toString());
        }
        
        return rep;
    }
    
    class IssueThread extends Thread{
            private CyclicBarrier barrier;
            private String orderNo;
            private AntService service;
            public IssueThread(CyclicBarrier barrier,String orderNo,AntService service) {
                this.barrier = barrier;
                this.orderNo = orderNo;
                this.service = service;
            }
     
            @Override
            public void run() {
                try {
                    log.debug("出单中--------------");
                    OrderDto orderDto = service.findOrderByOrderNo(orderNo);
                    if(service.isHomePlan(orderDto.getOut_product_code(), orderDto.getEffectstarttime())){
                        log.info("家财险，调标准接口出单--------------");
                        Integer contractId = service.issueHome(orderNo);
                        //发短信给投保人
                        if(contractId != null && contractId > 0){
                            log.debug("发短信给投保人--------------");
                            String holderMobile = service.getHolderMobile(orderNo);
                            String policyNo = service.getPolicyNo(orderNo);
                            String policy_url = getPolidyDownloadUrl(policyNo);
                            addSmsSchedule(holderMobile,policyNo,policy_url);
                        }
                    }else{
                        final Integer contractId = service.issue(orderNo);
                        //发短信给投保人
                        if(contractId != null && contractId > 0){
                            log.debug("发短信给投保人--------------");
                            String holderMobile = service.getHolderMobile(orderNo);
                            String policyNo = service.getPolicyNo(orderNo);
                            String policy_url = getPolidyDownloadUrl(policyNo);
                            addSmsSchedule(holderMobile,policyNo,policy_url);
                        }
                        if(contractId != -1){//为-1标识调用的核心出单核激活接口
                            //异步做settlement
                            executor.execute(new Thread(new Runnable(){  
                               public void run() {
                                       try {
                                           Integer result = service.doSettlement(contractId);
                                           if(2!=result)
                                               throw new Exception();
                                       } catch (Exception e) {
                                           log.error("doSettlement error "+e);
                                       }
                                   }}));
                        }
                    }
                    barrier.await();
                } catch (Exception e) {
                    log.error("出单时间过长");
                }
            }
    }
    
    private String getPolidyDownloadUrl(String policy_ref){
        log.debug("getPolidyDownloadUrl policy_ref="+policy_ref);
        String policyDownloadUrl = "";
        String aesPolicyNo = "";
        try {
            if(Beans.isNotEmpty(policy_ref))
                aesPolicyNo = EncodeUtil.aesEncrypt(policy_ref, Const.AES_KEY);//aes加密的key，解密也要用这个key
        } catch (Exception e) {
            log.debug("aes加密出错");                     
        }finally{
            if(Beans.isNotEmpty(policy_ref))
                policyDownloadUrl =Config.getInstance().getPolicyDownloadUrl()+ "?policyNo="+aesPolicyNo;
        }
        return policyDownloadUrl;    
    }
    
    private void finishIssue(CommonResponse rep,OrderDto orderDto) {
        final String policy_url = getPolidyDownloadUrl(orderDto.getPolicy_ref());
        log.debug("policy "+orderDto.getPolicy_ref()+" download url is: "+policy_url);
        orderDto.setPolicy_url(policy_url);
        
        CommonResponseBody body = new CommonResponseBody();
        if(Const.AntOrderStatus.IssueSuccess.value==orderDto.getStatus()&&Const.TRUE.equals(orderDto.getIs_issue_success())){
            body.setIs_success(Const.TRUE);
            body.setError_message(Const.allianzErrorMap.get("0000"));
            body.setErrorcode("0000");
            body.setOrder_no(orderDto.getOrder_no());
            body.setOutPolicyNo(orderDto.getPolicy_ref());
            body.setPolicyUrl(orderDto.getPolicy_url());
            //body.setNextContinuousTime(orderDto.getNext_continuous_time());
        }else if(Const.AntOrderStatus.UWSuccess.value==orderDto.getStatus() || Const.AntOrderStatus.WaitIssue.value==orderDto.getStatus()){
            body.setIs_success(Const.FALSE);
            body.setError_message(Const.allianzErrorMap.get("1300"));
            body.setErrorcode("1300");
            body.setOrder_no(orderDto.getOrder_no());
            body.setOutPolicyNo("");    
            body.setPolicyUrl("");
        }else{
            body.setIs_success(Const.FALSE);
            body.setError_message(Const.allianzErrorMap.get("1016")+"errorcode-"+orderDto.getStatus());
            body.setErrorcode("1016");
            body.setOrder_no(orderDto.getOrder_no());
            body.setOutPolicyNo("");    
            body.setPolicyUrl("");
        }
        
        rep.setBody(body);
    }
    
    private void addSmsSchedule(String holderMobile,String policyNo,String policy_url){
        log.debug("addSmsSchedule holderMobile="+holderMobile+" policy_url="+policy_url);
        String smsModel = Config.getInstance().getSmsModel();
        String value = policyNo+"%%"+policy_url;
        String modelContent = "";
        if(Beans.isNotEmpty(smsModel)){//模版不为空，则以模版发送
            modelContent = smsModel;
            if(Beans.isNotEmpty(value)){
                String[] values = value.split("%%");
                for(String s : values){
                    modelContent=modelContent.replaceFirst("%s", s);   
                }
            }
        }else{
            modelContent = value;//模版为空，直接发送内容
        } 
        service.addSmsSchedule(holderMobile,modelContent);
    }

    private void validateUWOrder(OrderDto orderDto,String orderNo) throws AntException {
        if (Beans.isEmpty(orderDto.getOrder_no())) { //如果订单不存在，抛异常
            log.error("can not find order:"+orderNo);
            throw new AntException("1009");
        }
        if (Const.UnderWriteStatus.success.value != orderDto.getUnderwrite_flag()) { //如果订单不是已核保状态，抛异常
            log.error("can not find order:"+orderNo);
            throw new AntException("1010");
        }
        
    }
    
    private void validateRequest(List<BillDto> billDtoList,OrderDto orderDto) throws AntException {
        for(BillDto billDto:billDtoList){
            if(Beans.isEmpty(billDto.getFee()))
                throw new AntException("1109"); 
            if(!AccountType.alipay.value.equals(billDto.getMerchantaccounttype()))
                throw new AntException("1017");
//            if(Config.getInstance().getAccountID().equals(billDto.getMerchantaccountid()))
//                throw new AntException("1018");//不校验机构支付宝账号
            if(billDto.getFee().compareTo(orderDto.getPremium())!=0)
                throw new AntException("1012");
            if(billDto.getPaytime().after(orderDto.getEffectstarttime()))
                throw new AntException("1019");
            if(new Date().after(orderDto.getEffectstarttime()))
                throw new AntException("1013");
        }
    }
    
    /**
     * 续保校验
     * 触发校验条件： 1-续保 + 续保单号非空
     */
    private void validateRenewal(OrderDto orderDto) throws AntException {
        log.info("validateRenewal for inssue...order_no: " +  orderDto.getOrder_no());
        if(Const.IsRenewal.Renewal.value.equals(orderDto.getIs_renewal()) && Beans.isNotEmpty(orderDto.getOld_out_policy_no())){
            //获取原保单信息
            PolicyInfoVo policyInfo = service.getPolicyInfoByPolicyNo(orderDto.getOld_out_policy_no());
            //没有原保单记录
            if(Beans.isEmpty(policyInfo)){
                throw new AntException("2001");
            }
            //原保单是否生效状态
            if(!Const.PolicyStatus.InForce.value.equals(policyInfo.getPolicyStatus())){
                throw new AntException("2004");
            }
            //续保宽限期(在宽限期内进行投保即可)
            if(Beans.isNotEmpty(policyInfo.getRenewableGracePeriod()) && DateUtil.addDay(policyInfo.getExpireDate(), policyInfo.getRenewableGracePeriod()).compareTo(new Date()) < 0 ){
                throw new AntException("2005");
            }
            //原保单已续保
            if(Beans.isNotEmpty(service.getOldContractStatus(policyInfo.getContractId()))){
                throw new AntException("2007");
            }
            
        }
    }
    //特殊计划的投保次数校验(成功出单，不看承保区间，只针对该接口出的单)
    private void validateLimitTimes(String outProductCode, String holderCertno) throws AntException {
        if(service.overLimitTimes(outProductCode, holderCertno)){
            throw new AntException("9901");
        }
    }
    
    //一些公共的业务逻辑校验        
    private void validateCommonLimit(OrderDto orderDto, HolderDto holderDto, List<InsuredDto> insuredDtoList, PlanInfoDto planinfo) throws AntException {
        String returnCode = service.validateCommonLimit(orderDto, holderDto, insuredDtoList, planinfo);
        //超过投保次数
        if("overTimeLimit".equals(returnCode)){
            throw new AntException("1023");
        }else if("overInsurantTimeLimit".equals(returnCode)){
            throw new AntException("1024");
        }
    }

}

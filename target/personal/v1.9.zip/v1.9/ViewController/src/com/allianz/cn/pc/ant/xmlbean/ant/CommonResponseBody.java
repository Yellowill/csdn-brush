package com.allianz.cn.pc.ant.xmlbean.ant;


import com.allianz.cn.pc.ant.utils.AntDateConverter;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamConverter;

import java.util.Date;
import java.util.Map;

@XStreamAlias("body")
public class CommonResponseBody {

    @XStreamAlias("success")
    private String is_success;
    @XStreamAlias("errorCode")
    private String errorcode;
    @XStreamAlias("errorMessage")
    private String error_message;
    @XStreamAlias("policyNo")
    private String order_no;
    @XStreamAlias("policyUrl")
    private String policyUrl;
    
    @XStreamAlias("proposalNo")
    private String proposalNo;
    
    @XStreamAlias("outPolicyNo")
    private String outPolicyNo;
    
    @XStreamConverter(value=AntDateConverter.class)
    @XStreamAlias("nextContinuousTime")
    private Date nextContinuousTime;
    
    //批单body内容返回
    @XStreamAlias("instEndorsementNo")
    private String instEndorsementNo;
    
    @XStreamAlias("resultCode")
    private String resultCode;
    
    @XStreamAlias("resultDesc")
    private String resultDesc;
    
    @XStreamAlias("resultStatus")
    private String resultStatus;
    
    @XStreamAlias("instBizInfo")
    private Object instBizInfo ;//文档报文内是object 　
    
    @XStreamAlias("instSerialNo")
    private String instSerialNo;

    public void setIs_success(String is_success) {
        this.is_success = is_success;
    }

    public String getIs_success() {
        return is_success;
    }

    public void setErrorcode(String errorcode) {
        this.errorcode = errorcode;
    }

    public String getErrorcode() {
        return errorcode;
    }

    public void setError_message(String error_message) {
        this.error_message = error_message;
    }

    public String getError_message() {
        return error_message;
    }

    public void setOrder_no(String order_no) {
        this.order_no = order_no;
    }

    public String getOrder_no() {
        return order_no;
    }
    
    public void setPolicyUrl(String policyUrl) {
        this.policyUrl = policyUrl;
    }

    public String getPolicyUrl() {
        return policyUrl;
    }

    public void setProposalNo(String proposalNo) {
        this.proposalNo = proposalNo;
    }

    public String getProposalNo() {
        return proposalNo;
    }

    public void setOutPolicyNo(String outPolicyNo) {
        this.outPolicyNo = outPolicyNo;
    }

    public String getOutPolicyNo() {
        return outPolicyNo;
    }

    public void setNextContinuousTime(Date nextContinuousTime) {
        this.nextContinuousTime = nextContinuousTime;
    }

    public Date getNextContinuousTime() {
        return nextContinuousTime;
    }

    public void setInstEndorsementNo(String instEndorsementNo) {
        this.instEndorsementNo = instEndorsementNo;
    }

    public String getInstEndorsementNo() {
        return instEndorsementNo;
    }

    public void setResultCode(String resultCode) {
        this.resultCode = resultCode;
    }

    public String getResultCode() {
        return resultCode;
    }

    public void setResultDesc(String resultDesc) {
        this.resultDesc = resultDesc;
    }

    public String getResultDesc() {
        return resultDesc;
    }

    public void setResultStatus(String resultStatus) {
        this.resultStatus = resultStatus;
    }

    public String getResultStatus() {
        return resultStatus;
    }

    public void setInstBizInfo(Object instBizInfo) {
        this.instBizInfo = instBizInfo;
    }

    public Object getInstBizInfo() {
        return instBizInfo;
    }

    public void setInstSerialNo(String instSerialNo) {
        this.instSerialNo = instSerialNo;
    }

    public String getInstSerialNo() {
        return instSerialNo;
    }
}


package com.allianz.cn.pc.ant.xmlbean.ant.policyconfirm.request;

import com.thoughtworks.xstream.annotations.XStreamAlias;

public class InsEndorsementItem {
    
    @XStreamAlias("endorseNo")
    private String endorseNo;
    
    @XStreamAlias("endorseItemNo")
    private String endorseItemNo;
    
    @XStreamAlias("type")
    private String type;
    
    @XStreamAlias("oldValue")
    private EndorsementJson oldValue;
    
    @XStreamAlias("newValue")
    private EndorsementJson newValue;
    
    @XStreamAlias("fee")
    private Long fee;

    public void setEndorseNo(String endorseNo) {
        this.endorseNo = endorseNo;
    }

    public String getEndorseNo() {
        return endorseNo;
    }

    public void setEndorseItemNo(String endorseItemNo) {
        this.endorseItemNo = endorseItemNo;
    }

    public String getEndorseItemNo() {
        return endorseItemNo;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getType() {
        return type;
    }

    public void setOldValue(EndorsementJson oldValue) {
        this.oldValue = oldValue;
    }

    public EndorsementJson getOldValue() {
        return oldValue;
    }

    public void setNewValue(EndorsementJson newValue) {
        this.newValue = newValue;
    }

    public EndorsementJson getNewValue() {
        return newValue;
    }

    public void setFee(Long fee) {
        this.fee = fee;
    }

    public Long getFee() {
        return fee;
    }
}

package com.allianz.cn.pc.ant.utils;


import java.sql.Timestamp;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.StringTokenizer;


public class DateUtil {
    public DateUtil() {
        super();
    }

    //一天的毫秒数
    private static long millionSecondsOfDay = 86400000;
    private static String defaultDateFormatParthen = "yyyyMMddHHmmssSSS";
    private static ThreadLocal<DateFormat> defaultDateFormatTL = new ThreadLocal<DateFormat>();

    //-----------------------------------------转换 begin---------------------------------------------

    public static Date stringToDate(String date) {
        if (date == null || "".equalsIgnoreCase(date))
            return null;

        Calendar cd = Calendar.getInstance();
        StringTokenizer token = new StringTokenizer(date, "-/ :.");
        if (token.hasMoreTokens()) {
            cd.set(Calendar.YEAR, Integer.parseInt(token.nextToken()));
        } else {
            cd.set(Calendar.YEAR, 1970);
        }
        if (token.hasMoreTokens()) {
            cd.set(Calendar.MONTH, Integer.parseInt(token.nextToken()) - 1);
        } else {
            cd.set(Calendar.MONTH, 0);
        }
        if (token.hasMoreTokens()) {
            cd.set(Calendar.DAY_OF_MONTH, Integer.parseInt(token.nextToken()));
        } else {
            cd.set(Calendar.DAY_OF_MONTH, 1);
        }
        if (token.hasMoreTokens()) {
            cd.set(Calendar.HOUR_OF_DAY, Integer.parseInt(token.nextToken()));
        } else {
            cd.set(Calendar.HOUR_OF_DAY, 0);
        }
        if (token.hasMoreTokens()) {
            cd.set(Calendar.MINUTE, Integer.parseInt(token.nextToken()));
        } else {
            cd.set(Calendar.MINUTE, 0);
        }
        if (token.hasMoreTokens()) {
            cd.set(Calendar.SECOND, Integer.parseInt(token.nextToken()));
        } else {
            cd.set(Calendar.SECOND, 0);
        }
        if (token.hasMoreTokens()) {
            cd.set(Calendar.MILLISECOND, Integer.parseInt(token.nextToken()));
        } else {
            cd.set(Calendar.MILLISECOND, 0);
        }

        return cd.getTime();
    }
    
    /**
     * 将任何带有阿拉伯数字时间格式且时间按照年月日时分秒毫秒方式排序（不求全，但至少有年月日）的对象转换为日期对象
     * @param o 带时间信息的对象
     * @return
     */
    public static Date toDate(Object o) {
        if (o == null) {
            return null;
        }
        if (o instanceof Date) {
            return new Date(((Date)o).getTime());
        }
        String s = o.toString();
        s = s.replaceAll("\\D", "");
        if (s.length() < 8) {
            return null;
        }
        if (s.length() < defaultDateFormatParthen.length()) {
            StringBuilder sb = new StringBuilder(defaultDateFormatParthen.length());
            sb.append(s);
            while (sb.length() < defaultDateFormatParthen.length()) {
                sb.append('0');
            }
            s = sb.toString();
        } else {
            s = s.substring(0, defaultDateFormatParthen.length());
        }
        try {
            DateFormat defaultDateFormat = defaultDateFormatTL.get();
            if (defaultDateFormat == null) {
                defaultDateFormat = new SimpleDateFormat(defaultDateFormatParthen);
                defaultDateFormatTL.set(defaultDateFormat);
            }
            return defaultDateFormat.parse(s);
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * 字符串转日期，不支持毫秒
     * @param sDate
     * @param format
     * @return
     * @throws Exception
     */
    public static Date stringToDate(String sDate, String format){
        Date resDate = new Date();
        try {
            if (sDate == null || sDate.equals("")) {
                return null;
            }

            SimpleDateFormat simDateFormat = new SimpleDateFormat(format);
            resDate = simDateFormat.parse(sDate);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
        return resDate;
    }

    /**
     * 日期转字符串，不支持毫秒
     * @param dDate
     * @param format
     * @return
     * @throws Exception
     */
    public static String DateToString(Date dDate, String format) {
        String resString = "";
        String sDay = "";
        try {

            SimpleDateFormat simDateFormat = new SimpleDateFormat(format);
            resString = simDateFormat.format(dDate);
        } catch (Exception e) {
            return resString;
        }
        return resString;
    }

    /**
     * @param date
     * @return
     */
    public static java.sql.Date convertUtilDateToSQLDate(java.util.Date date) {
        if (date == null)
            return null;
        Calendar cl = Calendar.getInstance();

        cl.setTime(date);
        java.sql.Date jd = new java.sql.Date(cl.getTimeInMillis());
        return jd;
    }


    /**
     * @param date
     * @return
     */
    public static Timestamp convertUtilDateToTimestamp(java.util.Date date) {
        if (date == null)
            return null;
        Calendar cl = Calendar.getInstance();

        cl.setTime(date);
        Timestamp jd = new Timestamp(cl.getTimeInMillis());
        return jd;
    }

    /**
     * @param date
     * @return
     */
    public static java.util.Date convertSQLDateToUtilDate(java.sql.Date date) {
        if (date == null)
            return null;
        Calendar cl = Calendar.getInstance();

        cl.setTime(date);
        java.util.Date jd = new java.util.Date(cl.getTimeInMillis());
        return jd;
    }

    /**
     * 格式化日期
     *
     * @author Vincent
     * @param date
     * @param formater
     * @return
     */
    public static Date formatDate(Date date, String formater){
        String dateString = DateToString(date, "yyyyMMddHHmmss");
        String formatString = dateString.substring(0, formater.length());
        SimpleDateFormat sdf = new SimpleDateFormat(formater);
        Date result = null;
        try {
            result = sdf.parse(formatString.trim());
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return result;
    }
    //-----------------------------------------转换 end---------------------------------------------


    //-----------------------------------------获取 begin---------------------------------------------

    /**
     * 获取当月第一天
     * @param date
     * @return
     */
    public static Date getFirstDateOfMonth(Date date) {
        Calendar cl = Calendar.getInstance();
        cl.setTime(date);
        cl.set(Calendar.DAY_OF_MONTH, 1);
        return cl.getTime();
    }


    /**
     * 获取当月最后一天
     * @param date
     * @return
     */
    public static Date getLastDateOfMonth(Date date) {
        Calendar cl = Calendar.getInstance();
        cl.setTime(date);
        cl.add(Calendar.MONTH, 1);
        cl.set(Calendar.DAY_OF_MONTH, 1);
        cl.add(Calendar.DAY_OF_MONTH, -1);
        return cl.getTime();
    }

    /**
     * 获取当前时间做加减后的时间
     * @param type
     * @param value
     * @return
     */
    public static Date getDateTimeBeforeOrAfter(Date date, int type, int value) {
        Calendar cl = Calendar.getInstance();
        cl.setTime(date);
        cl.add(type, value);
        
        return cl.getTime();
    }

    /**
     * 得到两个日期之间的天数,清空时分秒再计算
     *
     * @author Vincent
     * @param date1
     * @param date2
     * @return
     */
    public static int getBetweenDay(Date date1, Date date2) {
        Date d1_format = formatDate(date1, "yyyyMMdd");
        Date d2_format = formatDate(date2, "yyyyMMdd");
        Long d1 = d1_format.getTime();
        Long d2 = d2_format.getTime();
        return (int)((d2 - d1) / millionSecondsOfDay);
    }

    /**
     * 根据日期取出是星期几
     *
     * @author Vincent
     * @param date
     *            Date
     * @return int 返回1-7
     */
    public static int getWeekOfDate(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        return (calendar.get(Calendar.DAY_OF_WEEK) - 1) == 0 ? 7 : calendar.get(Calendar.DAY_OF_WEEK) - 1;
    }
    
    public static Date getBirthdayFromIDCard(String cardNo) {
        String birthday = cardNo.substring(6, 14);
        return DateUtil.stringToDate(birthday, "yyyyMMdd");
    }
    
    public static Date addDay(Date date, int days) {
        Calendar c = new GregorianCalendar();
        c.setTime(date);
        c.add(Calendar.DAY_OF_MONTH, days);
        return c.getTime();
    }

    //-----------------------------------------获取 end---------------------------------------------

    //-----------------------------------------计算 begin---------------------------------------------

    /**
     * 是否闰年
     * @param year
     * @return
     */
    public static boolean isLeapYear(int year) {

        if ((year % 400) == 0)
            return true;
        else if ((year % 4) == 0) {
            if ((year % 100) == 0)
                return false;
            else
                return true;
        } else
            return false;
    }
    
    /** 计算年龄 */
    public static Integer getAge(Date birthDay,Date startDate){
        Calendar cal = Calendar.getInstance();

        cal.setTime(startDate);
        int beginYear = cal.get(Calendar.YEAR);
        int beginMonth = cal.get(Calendar.MONTH) + 1;
        int beginDayOfMonth = cal.get(Calendar.DAY_OF_MONTH);

        cal.setTime(birthDay);
        int birthYear = cal.get(Calendar.YEAR);
        int birthMonth = cal.get(Calendar.MONTH)+1;
        int birthday = cal.get(Calendar.DAY_OF_MONTH);

        int age = beginYear - birthYear;

        if (beginMonth <= birthMonth) {
            if (beginMonth == birthMonth) {
                if ( birthday > beginDayOfMonth) {
                    age-=1;
                }
            } else {
                age-=1;
            }
        }

        return age;
    }
    
    //-----------------------------------------判断 end---------------------------------------------
    /**
     *判断时间是否同天（忽略时分秒）
     * @param dt1
     * @param dt2
     * @return
     */
    public static Boolean sameDate(Date dt1 , Date dt2 ){
        SimpleDateFormat fmt = new SimpleDateFormat("yyyyMMdd");
                        //fmt.setTimeZone(new TimeZone()); // 如果需要设置时间区域，可以在这里设置
        return fmt.format(dt1).equals(fmt.format(dt2));
    }
}

package com.allianz.cn.pc.ant.xmlbean.sms;




import com.thoughtworks.xstream.annotations.XStreamAlias;

import java.io.Serializable;


@XStreamAlias("Request")
public class SmsRequest implements Serializable{

    @XStreamAlias("Origin")
    private String Origin;
    
    @XStreamAlias("MobileNo")
    private String mobileNo;
    
    @XStreamAlias("Value")
    private String value;
    
    @XStreamAlias("Model")
    private String model;


    public void setOrigin(String Origin) {
        this.Origin = Origin;
    }

    public String getOrigin() {
        return Origin;
    }

    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }

    public String getMobileNo() {
        return mobileNo;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getModel() {
        return model;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}

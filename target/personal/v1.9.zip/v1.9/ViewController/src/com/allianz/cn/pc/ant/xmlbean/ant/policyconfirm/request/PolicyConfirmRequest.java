package com.allianz.cn.pc.ant.xmlbean.ant.policyconfirm.request;


import com.allianz.cn.pc.ant.xmlbean.ant.CommonHeader;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("request")
public class PolicyConfirmRequest {
    
    @XStreamAlias("head")
    private CommonHeader head = new CommonHeader();
    
    @XStreamAlias("body")
    private PolicyConfirmRequestBody body = new PolicyConfirmRequestBody();

    public void setHead(CommonHeader head) {
        this.head = head;
    }

    public CommonHeader getHead() {
        return head;
    }

    public void setBody(PolicyConfirmRequestBody body) {
        this.body = body;
    }

    public PolicyConfirmRequestBody getBody() {
        return body;
    }
}

package com.allianz.cn.pc.ant.xmlbean.ant;


import com.allianz.cn.pc.ant.utils.AntDateConverter;

import com.allianz.oti.common.util.xstream.AllianzDateConverter;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamConverter;

import java.util.Date;

@XStreamAlias("head")
public class CommonHeader {
    
    @XStreamAlias("version")
    private String version_no;
    @XStreamAlias("function")
    private String function_code;
    @XStreamConverter(value=AntDateConverter.class)
    @XStreamAlias("transTime")
//    @XStreamConverter(value=AllianzDateConverter.class)
    private Date transtime;
    @XStreamAlias("transTimeZone")
    private String transtimezone;
    @XStreamAlias("reqMsgId")
    private String reqmsgid;
    @XStreamAlias("format")
    private String format;
    @XStreamAlias("signType")
    private String sign_type;
    @XStreamAlias("asyn")
    private String asyn;
    @XStreamAlias("cid")
    private String cid;

    public void setVersion_no(String version_no) {
        this.version_no = version_no;
    }

    public String getVersion_no() {
        return version_no;
    }

    public void setFunction_code(String function_code) {
        this.function_code = function_code;
    }

    public String getFunction_code() {
        return function_code;
    }

    public void setTranstime(Date transtime) {
        this.transtime = transtime;
    }

    public Date getTranstime() {
        return transtime;
    }

    public void setTranstimezone(String transtimezone) {
        this.transtimezone = transtimezone;
    }

    public String getTranstimezone() {
        return transtimezone;
    }

    public void setReqmsgid(String reqmsgid) {
        this.reqmsgid = reqmsgid;
    }

    public String getReqmsgid() {
        return reqmsgid;
    }

    public void setFormat(String format) {
        this.format = format;
    }

    public String getFormat() {
        return format;
    }

    public void setSign_type(String sign_type) {
        this.sign_type = sign_type;
    }

    public String getSign_type() {
        return sign_type;
    }

    public void setAsyn(String asyn) {
        this.asyn = asyn;
    }

    public String getAsyn() {
        return asyn;
    }

    public void setCid(String cid) {
        this.cid = cid;
    }

    public String getCid() {
        return cid;
    }
}


package com.allianz.cn.pc.ant.xmlbean.ant.common;


import com.allianz.cn.pc.ant.utils.AllianzBigDecimalConverter;
import com.allianz.cn.pc.ant.utils.AntDateConverter;
import com.allianz.cn.pc.ant.utils.AntMapConverter;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamConverter;

import java.math.BigDecimal;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;


@XStreamAlias("policy")
public class Policy {
    @XStreamAlias("instId")
    private String instId;
    
    @XStreamAlias("policyNo")
    private String order_no;
    
    @XStreamAlias("outPolicyNo")
    private String outPolicyNo;
    
    @XStreamAlias("prodNo")
    private String product_code;
    
    @XStreamAlias("outProdNo")
    private String out_product_code;
    
    @XStreamAlias("comId")
    private String comId;
    
    @XStreamAlias("spNo")
    private String spNo;
   
    @XStreamAlias("summaryPolicyNo")
    private String summary_order_no;
    
    @XStreamAlias("policyType")
    private String policy_type;
    
    @XStreamConverter(value=AllianzBigDecimalConverter.class)
    @XStreamAlias("premium")
    private BigDecimal premium;
    
    @XStreamConverter(value=AllianzBigDecimalConverter.class)
    @XStreamAlias("actualPremium")
    private BigDecimal actual_premium;
    
    @XStreamConverter(value=AllianzBigDecimalConverter.class)
    @XStreamAlias("sumInsured")
    private BigDecimal sum_insured;
    
    @XStreamConverter(value=AntDateConverter.class)
    @XStreamAlias("insuredTime")
    private Date insuredtime;
    
    @XStreamConverter(value=AntDateConverter.class)
    @XStreamAlias("issueTime")
    private Date issuetime;
    
    @XStreamConverter(value=AntDateConverter.class)
    @XStreamAlias("effectStartTime")
    private Date effectstarttime;
    
    @XStreamConverter(value=AntDateConverter.class)
    @XStreamAlias("effectEndTime")
    private Date effectendtime;
    
    @XStreamAlias("applyNum")
    private Integer applynum;
    
    @XStreamConverter(value=AntMapConverter.class)
    @XStreamAlias("extendInfos")
    private Map<String,String> extendInfos=new HashMap<String,String>();


    public void setOrder_no(String order_no) {
        this.order_no = order_no;
    }

    public String getOrder_no() {
        return order_no;
    }

    public void setProduct_code(String product_code) {
        this.product_code = product_code;
    }

    public String getProduct_code() {
        return product_code;
    }

    public void setOut_product_code(String out_product_code) {
        this.out_product_code = out_product_code;
    }

    public String getOut_product_code() {
        return out_product_code;
    }

    public void setSummary_order_no(String summary_order_no) {
        this.summary_order_no = summary_order_no;
    }

    public String getSummary_order_no() {
        return summary_order_no;
    }

    public void setPolicy_type(String policy_type) {
        this.policy_type = policy_type;
    }

    public String getPolicy_type() {
        return policy_type;
    }

    public void setPremium(BigDecimal premium) {
        this.premium = premium;
    }

    public BigDecimal getPremium() {
        return premium;
    }

    public void setActual_premium(BigDecimal actual_premium) {
        this.actual_premium = actual_premium;
    }

    public BigDecimal getActual_premium() {
        return actual_premium;
    }

    public void setSum_insured(BigDecimal sum_insured) {
        this.sum_insured = sum_insured;
    }

    public BigDecimal getSum_insured() {
        return sum_insured;
    }

    public void setInsuredtime(Date insuredtime) {
        this.insuredtime = insuredtime;
    }

    public Date getInsuredtime() {
        return insuredtime;
    }

    public void setIssuetime(Date issuetime) {
        this.issuetime = issuetime;
    }

    public Date getIssuetime() {
        return issuetime;
    }

    public void setEffectstarttime(Date effectstarttime) {
        this.effectstarttime = effectstarttime;
    }

    public Date getEffectstarttime() {
        return effectstarttime;
    }

    public void setEffectendtime(Date effectendtime) {
        this.effectendtime = effectendtime;
    }

    public Date getEffectendtime() {
        return effectendtime;
    }

    public void setApplynum(Integer applynum) {
        this.applynum = applynum;
    }

    public Integer getApplynum() {
        return applynum;
    }

    public void setExtendInfos(Map<String, String> extendInfos) {
        this.extendInfos = extendInfos;
    }

    public Map<String, String> getExtendInfos() {
        return extendInfos;
    }

    public void setInstId(String instId) {
        this.instId = instId;
    }

    public String getInstId() {
        return instId;
    }

    public void setOutPolicyNo(String outPolicyNo) {
        this.outPolicyNo = outPolicyNo;
    }

    public String getOutPolicyNo() {
        return outPolicyNo;
    }

    public void setComId(String comId) {
        this.comId = comId;
    }

    public String getComId() {
        return comId;
    }

    public void setSpNo(String spNo) {
        this.spNo = spNo;
    }

    public String getSpNo() {
        return spNo;
    }
}


package com.allianz.cn.pc.ant.exceptions;

public class AntException extends Exception{
    private String errCode;
    private String errMsg;
  
    public AntException() {
        super();
    }
    
    public AntException(String code) {
        errCode = code;
    }
    
    public AntException(String code,String message) {
        errCode = code;
        errMsg = message;
    }
    
    public AntException(Throwable cause) {
        super(cause);
    }

    public void setErrMsg(String errMsg) {
        this.errMsg = errMsg;
    }

    public String getErrMsg() {
        return errMsg;
    }

    public void setErrCode(String errCode) {
        this.errCode = errCode;
    }

    public String getErrCode() {
        return errCode;
    }
}

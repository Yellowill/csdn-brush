
package com.allianz.cn.pc.ant.servlet;


import com.allianz.cn.pc.ant.Const;
import com.allianz.cn.pc.ant.Const.AntOrderStatus;
import com.allianz.cn.pc.ant.action.CommonAction;
import com.allianz.cn.pc.ant.action.EndorsementCancelAction;
import com.allianz.cn.pc.ant.action.PolicyConfirmAction;
import com.allianz.cn.pc.ant.action.UnderWriteAction;
import com.allianz.cn.pc.ant.dto.AntTransDto;
import com.allianz.cn.pc.ant.exceptions.AntException;
import com.allianz.cn.pc.ant.services.AntService;
import com.allianz.cn.pc.ant.services.Config;
import com.allianz.cn.pc.ant.services.impl.AntJDBCServiceImpl;
import com.allianz.cn.pc.ant.utils.BusinessUtil;
import com.allianz.cn.pc.ant.utils.RsaSignatureUtil;
import com.allianz.cn.pc.ant.xmlbean.ant.CommonHeader;
import com.allianz.cn.pc.ant.xmlbean.ant.CommonResponse;
import com.allianz.cn.pc.ant.xmlbean.ant.CommonResponseBody;
import com.allianz.cn.pc.ant.xmlbean.ant.DocumentNode;
import com.allianz.cn.pc.ant.xmlbean.ant.policyconfirm.request.PolicyConfirmRequest;
import com.allianz.cn.pc.ant.xmlbean.ant.policyconfirm.request.PolicyEndorsementRequest;
import com.allianz.cn.pc.ant.xmlbean.ant.policyconfirm.request.PolicyEndorsementRequestBody;
import com.allianz.cn.pc.common.model.bean.InterfaceLogBean;
import com.allianz.cn.pc.common.model.bean.XmlResponse;
import com.allianz.cn.pc.utils.Beans;
import com.allianz.cn.pc.utils.XmlUtil;

import java.io.IOException;
import java.io.PrintWriter;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import org.omg.IOP.Encoding;


public class AntServlet extends HttpServlet {
    static Logger log = Logger.getLogger(AntServlet.class);
    public final static String UTF8 = "utf-8";
    public final static String GBK = "gbk";
    protected AntService service = AntJDBCServiceImpl.getNewInstance();
    
    private static Map<String, Class> RequestTypeMap = new HashMap() {
        {
            put(Const.FUNCTION_CODE_UNDERWRITE, PolicyConfirmRequest.class);
            put(Const.FUNCTION_CODE_POLICYCONFIRM, PolicyConfirmRequest.class);
        }
    };
    
    private static Map<String, Class> ActionTypeMap = new HashMap() {
        {
            put(Const.FUNCTION_CODE_UNDERWRITE, UnderWriteAction.class);
            put(Const.FUNCTION_CODE_POLICYCONFIRM, PolicyConfirmAction.class);
//            put(Const.FUNCTION_CODE_ENDORSEMENT, EndorsementCancelAction.class);
        }
    };

    public void init(ServletConfig config) throws ServletException {
        super.init(config);
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setCharacterEncoding(GBK);
        PrintWriter out = response.getWriter();
        log.error("Error request type");
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding(UTF8);
        response.setCharacterEncoding(UTF8);
        response.setContentType("application/xml;charset=utf-8");

        PrintWriter out = response.getWriter();
        
        DocumentNode document = new DocumentNode();
        CommonResponse rep = new CommonResponse();
        String sinature = null;
        String headXml = null;
        String bodyXml = null;
        CommonHeader head = null;
        AntTransDto transDto = new AntTransDto();
        String orderNo = null;
        boolean isChangeHeadFlag = false;//承保头部标签为<head>,退保头部标签为<header>
        Document doc = null;
        try {
            String baseString = IOUtils.toString(request.getInputStream(),UTF8);
            log.debug("request xml is \n" +baseString);
            if(baseString.indexOf("<header>") != -1){//存在<header>的即为退保，做标记并替换
                isChangeHeadFlag = true;
                baseString = baseString.replace("<header>", "<head>");//替换退保的标签使逻辑可以正常
                baseString = baseString.replace("</header>", "</head>");
            }
            SAXReader reader = new SAXReader();
            reader.setEncoding(GBK);
            
            doc = reader.read(IOUtils.toInputStream(baseString),GBK);
            Element root = doc.getRootElement();
            
            //获取RSA加密串
            Element signatureNode = root.element("signature");
            String signatureStr = null;
            if(null != signatureNode)
                signatureStr = signatureNode.getText().trim();
            
            //获取请求报文头和报文体
            Element requestNode = root.element("request");
            if(null != requestNode){
                headXml = requestNode.element("head").asXML();
                bodyXml = requestNode.element("body").asXML();
            }
            head = XmlUtil.fromXml(CommonHeader.class, headXml);
            //获取返回报文头
            rep.setHead(head);
            
            //校验RSA加密内容
            String requestStr = baseString.substring(baseString.indexOf("<request>"),baseString.indexOf("</request>"));
            if(isChangeHeadFlag){//若为退保则需要头部为<header>
                requestStr = requestStr.replace("<head>", "<header>");//替换退保的标签使逻辑可以正常
                requestStr = requestStr.replace("</head>", "</header>");
            }
            requestStr = requestStr.replace("<request>", "");
            if(null != requestStr){
                log.info("signatureStr----" + signatureStr);
                validateSinature(signatureStr,requestStr); //coffee test
            }
            //转换报文头
            Beans.copy(transDto, head);
            Element policyNo = requestNode.element("body").element("policy").element("policyNo");
            transDto.setOrder_no(policyNo.getText());
            transDto.setOrder_status(Const.AntOrderStatus.NoRecord.value);
            orderNo = policyNo.getText();
//            //校验请求唯一标示是否重复
//            validateHead(head);
////            
            //保存请求
//            saveTrans(transDto);
            
            //获取返回报文体
            CommonAction action = null;
            Class actionClazz = null;
            if(null != requestStr){
                actionClazz = ActionTypeMap.get(head.getFunction_code());
                action = (CommonAction)actionClazz.newInstance();
                long startTime = System.currentTimeMillis();
                CommonResponse temp = action.doProcess(requestNode);
                log.info("response cost "+(System.currentTimeMillis()-startTime));
                rep.setBody(temp.getBody());
            }
            //更新trans表
//            updateTrans(transDto, rep.getBody());
            
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            rep = BusinessUtil.createErrorResponse(head, e);
            //更新trans表
//            try {
//                updateTrans(transDto, rep.getBody());
//            } catch (Exception f) {
//                f.printStackTrace();
//                rep = BusinessUtil.createErrorResponse(head, f);
//            }
        }finally{
            String resXml = XmlUtil.toXml(rep,"utf-8");
            log.debug("###response xml is ### " + resXml);
            rep = BusinessUtil.convertAntError(rep, orderNo);
            bodyXml = XmlUtil.toXml(rep.getBody(),"utf-8");
            bodyXml = bodyXml.substring(bodyXml.indexOf("<body>"));
            if(isChangeHeadFlag){//若为退保则需要头部为<header>再进行加签
                headXml = headXml.replace("<head>", "<header>");
                headXml = headXml.replace("</head>", "</header>");
            }
            sinature = headXml+bodyXml;//需要加密的内容,将格式化为一行
            sinature = sinature.replaceAll("\\s+", " ");//所有换行和空白，都换成一个空白
            sinature = sinature.replace("> <", "><");//节点间的空白去掉
            sinature = RsaSignatureUtil.sign(sinature, Config.getInstance().getPrivateKey());//加密
            document.setSignature(sinature);
            document.setResponse(rep);
            resXml = XmlUtil.toXml(document,"utf-8");
            resXml = resXml.replaceAll("\\s+", " ");//所有换行和空白，都换成一个空白
            resXml = resXml.replace("> <", "><");//节点间的空白去掉
            log.debug("###response xml to ant is ### " + resXml);
            if(isChangeHeadFlag){//若为退保则需要头部为<header>
                resXml = resXml.replace("<head>", "<header>");
                resXml = resXml.replace("</head>", "</header>");
                log.debug("###cancel-response xml to ant is ### " + resXml);
            }
            if(Beans.isNotEmpty(resXml)){
                log.info("save-logs---start");
                saveAdfLogs(doc,request.getRequestURL().toString(),resXml);
            }
            out.print(resXml);
            out.close();
        }
        
    }
    private void saveAdfLogs(Document doc,String reqUrl,String respObj){
        try{
            String reqXml = doc.asXML();
            Element rootElement = doc.getRootElement();
            Element requestTypeEt = ((Element)rootElement.selectSingleNode("//function"));
            String requestType = Beans.isNotEmpty(requestTypeEt) ? requestTypeEt.getTextTrim() : "";
            Element planCodeEt = (Element)rootElement.selectSingleNode("//outProdNo");
            Element reqIdEt = (Element)rootElement.selectSingleNode("//policyNo");
            String planCode = Beans.isNotEmpty(planCodeEt) ? planCodeEt.getTextTrim() : "";
            String reqId = Beans.isNotEmpty(reqIdEt) ? reqIdEt.getTextTrim() : "";
            
            InterfaceLogBean logBean = new InterfaceLogBean();
            logBean.setRequestType(requestType);
            logBean.setTypeDesc("支付宝(蚂蚁)-定制化");
            logBean.setPlanCode(planCode);
            logBean.setPlanCode("<PlanCode>" + planCode + "</PlanCode>" );
            logBean.setRequsetId(reqId);
            logBean.setReqMessage(reqXml);
            logBean.setResMessage(respObj);
            logBean.setReqURL(reqUrl);
            service.commonSaveLog(logBean);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        }
        log.info("req-log-record-over");
    }
    private void updateTrans(AntTransDto transDto, CommonResponseBody repbody) throws Exception {
        Beans.copy(transDto, repbody);
        if(Const.FUNCTION_CODE_UNDERWRITE.equals(transDto.getFunction_code())){
            if(Beans.isNotEmpty(transDto.getErrorcode())||"0000".equals(transDto.getErrorcode()))
                transDto.setOrder_status(AntOrderStatus.UWSuccess.value);
            else
                transDto.setOrder_status(AntOrderStatus.UWFail.value);
        }
        if(Const.FUNCTION_CODE_POLICYCONFIRM.equals(transDto.getFunction_code())){
            if(Beans.isNotEmpty(transDto.getErrorcode())&&Beans.isNotEmpty(transDto.getPolicyNo()))
                transDto.setOrder_status(AntOrderStatus.IssueSuccess.value);
            else
                transDto.setOrder_status(AntOrderStatus.IssueFail.value);
        }
        CommonAction.updateTrans(transDto);
    }
    
    private void saveTrans(AntTransDto transDto) throws Exception {
        if(Const.FUNCTION_CODE_UNDERWRITE.equals(transDto.getFunction_code())){
            transDto.setOrder_status(AntOrderStatus.WaitUW.value);
        }
        if(Const.FUNCTION_CODE_POLICYCONFIRM.equals(transDto.getFunction_code())){
            transDto.setOrder_status(AntOrderStatus.WaitIssue.value);
        }
        CommonAction.saveTrans(transDto);
    }

    private void validateSinature(String sinature, String content) throws AntException {
        try {
            if(RsaSignatureUtil.verify(content, sinature, Config.getInstance().getPublicKey()))
                return;
        } catch (Exception e) {
            e.printStackTrace();
            log.error("validateSinature error sinature:"+sinature);
            e.printStackTrace();
        }
        throw new AntException("1200");
    }

    private void validateHead(CommonHeader head) throws AntException {
        if(!CommonAction.validateRequestId(head.getReqmsgid()))
            throw new AntException("1003");
        if(Beans.isEmpty(head.getFunction_code())||!Const.functionTypeList.contains(head.getFunction_code()))
            throw new AntException("1002");
    }

}

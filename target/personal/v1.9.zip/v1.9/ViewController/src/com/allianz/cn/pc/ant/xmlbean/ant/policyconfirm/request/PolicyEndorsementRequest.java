package com.allianz.cn.pc.ant.xmlbean.ant.policyconfirm.request;

import com.allianz.cn.pc.ant.xmlbean.ant.CommonHeader;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("request")
public class PolicyEndorsementRequest {
   
    @XStreamAlias("head")
    private CommonHeader head = new CommonHeader();
    
    @XStreamAlias("body")
    private PolicyEndorsementRequestBody body = new PolicyEndorsementRequestBody();

    public void setHead(CommonHeader head) {
        this.head = head;
    }

    public CommonHeader getHead() {
        return head;
    }

    public void setBody(PolicyEndorsementRequestBody body) {
        this.body = body;
    }

    public PolicyEndorsementRequestBody getBody() {
        return body;
    }
}

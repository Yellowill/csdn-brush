package com.allianz.cn.pc.ant.utils;


import com.allianz.cn.pc.ant.Const;
import com.allianz.cn.pc.ant.action.UnderWriteAction;
import com.allianz.cn.pc.ant.exceptions.AntException;
import com.allianz.cn.pc.ant.services.AntService;
import com.allianz.cn.pc.ant.services.impl.AntJDBCServiceImpl;
import com.allianz.cn.pc.ant.xmlbean.ant.CommonHeader;
import com.allianz.cn.pc.ant.xmlbean.ant.CommonResponse;
import com.allianz.cn.pc.ant.xmlbean.ant.CommonResponseBody;

import com.allianz.cn.pc.utils.Beans;

import java.util.ResourceBundle;

import org.apache.log4j.Logger;


public class BusinessUtil {
    
    static Logger logger = Logger.getLogger(BusinessUtil.class);
    private static AntService service = AntJDBCServiceImpl.getNewInstance();
    
    public static String getValueFromBundle(String key){
        ResourceBundle bundle = ResourceBundle.getBundle("com.allianz.eproductservice.i18n.Bundle");
        return bundle.getString(key);
    }
    
    public static String getValueFromBundle(String key,String... values){
        ResourceBundle bundle = ResourceBundle.getBundle("com.allianz.eproductservice.i18n.Bundle");
        if(values == null)
            return   bundle.getString(key);
        
        return String.format(bundle.getString(key), values);
    }
    
    public static String getMessageByKey(String key){
        ResourceBundle bundle = ResourceBundle.getBundle("com.allianz.eproductservice.model.ModelBundle");
        return bundle.getString(key);
    }
    
    public static String getMessageByKeyWithValues(String key,String... values){
        ResourceBundle bundle = ResourceBundle.getBundle("com.allianz.eproductservice.model.ModelBundle");
        if(values == null)
            return   bundle.getString(key);
        
        return String.format(bundle.getString(key), values);
    }
    
    /*--------------------------------------coffee add begin------------------------*/
    public static CommonResponse createErrorResponse( CommonHeader head,Exception e){
        CommonResponse response = new CommonResponse();
        response.setHead(head);
        //
        if(e instanceof AntException){
            setErrorCodeAndMsg(response, ((AntException)e));
        }else {
            setErrorCodeAndMsg(response, new AntException("1000","未知错误"));
        }
        
        return response;
    }
    
    public static void setErrorCodeAndMsg(CommonResponse rep,AntException e){
        CommonResponseBody body = new CommonResponseBody();
        if(Const.FUNCTION_CODE_ENDORSEMENT.equals(rep.getHead().getFunction_code())){
            body.setResultCode(Const.ResponseStatus.failCode.value);
            body.setResultDesc(e.getErrCode());
            body.setResultStatus(Const.ResponseStatus.fail.value);
            body.setInstBizInfo(new Object());//返回相关属性
        }
        body.setErrorcode(e.getErrCode());
        body.setIs_success(Const.FALSE);
        if("1000".equals(e.getErrCode()) || "1444".equals(e.getErrCode()))
            body.setError_message(e.getErrMsg());
        else
            body.setError_message(Const.allianzErrorMap.get(e.getErrCode()));
        body.setOrder_no("");
        
        if(Const.FUNCTION_CODE_POLICYCONFIRM.equals(rep.getHead().getFunction_code())){
            body.setPolicyUrl("");
            body.setOutPolicyNo("");
        }
        
        rep.setBody(body);
    }
    
    public static CommonResponse convertAntError(CommonResponse rep, String orderNo){
        if(Const.FUNCTION_CODE_ENDORSEMENT.equals(rep.getHead().getFunction_code())){
            if(Beans.isEmpty(rep.getBody().getErrorcode())){
                return rep;//退保不需要设置errorcode
            }
        }
        if(Const.FUNCTION_CODE_UNDERWRITE.equals(rep.getHead().getFunction_code())){
            //核保没有保单号
            rep.getBody().setOutPolicyNo(null);
            if("1000".equals(rep.getBody().getErrorcode())){
                //邮件报警    
                service.updateWarningMail("Ant Underwrite Error", rep.getBody().getOrder_no()+"--"+rep.getBody().getError_message());
            }
            if("1002".equals(rep.getBody().getErrorcode())){
                rep.getBody().setErrorcode("AE10316060001002");
                rep.getBody().setError_message(Const.antErrorMap.get("AE10316060001002"));
            }else if(rep.getBody().getErrorcode().startsWith("11")){
                rep.getBody().setErrorcode("AE10316060001004");
//                rep.getBody().setError_message(Const.antErrorMap.get("AE10316060001004"));//提示具体空字段
            }else if(rep.getBody().getErrorcode().startsWith("20")){
                //续保
                rep.getBody().setError_message(Const.allianzErrorMap.get(rep.getBody().getErrorcode()));
                rep.getBody().setErrorcode("AE10316060001005");
            }else if(rep.getBody().getErrorcode().startsWith("30")){
                //家财险
                rep.getBody().setErrorcode("AE10316060001005");
            }else{
                if("1000".equals(rep.getBody().getErrorcode()))
                    rep.getBody().setError_message(Const.allianzErrorMap.get("1000"));
                if("1444".equals(rep.getBody().getErrorcode())){
                    //不重写errorMessage-->保证指定message被返回
                }
                rep.getBody().setErrorcode("AE10316060001005");
            }
        }else{
            //出单没有投保单号
            rep.getBody().setProposalNo(null);
            if("1000".equals(rep.getBody().getErrorcode())){
                //邮件报警    
                service.updateWarningMail("Ant Issue Error", rep.getBody().getOrder_no()+"--"+rep.getBody().getError_message());
            }
            if("1002".equals(rep.getBody().getErrorcode())){
                rep.getBody().setErrorcode("AE10316060002002");
                rep.getBody().setError_message(Const.antErrorMap.get("AE10316060002002"));
            }else if("1300".equals(rep.getBody().getErrorcode())){
                rep.getBody().setErrorcode("AE10316060002001");
                rep.getBody().setError_message(Const.antErrorMap.get("AE10316060002001"));
            }else if(rep.getBody().getErrorcode().startsWith("11")){
                rep.getBody().setErrorcode("AE10316060002004");
                rep.getBody().setError_message(Const.antErrorMap.get("AE10316060002004"));
            }else if(rep.getBody().getErrorcode().startsWith("20")){
                //续保
                rep.getBody().setError_message(Const.allianzErrorMap.get(rep.getBody().getErrorcode()));
                rep.getBody().setErrorcode("AE10316060002005");
            }else{
                if("1009,1010".contains(rep.getBody().getErrorcode()))
                    rep.getBody().setError_message(Const.allianzErrorMap.get("1020"));
                if("1000,1016,1017".contains(rep.getBody().getErrorcode()))
                    rep.getBody().setError_message(Const.allianzErrorMap.get("1000"));
                if("1444".equals(rep.getBody().getErrorcode())){
                    //不重写errorMessage-->保证指定message被返回
                }
                rep.getBody().setErrorcode("AE10316060002005");
            }
        }
        if(Const.allianzErrorMap.get("0000").equals(rep.getBody().getError_message())){
            rep.getBody().setErrorcode("");
            rep.getBody().setError_message("");
        }
        //更新错误信息到order表中 Error_message: 成功(0000)清空错误信息； 系统错误(1000)保留原错误信息； 其他错误信息更新到表中
        if(!Const.allianzErrorMap.get("1000").equals(rep.getBody().getError_message())){
            service.updateErrorMsgToOrder(orderNo, rep.getBody().getError_message());
        }
        return rep;
    }
    
    /*--------------------------------------coffee add end------------------------*/
}


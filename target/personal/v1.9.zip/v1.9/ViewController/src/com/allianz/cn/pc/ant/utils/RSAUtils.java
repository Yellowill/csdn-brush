package com.allianz.cn.pc.ant.utils;


import java.math.BigInteger;

import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.RSAPrivateKeySpec;
import java.security.spec.RSAPublicKeySpec;

import java.util.HashMap;

import javax.crypto.Cipher;

import org.apache.commons.codec.binary.Base64;


public class RSAUtils {

    /**
     * 生成公钥和私钥
     * @throws NoSuchAlgorithmException
     *
     */
    private static HashMap<String, Object> getKeys() throws NoSuchAlgorithmException {
        HashMap<String, Object> map = new HashMap<String, Object>();
        KeyPairGenerator keyPairGen = KeyPairGenerator.getInstance("RSA");
        keyPairGen.initialize(1024);
        KeyPair keyPair = keyPairGen.generateKeyPair();
        RSAPublicKey publicKey = (RSAPublicKey)keyPair.getPublic();
        RSAPrivateKey privateKey = (RSAPrivateKey)keyPair.getPrivate();
        map.put("public", publicKey);
        map.put("private", privateKey);
        return map;
    }

    /**
     * 使用模和指数生成RSA公钥
     * 注意：【此代码用了默认补位方式，为RSA/None/PKCS1Padding，不同JDK默认的补位方式可能不同，如Android默认是RSA
     * /None/NoPadding】
     *
     * @param modulus
     *            模
     * @param exponent
     *            指数
     * @return
     */
    private static RSAPublicKey getPublicKey(String modulus, String exponent) {
        try {
            BigInteger b1 = new BigInteger(modulus);
            BigInteger b2 = new BigInteger(exponent);
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            RSAPublicKeySpec keySpec = new RSAPublicKeySpec(b1, b2);
            return (RSAPublicKey)keyFactory.generatePublic(keySpec);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * 使用模和指数生成RSA私钥
     * 注意：【此代码用了默认补位方式，为RSA/None/PKCS1Padding，不同JDK默认的补位方式可能不同，如Android默认是RSA
     * /None/NoPadding】
     *
     * @param modulus
     *            模
     * @param exponent
     *            指数
     * @return
     */
    private static RSAPrivateKey getPrivateKey(String modulus, String exponent) {
        try {
            BigInteger b1 = new BigInteger(modulus);
            BigInteger b2 = new BigInteger(exponent);
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            RSAPrivateKeySpec keySpec = new RSAPrivateKeySpec(b1, b2);
            return (RSAPrivateKey)keyFactory.generatePrivate(keySpec);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * ASCII码转BCD码
     *
     */
    private static byte[] ASCII_To_BCD(byte[] ascii, int asc_len) {
        byte[] bcd = new byte[asc_len / 2];
        int j = 0;
        for (int i = 0; i < (asc_len + 1) / 2; i++) {
            bcd[i] = asc_to_bcd(ascii[j++]);
            bcd[i] = (byte)(((j >= asc_len) ? 0x00 : asc_to_bcd(ascii[j++])) + (bcd[i] << 4));
        }
        return bcd;
    }

    private static byte asc_to_bcd(byte asc) {
        byte bcd;

        if ((asc >= '0') && (asc <= '9'))
            bcd = (byte)(asc - '0');
        else if ((asc >= 'A') && (asc <= 'F'))
            bcd = (byte)(asc - 'A' + 10);
        else if ((asc >= 'a') && (asc <= 'f'))
            bcd = (byte)(asc - 'a' + 10);
        else
            bcd = (byte)(asc - 48);
        return bcd;
    }

    /**
     * BCD转字符串
     */
    private static String bcd2Str(byte[] bytes) {
        char temp[] = new char[bytes.length * 2], val;

        for (int i = 0; i < bytes.length; i++) {
            val = (char)(((bytes[i] & 0xf0) >> 4) & 0x0f);
            temp[i * 2] = (char)(val > 9 ? val + 'A' - 10 : val + '0');

            val = (char)(bytes[i] & 0x0f);
            temp[i * 2 + 1] = (char)(val > 9 ? val + 'A' - 10 : val + '0');
        }
        return new String(temp);
    }

    /**
     * 拆分字符串
     */
    private static String[] splitString(String string, int len) {
        int x = string.length() / len;
        int y = string.length() % len;
        int z = 0;
        if (y != 0) {
            z = 1;
        }
        String[] strings = new String[x + z];
        String str = "";
        for (int i = 0; i < x + z; i++) {
            if (i == x + z - 1 && y != 0) {
                str = string.substring(i * len, i * len + y);
            } else {
                str = string.substring(i * len, i * len + len);
            }
            strings[i] = str;
        }
        return strings;
    }

    /**
     *拆分数组
     */
    private static byte[][] splitArray(byte[] data, int len) {
        int x = data.length / len;
        int y = data.length % len;
        int z = 0;
        if (y != 0) {
            z = 1;
        }
        byte[][] arrays = new byte[x + z][];
        byte[] arr;
        for (int i = 0; i < x + z; i++) {
            arr = new byte[len];
            if (i == x + z - 1 && y != 0) {
                System.arraycopy(data, i * len, arr, 0, y);
            } else {
                System.arraycopy(data, i * len, arr, 0, len);
            }
            arrays[i] = arr;
        }
        return arrays;
    }
    
    
    
    //------------------------------------public 方法--------------------------------------
    
    /**
     * 私钥加密
     *
     * @param data
     * @param privateKey
     * @return
     * @throws Exception
     */
    private static String encryptByPrivateKey(String data, RSAPrivateKey privateKey) throws Exception {
        Cipher cipher = Cipher.getInstance("RSA");
        cipher.init(Cipher.ENCRYPT_MODE, privateKey);
        // 模长
        int key_len = privateKey.getModulus().bitLength() / 8;
        // 加密数据长度 <= 模长-11
        String[] datas = splitString(data, key_len - 11);
        String mi = "";
        //如果明文长度大于模长-11则要分组加密
        for (String s : datas) {
            mi += bcd2Str(cipher.doFinal(s.getBytes()));
        }
        return mi;
    }

    /**
     * 公钥解密
     *
     * @param data
     * @param publicKey
     * @return
     * @throws Exception
     */
    private static String decryptByPublicKey(String data, RSAPublicKey publicKey) throws Exception {
        Cipher cipher = Cipher.getInstance("RSA");
        cipher.init(Cipher.DECRYPT_MODE, publicKey);
        //模长
        int key_len = publicKey.getModulus().bitLength() / 8;
        byte[] bytes = data.getBytes();
        byte[] bcd = ASCII_To_BCD(bytes, bytes.length);
        //如果密文长度大于模长则要分组解密
        String ming = "";
        byte[][] arrays = splitArray(bcd, key_len);
        for (byte[] arr : arrays) {
            ming += new String(cipher.doFinal(arr));
        }
        return ming;
    }
    
    public static RSAPublicKey pubKey = null;
    public static RSAPrivateKey priKey = null;
    public static String module = null;
    public static String public_exponent = null;
    public static String private_exponent = null;
    public static String publicKey_str = null;
    public static String privateKey_str = null;
    
    private static void init() {
        //生成公钥和私钥
        if(null==pubKey||null==priKey||null==module||null==public_exponent||null==private_exponent){
            HashMap<String, Object> map = null;
            try {
                map = RSAUtils.getKeys();
            } catch (NoSuchAlgorithmException e) {
                e.printStackTrace();
            }
            pubKey = (RSAPublicKey)map.get("public");
            priKey = (RSAPrivateKey)map.get("private");
//            //模
//            module = pubKey.getModulus().toString();
//            System.err.println("模 "+module);
//            //公钥指数
//            public_exponent = pubKey.getPublicExponent().toString();
//            System.err.println("公钥指数 "+public_exponent);
//            //私钥指数
//            private_exponent = priKey.getPrivateExponent().toString();
//            System.err.println("私钥指数 "+private_exponent);
            //公钥String
            publicKey_str = new String(pubKey.getEncoded());
            publicKey_str=new String(new Base64().encode(pubKey.getEncoded()));
            System.err.println("公钥String "+publicKey_str);
            //私钥String
            publicKey_str = new String(new Base64().encode(priKey.getEncoded()));
            System.err.println("私钥String "+publicKey_str);
        }
    }

    public static void main(String[] args) throws Exception {
        
        String priKeyStr = "MIICdQIBADANBgkqhkiG9w0BAQEFAASCAl8wggJbAgEAAoGBAKVgPrrT7XcRNUSe5W58iB2CCLt/wKcLzyJ2SiRasJVOVg20I4y0c9wyxp6PL7lHLjttSQ9Po2Oyc6cpND5Zj34FUW0rnRLvshNwC4Nvycaz/7imWuRG8Y/pqS7JRcbNS/vKZCKsEfGnOQ+KBVE8992AA3Q7GxPR/2W5fYrwpnexAgMBAAECgYBts8SpBoCV5XJijM1BV5arjGDikEJqDWlgQPu51fchdA+dk4upgOMChSRAdleAHnnKrhoy7+9A6VXS44Bmg96s8iXeRk2uaVFHnozD/UV9Vuya8cX1NzpxPVz72z2+4UnR97418p/ZiBtVpmv+u5oAuZY9ijBgvL/GzGJfkuodKQJBAPl36wcTO76rLk5HzlH4MCfCGH4AR8+bsMhcVbCew3jY1pCHx4CSKlo71/XxMNZpCgyXxLVsWPY/V7uv3qwXR2MCQQCptLDEePKsawHScW3aSqRQGFoIwyazDDDjYulG20R8nhbcR0hhZIBwF3tJZtqxqxPTw4xga4wtzHJnCYNMneLbAkA++aa7An/yggQOftH2n1CIuNa1+BworITUD3sSOwHdX9/KXHxgWIWYgcLisyBBAAMpaqadpdxPTW44Uw1DJB1BAkAq2bkYowGDj7FyFboLOHWs07lIJR6MbzOY9sy4W307ih9zl3wrO1lC9Gro6dOmsO/ctK+pWP6YQdtRMRG6MtOpAkAtkAZ6gX1ztW3iTepbZF4PFJVsFe/oUpPTmeV2LoQK1tGOvEsi0lhMDOijkEPkfkqFLIkfA8m5CaOTrUQlkrE8";
        System.err.println(priKeyStr.length());
        String pubKeyStr = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQClYD660+13ETVEnuVufIgdggi7f8CnC88idkokWrCVTlYNtCOMtHPcMsaejy+5Ry47bUkPT6NjsnOnKTQ+WY9+BVFtK50S77ITcAuDb8nGs/+4plrkRvGP6akuyUXGzUv7ymQirBHxpzkPigVRPPfdgAN0OxsT0f9luX2K8KZ3sQIDAQAB";
        System.err.println(pubKeyStr.length());
//        
        System.err.println(priKeyStr.substring(0, 200));
        System.err.println(priKeyStr.substring(200, 400));
        System.err.println(priKeyStr.substring(400, 600));
        System.err.println(priKeyStr.substring(600, 800));
        System.err.println(priKeyStr.substring(800));
        System.err.println(pubKeyStr.substring(0, 200));
        System.err.println(pubKeyStr.substring(200));
        
        RSAUtils.init();
        String ming = "123456789";
        System.err.println("原文" + ming);
        //生成密钥
//        RSAPrivateKey priKey = generatePrivateKey(priKeyStr);
        //私钥加密
        String mi = RSAUtils.encryptByPrivateKey(ming,priKey);
        System.err.println("加密" +mi);
        //公钥解密
        System.err.println("解密" + RSAUtils.decryptByPublicKey(mi,pubKey));
    }
}


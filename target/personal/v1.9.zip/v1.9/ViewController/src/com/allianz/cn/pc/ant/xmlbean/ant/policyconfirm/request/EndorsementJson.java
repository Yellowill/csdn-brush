package com.allianz.cn.pc.ant.xmlbean.ant.policyconfirm.request;

import com.allianz.cn.pc.ant.utils.AntDateConverter;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamConverter;

import java.util.Date;

public class EndorsementJson {
    
    @XStreamAlias("policyNo")
    private String policyNo;
    
    @XStreamAlias("status")
    private Integer status;
    
    @XStreamConverter(value=AntDateConverter.class)
    @XStreamAlias("surrenderTime")
    private Date surrenderTime;
    
    @XStreamAlias("surrenderReasonDesc")
    private String surrenderReasonDesc;
}

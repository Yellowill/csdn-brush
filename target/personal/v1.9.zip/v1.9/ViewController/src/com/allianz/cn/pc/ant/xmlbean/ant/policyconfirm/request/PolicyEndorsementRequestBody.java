package com.allianz.cn.pc.ant.xmlbean.ant.policyconfirm.request;

import com.allianz.cn.pc.ant.utils.AntDateConverter;

import com.allianz.cn.pc.ant.xmlbean.ant.common.Policy;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamConverter;

import java.util.Date;
import java.util.List;
import java.util.Map;

@XStreamAlias("body")
public class PolicyEndorsementRequestBody {
    
    @XStreamAlias("instSerialNo")
    private String instSerialNo;
    
    @XStreamAlias("endorseNo")
    private String endorseNo;
    
    @XStreamAlias("policy")
    private Policy policy;
    
    @XStreamAlias("planNo")
    private String planNo;
    
    @XStreamConverter(value=AntDateConverter.class)
    @XStreamAlias("endorseCreateTime")
    private Date endorseCreateTime;
    
    @XStreamConverter(value=AntDateConverter.class)
    @XStreamAlias("endorseTime")
    private Date endorseTime;
    
    @XStreamAlias("endorseReason")
    private Integer endorseReason;
    
    @XStreamAlias("endorseReasonDesc")
    private String endorseReasonDesc;
    
    @XStreamAlias("newPolicyVersion")
    private String newPolicyVersion;
    
    @XStreamAlias("oldPolicyVersion")
    private String oldPolicyVersion;
    
    @XStreamAlias("endorseFee")
    private Long endorseFee;
    
    @XStreamAlias("payType")//1-正单，应收款; 2-负单，应付款; 3-免费（无资金处理）
    private Integer payType;

    @XStreamAlias("endorseItemList")
    private List<InsEndorsementItem> endorseItemList;
    
//    <bizData>
//    <hesitationType>in</hesitationType>
//    </bizData>待测试使用map是否可行
    @XStreamAlias("bizData")
    private BizData bizData;
    
    @XStreamAlias("billList")
    private List<InsBillDTO> billList;
    
    @XStreamAlias("endorseCount")
    private String endorseCount;
    
    private String planCode;

    public void setInstSerialNo(String instSerialNo) {
        this.instSerialNo = instSerialNo;
    }

    public String getInstSerialNo() {
        return instSerialNo;
    }

    public void setEndorseNo(String endorseNo) {
        this.endorseNo = endorseNo;
    }

    public String getEndorseNo() {
        return endorseNo;
    }

    public void setPlanNo(String planNo) {
        this.planNo = planNo;
    }

    public String getPlanNo() {
        return planNo;
    }

    public void setEndorseCreateTime(Date endorseCreateTime) {
        this.endorseCreateTime = endorseCreateTime;
    }

    public Date getEndorseCreateTime() {
        return endorseCreateTime;
    }

    public void setEndorseTime(Date endorseTime) {
        this.endorseTime = endorseTime;
    }

    public Date getEndorseTime() {
        return endorseTime;
    }

    public void setEndorseReason(Integer endorseReason) {
        this.endorseReason = endorseReason;
    }

    public Integer getEndorseReason() {
        return endorseReason;
    }

    public void setEndorseReasonDesc(String endorseReasonDesc) {
        this.endorseReasonDesc = endorseReasonDesc;
    }

    public String getEndorseReasonDesc() {
        return endorseReasonDesc;
    }

    public void setNewPolicyVersion(String newPolicyVersion) {
        this.newPolicyVersion = newPolicyVersion;
    }

    public String getNewPolicyVersion() {
        return newPolicyVersion;
    }

    public void setOldPolicyVersion(String oldPolicyVersion) {
        this.oldPolicyVersion = oldPolicyVersion;
    }

    public String getOldPolicyVersion() {
        return oldPolicyVersion;
    }

    public void setEndorseFee(Long endorseFee) {
        this.endorseFee = endorseFee;
    }

    public Long getEndorseFee() {
        return endorseFee;
    }

    public void setPayType(Integer payType) {
        this.payType = payType;
    }

    public Integer getPayType() {
        return payType;
    }

    public void setEndorseItemList(List<InsEndorsementItem> endorseItemList) {
        this.endorseItemList = endorseItemList;
    }

    public List<InsEndorsementItem> getEndorseItemList() {
        return endorseItemList;
    }

    public void setBizData(BizData bizData) {
        this.bizData = bizData;
    }

    public BizData getBizData() {
        return bizData;
    }

    public void setBillList(List<InsBillDTO> billList) {
        this.billList = billList;
    }

    public List<InsBillDTO> getBillList() {
        return billList;
    }

    public void setEndorseCount(String endorseCount) {
        this.endorseCount = endorseCount;
    }

    public String getEndorseCount() {
        return endorseCount;
    }

    public void setPolicy(Policy policy) {
        this.policy = policy;
    }

    public Policy getPolicy() {
        return policy;
    }

    public void setPlanCode(String planCode) {
        this.planCode = planCode;
    }

    public String getPlanCode() {
        return planCode;
    }
}

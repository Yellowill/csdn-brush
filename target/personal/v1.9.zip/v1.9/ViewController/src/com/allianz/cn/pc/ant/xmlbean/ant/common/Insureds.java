package com.allianz.cn.pc.ant.xmlbean.ant.common;


import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import java.util.ArrayList;
import java.util.List;

@XStreamAlias("insureds")
public class Insureds {
    
    @XStreamImplicit(itemFieldName="insured")
    private List<Insured> insuredList = new ArrayList<Insured>();


    public void setInsuredList(List<Insured> insuredList) {
        this.insuredList = insuredList;
    }

    public List<Insured> getInsuredList() {
        return insuredList;
    }
}

package com.allianz.cn.pc.ant.xmlbean.ant;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("document")
public class DocumentNode {
    @XStreamAlias("signature")
    private String signature ;
    
    @XStreamAlias("response")
    private CommonResponse response = new CommonResponse();

    public void setSignature(String signature) {
        this.signature = signature;
    }

    public String getSignature() {
        return signature;
    }

    public void setResponse(CommonResponse response) {
        this.response = response;
    }

    public CommonResponse getResponse() {
        return response;
    }
}

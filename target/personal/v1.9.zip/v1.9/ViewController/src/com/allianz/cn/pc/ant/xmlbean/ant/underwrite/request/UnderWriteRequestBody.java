package com.allianz.cn.pc.ant.xmlbean.ant.underwrite.request;


import com.allianz.cn.pc.ant.xmlbean.ant.common.Holder;
import com.allianz.cn.pc.ant.xmlbean.ant.common.InsObject;
import com.allianz.cn.pc.ant.xmlbean.ant.common.Insureds;
import com.allianz.cn.pc.ant.xmlbean.ant.common.Policy;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("body")
public class UnderWriteRequestBody {
    
    @XStreamAlias("policy")
    private Policy policy = new Policy();
    
    @XStreamAlias("insObject")
    private InsObject insObject = new InsObject();
    
    @XStreamAlias("insureds")
    private Insureds insureds = new Insureds();
    
    @XStreamAlias("holder")
    private Holder holder = new Holder();


    public void setPolicy(Policy policy) {
        this.policy = policy;
    }

    public Policy getPolicy() {
        return policy;
    }

    public void setInsObject(InsObject insObject) {
        this.insObject = insObject;
    }

    public InsObject getInsObject() {
        return insObject;
    }

    public void setInsureds(Insureds insureds) {
        this.insureds = insureds;
    }

    public Insureds getInsureds() {
        return insureds;
    }

    public void setHolder(Holder holder) {
        this.holder = holder;
    }

    public Holder getHolder() {
        return holder;
    }
}

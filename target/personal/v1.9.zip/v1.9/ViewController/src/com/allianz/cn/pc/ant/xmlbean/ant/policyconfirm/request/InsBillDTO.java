package com.allianz.cn.pc.ant.xmlbean.ant.policyconfirm.request;

import com.allianz.cn.pc.ant.utils.AntDateConverter;

import com.thoughtworks.xstream.annotations.XStreamAlias;

import com.thoughtworks.xstream.annotations.XStreamConverter;

import java.math.BigDecimal;

import java.util.Date;

@XStreamAlias("bill")
public class InsBillDTO {
    
    @XStreamAlias("billNo")
    private String billNo;
    
    @XStreamAlias("type")
    private String type;
    
    @XStreamAlias("insBizNo")
    private String insBizNo;
    
    @XStreamAlias("inAlipayAccount")
    private String inAlipayAccount;
    
    @XStreamAlias("outAlipayAccount")
    private String outAlipayAccount;
    
    @XStreamConverter(value=AntDateConverter.class)
    @XStreamAlias("payTime")
    private Date payTime;
    
    @XStreamAlias("fee")
    private BigDecimal fee;
    
    @XStreamAlias("payFlowId")
    private String payFlowId;
    
    @XStreamAlias("discountFee")
    private BigDecimal discountFee;
    
    @XStreamAlias("payFlowType")
    private String payFlowType;
    
    @XStreamAlias("bizData")
    private String bizData;
    
    @XStreamAlias("status")
    private String status;

    public void setBillNo(String billNo) {
        this.billNo = billNo;
    }

    public String getBillNo() {
        return billNo;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getType() {
        return type;
    }

    public void setInsBizNo(String insBizNo) {
        this.insBizNo = insBizNo;
    }

    public String getInsBizNo() {
        return insBizNo;
    }

    public void setInAlipayAccount(String inAlipayAccount) {
        this.inAlipayAccount = inAlipayAccount;
    }

    public String getInAlipayAccount() {
        return inAlipayAccount;
    }

    public void setOutAlipayAccount(String outAlipayAccount) {
        this.outAlipayAccount = outAlipayAccount;
    }

    public String getOutAlipayAccount() {
        return outAlipayAccount;
    }

    public void setPayTime(Date payTime) {
        this.payTime = payTime;
    }

    public Date getPayTime() {
        return payTime;
    }

    public void setFee(BigDecimal fee) {
        this.fee = fee;
    }

    public BigDecimal getFee() {
        return fee;
    }

    public void setPayFlowId(String payFlowId) {
        this.payFlowId = payFlowId;
    }

    public String getPayFlowId() {
        return payFlowId;
    }

    public void setPayFlowType(String payFlowType) {
        this.payFlowType = payFlowType;
    }

    public String getPayFlowType() {
        return payFlowType;
    }

    public void setBizData(String bizData) {
        this.bizData = bizData;
    }

    public String getBizData() {
        return bizData;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStatus() {
        return status;
    }

    public void setDiscountFee(BigDecimal discountFee) {
        this.discountFee = discountFee;
    }

    public BigDecimal getDiscountFee() {
        return discountFee;
    }
}

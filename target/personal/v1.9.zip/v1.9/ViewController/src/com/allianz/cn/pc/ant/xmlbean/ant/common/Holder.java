package com.allianz.cn.pc.ant.xmlbean.ant.common;


import com.allianz.cn.pc.ant.utils.AntMapConverter;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamConverter;

import java.util.HashMap;
import java.util.Map;

@XStreamAlias("holder")
public class Holder {

    @XStreamAlias("personNo")
    private String personno;
    @XStreamAlias("certType")
    private String certtype;
    @XStreamAlias("accountType")
    private String accounttype;
    @XStreamAlias("accountNo")
    private String accountno;
    @XStreamAlias("accountName")
    private String accountname;
    @XStreamAlias("certNo")
    private String certno;
    @XStreamAlias("certName")
    private String certname;
    @XStreamConverter(value=AntMapConverter.class)
    @XStreamAlias("extendInfos")
    private Map<String,String> extendInfos=new HashMap<String,String>();

    public void setPersonno(String personno) {
        this.personno = personno;
    }

    public String getPersonno() {
        return personno;
    }

    public void setCerttype(String certtype) {
        this.certtype = certtype;
    }

    public String getCerttype() {
        return certtype;
    }

    public void setAccounttype(String accounttype) {
        this.accounttype = accounttype;
    }

    public String getAccounttype() {
        return accounttype;
    }

    public void setAccountno(String accountno) {
        this.accountno = accountno;
    }

    public String getAccountno() {
        return accountno;
    }

    public void setAccountname(String accountname) {
        this.accountname = accountname;
    }

    public String getAccountname() {
        return accountname;
    }

    public void setCertno(String certno) {
        this.certno = certno;
    }

    public String getCertno() {
        return certno;
    }

    public void setCertname(String certname) {
        this.certname = certname;
    }

    public String getCertname() {
        return certname;
    }

    public void setExtendInfos(Map<String, String> extendInfos) {
        this.extendInfos = extendInfos;
    }

    public Map<String, String> getExtendInfos() {
        return extendInfos;
    }
}


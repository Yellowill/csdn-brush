package com.allianz.cn.pc.ant.dto;


import java.util.Date;

public class AntTransDto {

    private String version_no;
    private String function_code;
    private Date transtime;
    private String transtimezone;
    private String reqmsgid;
    private String format;
    private String sign_type;
    private String asyn;
    private String cid;
    
    private String is_success;
    private String errorcode;
    private String error_message;
    private String order_no;
    private String policyNo;
    private Integer order_status;

    public void setVersion_no(String version_no) {
        this.version_no = version_no;
    }

    public String getVersion_no() {
        return version_no;
    }

    public void setFunction_code(String function_code) {
        this.function_code = function_code;
    }

    public String getFunction_code() {
        return function_code;
    }

    public void setTranstime(Date transtime) {
        this.transtime = transtime;
    }

    public Date getTranstime() {
        return transtime;
    }

    public void setTranstimezone(String transtimezone) {
        this.transtimezone = transtimezone;
    }

    public String getTranstimezone() {
        return transtimezone;
    }

    public void setReqmsgid(String reqmsgid) {
        this.reqmsgid = reqmsgid;
    }

    public String getReqmsgid() {
        return reqmsgid;
    }

    public void setFormat(String format) {
        this.format = format;
    }

    public String getFormat() {
        return format;
    }

    public void setSign_type(String sign_type) {
        this.sign_type = sign_type;
    }

    public String getSign_type() {
        return sign_type;
    }

    public void setAsyn(String asyn) {
        this.asyn = asyn;
    }

    public String getAsyn() {
        return asyn;
    }

    public void setCid(String cid) {
        this.cid = cid;
    }

    public String getCid() {
        return cid;
    }

    public void setIs_success(String is_success) {
        this.is_success = is_success;
    }

    public String getIs_success() {
        return is_success;
    }

    public void setErrorcode(String errorcode) {
        this.errorcode = errorcode;
    }

    public String getErrorcode() {
        return errorcode;
    }

    public void setError_message(String error_message) {
        this.error_message = error_message;
    }

    public String getError_message() {
        return error_message;
    }

    public void setOrder_no(String order_no) {
        this.order_no = order_no;
    }

    public String getOrder_no() {
        return order_no;
    }

    public void setPolicyNo(String policyNo) {
        this.policyNo = policyNo;
    }

    public String getPolicyNo() {
        return policyNo;
    }

    public void setOrder_status(Integer order_status) {
        this.order_status = order_status;
    }

    public Integer getOrder_status() {
        return order_status;
    }
}

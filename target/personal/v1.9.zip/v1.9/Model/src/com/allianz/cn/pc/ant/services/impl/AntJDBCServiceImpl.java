package com.allianz.cn.pc.ant.services.impl;


import com.allianz.cn.pc.ant.Const;
import com.allianz.cn.pc.ant.Const.RegionCode;
import com.allianz.cn.pc.ant.dto.AntTransDto;
import com.allianz.cn.pc.ant.dto.BillDto;
import com.allianz.cn.pc.ant.dto.GroupPlanInfoDto;
import com.allianz.cn.pc.ant.dto.HolderDto;
import com.allianz.cn.pc.ant.dto.InsuredDto;
import com.allianz.cn.pc.ant.dto.OrderDto;
import com.allianz.cn.pc.ant.dto.PaymentInfoDto;
import com.allianz.cn.pc.ant.dto.PlanInfoDto;
import com.allianz.cn.pc.ant.services.AntAbstractService;
import com.allianz.cn.pc.ant.services.AntService;
import com.allianz.cn.pc.ant.services.Config;
import com.allianz.cn.pc.ant.utils.AntModelUtil;
import com.allianz.cn.pc.ant.vo.PolicyInfoVo;
import com.allianz.cn.pc.ant.vo.standard.requestvo.ehome.EhmoneRequestBody;
import com.allianz.cn.pc.ant.vo.standard.requestvo.ehome.EhomeRequestPacket;
import com.allianz.cn.pc.common.constant.CommonConst;
import com.allianz.cn.pc.common.model.bean.InterfaceLogBean;
import com.allianz.cn.pc.utils.Beans;

import com.allianz.cn.pc.utils.DateUtil;
import com.allianz.cn.pc.utils.HttpClient;
import com.allianz.cn.pc.utils.XmlUtil;
import com.allianz.oti.common.EtravelConst;
import com.allianz.oti.common.util.DateUtils;
import com.allianz.oti.common.util.vo.QueryResultBean;
import com.allianz.oti.model.dto.commonsearch.endorsement.EndorsementInfo;
import com.allianz.oti.model.thirdparty.vo.ResponseBigObject;
import com.allianz.oti.model.thirdparty.vo.ehome.RequestBody;
import com.allianz.oti.model.thirdparty.vo.ehome.RequestHead;

import com.allianz.oti.model.thirdparty.vo.ehome.RequestPacket;
import com.allianz.oti.model.thirdparty.vo.ehome.ResponsePacket;
import com.allianz.oti.model.thirdparty.vo.ehome.request.policyconfirm.Agency;

import com.allianz.oti.model.thirdparty.vo.ehome.request.policyconfirm.Insured;
import com.allianz.oti.model.thirdparty.vo.ehome.request.policyconfirm.Policy;

import com.allianz.oti.model.thirdparty.vo.ehome.request.policyconfirm.PolicyHolder;

import com.allianz.oti.model.thirdparty.vo.oti.request.policyconfirm.OTIAgency;
import com.allianz.oti.model.thirdparty.vo.oti.request.policyconfirm.OTIBody;
import com.allianz.oti.model.thirdparty.vo.oti.request.policyconfirm.OTIHead;
import com.allianz.oti.model.thirdparty.vo.oti.request.policyconfirm.OTIInsured;
import com.allianz.oti.model.thirdparty.vo.oti.request.policyconfirm.OTIInsuredList;
import com.allianz.oti.model.thirdparty.vo.oti.request.policyconfirm.OTIPacket;
import com.allianz.oti.model.thirdparty.vo.oti.request.policyconfirm.OTIPolicy;
import com.allianz.oti.model.thirdparty.vo.oti.request.policyconfirm.OTIPolicyHolder;
import com.allianz.oti.model.thirdparty.vo.requestvo.issuepolicy.IssuePacket;
import com.allianz.oti.model.thirdparty.vo.requestvo.issuepolicy.IssuePolicyBody;
import com.allianz.oti.model.thirdparty.vo.requestvo.issuepolicy.PaymentInfo;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

import java.io.UnsupportedEncodingException;

import java.math.BigDecimal;

import java.math.RoundingMode;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.sql.Types;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import java.util.TimeZone;

import org.apache.log4j.Logger;


public class AntJDBCServiceImpl extends AntAbstractService implements AntService{ 
    
    private static Logger log = Logger.getLogger(AntJDBCServiceImpl.class);
    private static AntJDBCServiceImpl connJDBCService = null;
    private Connection conn = null;
    private static final String CORE_IG_APP_NAME="INTERFACE";
    private static final String CORE_IG_EHOME_KEY="ig.ehome";
    
    private static final String CORE_IG_UW_OTI_KEY="ig.uw.oti";
    private static final String CORE_IG_CONFIRM_OTI_KEY="ig.oti";
    private static final String CORE_IG_ISSUE_KEY="ig.issue";
    
    private AntJDBCServiceImpl() {
    }
    
    public synchronized static AntJDBCServiceImpl getInstance() {
        if (connJDBCService == null)
            connJDBCService = new AntJDBCServiceImpl();

        return connJDBCService;
    }
    
    public static AntJDBCServiceImpl getNewInstance() {
        return new AntJDBCServiceImpl();
    }

    @Override
    public void saveTrans(AntTransDto dto) throws Exception {
        Connection conn = null;
        PreparedStatement prep = null;
        try {
            conn = this.getDataSource().getConnection();
            String sql = "insert into prl_ant_inf_trans (ORDER_NO, VERSION_NO, FUNCTION_CODE, TRANSTIME, TRANSTIMEZONE," +
                "REQMSGID, FORMAT, SIGN_TYPE, ASYN, CID, IS_SUCCESS,order_status)" + 
            "values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            
            prep = conn.prepareStatement(sql.toString());
            prep.setString(1, dto.getOrder_no());
            prep.setString(2, dto.getVersion_no());
            prep.setString(3, dto.getFunction_code());
            prep.setTimestamp(4, new Timestamp(dto.getTranstime().getTime()));
            prep.setString(5, dto.getTranstimezone());
            prep.setString(6, dto.getReqmsgid());
            prep.setString(7, dto.getFormat());
            prep.setString(8, dto.getSign_type());
            prep.setString(9, dto.getAsyn());
            prep.setString(10, dto.getCid());
            prep.setString(11, dto.getIs_success());
            prep.setInt(12, dto.getOrder_status());

            prep.executeUpdate();

        } catch (Exception e) {
            throw e;
        } finally {
            closeAll(conn, prep, null);
        }
    }

    @Override
    public boolean isDuplicateRequestId(String reqId) {
        log.debug("isDuplicateRequestId reqId="+reqId);
        boolean returnvalue = true;
        Connection conn = null;
        PreparedStatement prep = null;
        ResultSet rs = null;
        try {
            conn = this.getDataSource().getConnection();
            String sql = "SELECT count(*) from prl_ant_inf_trans s WHERE s.reqmsgid=?";
            prep = conn.prepareStatement(sql.toString());
            prep.setString(1, reqId);

            rs = prep.executeQuery();
            if(rs.next()){
                int count = rs.getInt(1);
                if(count>0)
                    returnvalue = false;
            }
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        } finally {
            closeAll(conn, prep, rs);
        }
        return returnvalue;
    }

    @Override
    public OrderDto findOrder(String order_no) throws Exception {
        log.debug("findOrder order_no="+order_no);
        
        OrderDto returnvalue = new OrderDto();
        Connection conn = null;
        PreparedStatement prep = null;
        ResultSet rs = null;
        try {
            conn = this.getDataSource().getConnection();
            String sql = "SELECT ORDER_NO,EFFECTSTARTTIME,Premium,Status,Underwrite_flag,is_issued_success,policy_ref, is_renewal, old_out_policy_no, next_continuous_time " +
                " FROM prl_ant_inf_order o where o.order_no=?";
            prep = conn.prepareStatement(sql.toString());
            prep.setString(1, order_no);

            rs = prep.executeQuery();
            if(rs.next()){
                returnvalue.setOrder_no(rs.getString("ORDER_NO"));
//                returnvalue.setActual_premium(rs.getBigDecimal("Actual_premium"));
//                returnvalue.setApplynum(rs.getInt("APPLYNUM"));
//                returnvalue.setEffectendtime(rs.getTimestamp("EFFECTENDTIME"));
                returnvalue.setEffectstarttime(rs.getTimestamp("EFFECTSTARTTIME"));
//                returnvalue.setInsuredtime(rs.getTimestamp("INSUREDTIME"));
//                returnvalue.setIssuetime(rs.getTimestamp("ISSUETIME"));
//                returnvalue.setObject_type(rs.getInt("OBJECT_TYPE"));
//                returnvalue.setOut_product_code(rs.getString("OUT_PRODUCT_CODE"));
//                returnvalue.setPolicy_type(rs.getString("POLICY_TYPE"));
                returnvalue.setPremium(rs.getBigDecimal("Premium"));
//                returnvalue.setProduct_code(rs.getString("Product_code"));
                returnvalue.setStatus(rs.getInt("Status"));
//                returnvalue.setSum_insured(rs.getBigDecimal("Sum_insured"));
//                returnvalue.setSummary_order_no(rs.getString("Summary_order_no"));
                returnvalue.setUnderwrite_flag(rs.getInt("Underwrite_flag"));
                returnvalue.setIs_issue_success(rs.getString("is_issued_success"));
                returnvalue.setPolicy_ref(rs.getString("policy_ref"));
//                returnvalue.setDb_error_msg(rs.getString("db_error_msg"));
                returnvalue.setIs_renewal(rs.getString("is_renewal"));
                returnvalue.setOld_out_policy_no(rs.getString("old_out_policy_no"));
                returnvalue.setNext_continuous_time(rs.getTimestamp("next_continuous_time"));
            }
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            throw e;
        } finally {
            closeAll(conn, prep, rs);
        }
        return returnvalue;
    }
    
    @Override
    public BillDto findBill(String order_no, String payFlowId) throws Exception {
        log.debug("findBill order_no="+order_no);
        BillDto returnvalue = new BillDto();
        Connection conn = null;
        PreparedStatement prep = null;
        ResultSet rs = null;
        try {
            conn = this.getDataSource().getConnection();
            String sql = "SELECT t.order_no,t.merchantaccounttype,t.merchantaccountid,t.otheraccounttype,t.otheraccountid," + 
                        " t.paytime,t.payflowid,t.fee,t.updatetime,t.discountfee FROM prl_ant_inf_order_bill t" +
                        " where t.order_no=? and t.payflowid=?";
            prep = conn.prepareStatement(sql.toString());
            prep.setString(1, order_no);
            prep.setString(2, payFlowId);

            rs = prep.executeQuery();
            if(rs.next()){
                returnvalue.setOrder_no(rs.getString("ORDER_NO"));
                returnvalue.setMerchantaccounttype(rs.getInt("MERCHANTACCOUNTTYPE"));
                returnvalue.setMerchantaccountid(rs.getString("MERCHANTACCOUNTID"));
                returnvalue.setOtheraccounttype(rs.getInt("OTHERACCOUNTTYPE"));
                returnvalue.setOtheraccountid(rs.getString("OTHERACCOUNTID"));
                returnvalue.setPaytime(rs.getTimestamp("PAYTIME"));
                returnvalue.setPayflowid(rs.getString("PAYFLOWID"));
                returnvalue.setDiscountFee(rs.getBigDecimal("DISCOUNTFEE"));
                returnvalue.setFee(rs.getBigDecimal("FEE"));
            }
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            throw e;
        } finally {
            closeAll(conn, prep, rs);
        }
        return returnvalue;
    }
    public static void main(String[] args) {
        IssuePacket requestPacket = new IssuePacket();
        //报文-head
        RequestHead head = new RequestHead();
        IssuePolicyBody body = new IssuePolicyBody();
        String requestType = CommonConst.RequestType.REQ_TYPE_ISSUEPOLICY.value;
        head.setRequestType(requestType);
        requestPacket.setRequestHead(head);
        try {
            PaymentInfo paymentInfo = new PaymentInfo();
            paymentInfo.setPolicyRef("123");
            paymentInfo.setPaymentMethod("alipay");// 支付方式待定
            paymentInfo.setPayTime(new java.util.Date());
            paymentInfo.setPremium(new BigDecimal(123));
            paymentInfo.setPlatformSerialNumber("321");
            body.setPaymentInfo(paymentInfo);
            requestPacket.setIssuePolicyBody(body);
            String retXml = XmlUtil.toXml(requestPacket, "UTF-8");     
            log.info("return xml:\n"+retXml);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        StringBuffer sql = new StringBuffer();
        sql.append(" SELECT S.PLAN_CODE, " + 
        "       S.STATUS, " + 
        "       S.START_DATE, " + 
        "       S.END_DATE, " + 
        "       S.AGE_FROM, " + 
        "       S.AGE_TO, " + 
        "       S.product_code " + 
        "  FROM PRL_EOPUS_PLANS S " + 
        " WHERE S.VERSION_NO = " + 
        "       (SELECT MAX(VERSION_NO) FROM PRL_EOPUS_PLANS WHERE PLAN_CODE = ?) " + 
        "   AND S.PLAN_CODE = ?");
        System.err.println(sql);
    }
    
    /**
     * coffee add  获取计划的信息
     * @param planId
     * @return
     */
    public PlanInfoDto findPlanInfoByPlanCode(String planCode,Date effetiveDate) throws Exception {
        PlanInfoDto returnvalue = new PlanInfoDto();
        
        Connection conn = null;
        PreparedStatement cst = null;     
        ResultSet rs = null;
        
        StringBuffer sql = new StringBuffer();
        sql.append(" SELECT S.PLAN_CODE," + 
        "       S.STATUS," + 
        "       S.START_DATE," + 
        "       S.END_DATE," + 
        "       S.AGE_FROM," + 
        "       S.AGE_TO," + 
        "       S.PRODUCT_CODE, " + 
        "       S.PREMIUM, " + 
        "       S.PLAN_ID, " + 
        "       S.group_plan_code, " + 
        "       S.group_plan_name " + 
        "  FROM PRL_EOPUS_PLANS S" + 
        " WHERE S.STATUS = '1' " +
        " AND S.PLAN_CODE = ?" + 
        " AND s.start_date<=?" + 
        " AND (s.end_date IS NULL OR s.end_date+1>?)");

        try {
            conn = this.getDataSource().getConnection();
            cst = conn.prepareStatement(sql.toString());
            cst.setString(1, planCode);
            cst.setTimestamp(2, new Timestamp(effetiveDate.getTime()));
            cst.setTimestamp(3, new Timestamp(effetiveDate.getTime()));
            
            rs = cst.executeQuery();
            if (rs.next()) {
                returnvalue.setPlanCode(rs.getString("PLAN_CODE"));
                returnvalue.setStatus(rs.getString("STATUS"));
                if(Beans.isNotEmpty(rs.getTimestamp("START_DATE")))
                    returnvalue.setStartDate(new Date(rs.getTimestamp("START_DATE").getTime()));
                if(Beans.isNotEmpty(rs.getTimestamp("END_DATE")))
                    returnvalue.setEndDate(new Date(rs.getTimestamp("END_DATE").getTime()));
                returnvalue.setStartAge(rs.getDouble("AGE_FROM"));
                returnvalue.setEndAge(rs.getDouble("AGE_TO"));
                returnvalue.setSubProduct(rs.getString("product_code"));
                returnvalue.setPremium(rs.getBigDecimal("PREMIUM"));
                returnvalue.setPlanId(rs.getInt("PLAN_ID"));
                returnvalue.setGroupPlanCode(rs.getString("group_plan_code"));
                returnvalue.setGroupPlanName(rs.getString("group_plan_name"));
            }
        } catch (Exception e) {
            throw e;
        } finally {
            closeAll(conn,cst,rs);
        }
            
        return returnvalue;
    }

    @Override
    public void saveOrder(OrderDto orderDto) throws Exception {
        Connection conn = this.getConnection();
        PreparedStatement cst = null;     
        
        StringBuffer sql = null;
        sql = new StringBuffer(" insert into prl_ant_inf_order (ORDER_NO, PRODUCT_CODE, OUT_PRODUCT_CODE, SUMMARY_ORDER_NO, " +
            "POLICY_TYPE, PREMIUM, ACTUAL_PREMIUM, SUM_INSURED, " +
            "EFFECTSTARTTIME, EFFECTENDTIME, APPLYNUM, OBJECT_TYPE, UNDERWRITE_FLAG, STATUS,post_address,ehome_address,DESTINATION,address_code, " + 
            "EXTENDINFOS, IS_RENEWAL, OLD_OUT_POLICY_NO,INSUREDTIME,ISSUETIME) " + 
            "values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,?)");
      

        try {
            cst = conn.prepareStatement(sql.toString());
            cst.setString(1, orderDto.getOrder_no());
            cst.setString(2, orderDto.getProduct_code());
            cst.setString(3, orderDto.getOut_product_code());
            cst.setString(4, orderDto.getSummary_order_no());
            cst.setString(5, orderDto.getPolicy_type());
            cst.setBigDecimal(6, orderDto.getPremium());
            cst.setBigDecimal(7, orderDto.getActual_premium());
            cst.setBigDecimal(8, orderDto.getSum_insured());
            cst.setTimestamp(9, Beans.isEmpty(orderDto.getEffectstarttime())? null : new Timestamp(orderDto.getEffectstarttime().getTime()));
            cst.setTimestamp(10, Beans.isEmpty(orderDto.getEffectendtime())? null : new Timestamp(orderDto.getEffectendtime().getTime()));
            cst.setInt(11, orderDto.getApplynum());
            cst.setInt(12, Beans.isEmpty(orderDto.getInsObjectDto())? orderDto.getObject_type() : orderDto.getInsObjectDto().getType());
            cst.setInt(13, orderDto.getUnderwrite_flag());
            cst.setInt(14, orderDto.getStatus());
            cst.setString(15, orderDto.getPost_address());
            cst.setString(16, orderDto.getEhome_address());
            cst.setString(17, orderDto.getDestination());
            cst.setString(18, orderDto.getAddress_code());
            cst.setString(19, Beans.isEmpty(orderDto.getExtendInfos())? null : orderDto.getExtendInfos().toString());
            cst.setString(20, orderDto.getIs_renewal());
            cst.setString(21, orderDto.getOld_out_policy_no());
            cst.setTimestamp(22, Beans.isEmpty(orderDto.getInsuredtime())? null : new Timestamp(orderDto.getInsuredtime().getTime()));
            cst.setTimestamp(23, Beans.isEmpty(orderDto.getIssuetime())? null : new Timestamp(orderDto.getIssuetime().getTime()));
            
            cst.executeUpdate();
            
        } catch (Exception e) {
            throw e; 
        } finally {
            closeAll(null,cst,null);
        }
    }

    @Override
    public void saveHolder(HolderDto holderDto) throws Exception {
        Connection conn = this.getConnection();
        PreparedStatement cst = null;     
        
        StringBuffer sql = new StringBuffer();
        sql.append(" insert into prl_ant_inf_order_holder (ORDER_NO, PERSONNO, CERTTYPE, ACCOUNTTYPE, ACCOUNTNO, " +
            "BIRTH_DAY, ACCOUNTNAME, CERTNO, CERTNAME, EXTENDINFOS, RESIDENT_PROVINCE, RESIDENT_CITY, ADDRESS, SEX, PHONE,email,name_en) " + 
        "values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

        try {
            cst = conn.prepareStatement(sql.toString());
            cst.setString(1, holderDto.getOrder_no());
            cst.setString(2, holderDto.getPersonno());
            cst.setString(3, holderDto.getCerttype());
            cst.setString(4, holderDto.getAccounttype());
            cst.setString(5, holderDto.getAccountno());
            cst.setTimestamp(6, new Timestamp(holderDto.getBirth_day().getTime()));
            cst.setString(7, holderDto.getAccountname());
            cst.setString(8, holderDto.getCertno());
            cst.setString(9, holderDto.getCertname());
            cst.setString(10, holderDto.getExtendInfos().toString());
            cst.setString(11, holderDto.getResident_province());
            cst.setString(12, holderDto.getResident_city());
            cst.setString(13, holderDto.getAddress());
            cst.setString(14, holderDto.getSex());
            cst.setString(15, holderDto.getPhone());
            cst.setString(16, holderDto.getEmail());
            cst.setString(17, holderDto.getNameEn());
            
            cst.executeUpdate();
            
        } catch (Exception e) {
            throw e;
        } finally {
            closeAll(null,cst,null);
        }
    }

    @Override
    public void saveInsured(InsuredDto insuredDto) throws Exception {
        Connection conn = this.getConnection();
        PreparedStatement cst = null;     
        
        StringBuffer sql = new StringBuffer();
        sql.append(" insert into prl_ant_inf_order_insured (ORDER_NO,  PERSONNO, " +
            "CERTTYPE, ACCOUNTTYPE, ACCOUNTNO, BIRTH_DAY, ACCOUNTNAME, CERTNO, CERTNAME, EXTENDINFOS, " +
            "RESIDENT_PROVINCE, RESIDENT_CITY, ADDRESS, SEX, PHONE,SAMEWITHHOLDER, RELATIONWITHHOLDER, INSURED_TYPE,email,name_en) " + 
        "values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

        try {
            cst = conn.prepareStatement(sql.toString());
            cst.setString(1, insuredDto.getOrder_no());
            cst.setString(2, insuredDto.getPersonno());
            cst.setString(3, insuredDto.getCerttype());
            cst.setString(4, insuredDto.getAccounttype());
            cst.setString(5, insuredDto.getAccountno());
            cst.setTimestamp(6, new Timestamp(insuredDto.getBirth_day().getTime()));
            cst.setString(7, insuredDto.getAccountname());
            cst.setString(8, insuredDto.getCertno());
            cst.setString(9, insuredDto.getCertname());
            cst.setString(10, insuredDto.getExtendInfos().toString());
            cst.setString(11, insuredDto.getResident_province());
            cst.setString(12, insuredDto.getResident_city());
            cst.setString(13, insuredDto.getAddress());
            cst.setString(14, insuredDto.getSex());
            cst.setString(15, insuredDto.getPhone());
            cst.setInt(16, insuredDto.getSameWithholder());
            cst.setString(17, insuredDto.getRelationWithholder());
            cst.setString(18, insuredDto.getInsuredType());
            cst.setString(19, insuredDto.getEmail());
            cst.setString(20, insuredDto.getNameEn());
            
            cst.executeUpdate();
            
        } catch (Exception e) {
            throw e;
        }finally {
            closeAll(null,cst,null);
        }
    }
    
    @Override
    public void saveBill(BillDto billDto) throws Exception {
        Connection conn = this.getDataSource().getConnection();
        PreparedStatement cst = null;     
        
        StringBuffer sql = new StringBuffer();
        sql.append(" insert into prl_ant_inf_order_bill (ORDER_NO, MERCHANTACCOUNTTYPE, MERCHANTACCOUNTID," +
            "OTHERACCOUNTTYPE, OTHERACCOUNTID, PAYTIME, PAYFLOWID, FEE,updatetime,DISCOUNTFEE) " + 
        "values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

        try {
            cst = conn.prepareStatement(sql.toString());
            cst.setString(1, billDto.getOrder_no());
            cst.setInt(2, billDto.getMerchantaccounttype());
            cst.setString(3, billDto.getMerchantaccountid());
            cst.setInt(4, billDto.getOtheraccounttype());
            cst.setString(5, billDto.getOtheraccountid());
            cst.setTimestamp(6, new Timestamp(billDto.getPaytime().getTime()));
            cst.setString(7, billDto.getPayflowid());
            cst.setBigDecimal(8, billDto.getFee());
            cst.setTimestamp(9, new Timestamp(new Date().getTime()));
            cst.setBigDecimal(10, billDto.getDiscountFee());
            
            cst.executeUpdate();
        } catch (Exception e) {
            throw e;
        } finally {
            closeAll(conn,cst,null);
        }
    }


    @Override
    public Integer issue(String order_no) throws Exception {
        Integer contract_id = null;
        String coreFlag = this.retrieveConfigValueByKey("INTERFACE", "ig.interface.invoke");//是否走原流程
//        coreFlag = "Y";
        if("Y".equals(coreFlag)){//调用核心接口
            //调用核心出单接口
            //激活保单    --可一步完成
            contract_id = commonOTIConfirm(order_no);
            return contract_id;
        }
        CallableStatement cbStatment = null;
        PreparedStatement prepFind = null;
        Connection conn = null;
        try {
            conn = this.getDataSource().getConnection();
            cbStatment = conn.prepareCall("begin prl_pk2_ant.New_Policy(?,?);end;");
            cbStatment.setObject(1, order_no);
            cbStatment.registerOutParameter(2, Types.NUMERIC);
            cbStatment.execute();
            
            contract_id = cbStatment.getInt(2);
        } catch (Exception e) {
            throw e;
        } finally {
            closeAll(conn, prepFind, null);
            try{ 
                if(cbStatment != null)
                    cbStatment.close();
            }catch(Exception e){
                e.printStackTrace();
            }
        }
        return contract_id;
    }
    
    @Override
    public Integer doSettlement(Integer contractId) throws Exception {
        Integer result = null;
        CallableStatement cbStatment = null;
        Connection conn = null;
        try {
            conn = this.getDataSource().getConnection();
            cbStatment = conn.prepareCall("begin prl_pk2_ant.ant_do_settelment(?,?);end;");
            cbStatment.setObject(1, contractId);
            cbStatment.registerOutParameter(2, Types.NUMERIC);
            cbStatment.execute();
            
            result = cbStatment.getInt(2);
        } catch (Exception e) {
            throw e;
        } finally {
            closeAll(conn, cbStatment, null);
            try{ 
                if(cbStatment != null)
                    cbStatment.close();
            }catch(Exception e){
                e.printStackTrace();
            }
        }
        return result;
    }

    @Override
    public void updateTrans(AntTransDto transDto) throws Exception {
        Connection conn = null;
        PreparedStatement cst = null;     
        
        StringBuffer sql = new StringBuffer();
        sql.append("UPDATE PRL_ANT_INF_TRANS S " + 
        "   SET S.IS_SUCCESS    = ?, " + 
        "       S.ERROR_CODE    = ?, " + 
        "       S.ERROR_MESSAGE = ?, " + 
        "       S.PROPOSALNO   =?, ");
        if(Beans.isNotEmpty(transDto.getOrder_status()))
            sql.append("       S.ORDER_STATUS =?, ");
        sql.append( " S.UPDATETIME    = ? WHERE S.ORDER_NO = ?");

        try {
            conn = this.getDataSource().getConnection();
            cst = conn.prepareStatement(sql.toString());
            cst.setString(1, transDto.getIs_success());
            cst.setString(2, transDto.getErrorcode());
            cst.setString(3, transDto.getError_message());
            cst.setString(4, transDto.getPolicyNo());
            int i=5;
            if(Beans.isNotEmpty(transDto.getOrder_status()))
                cst.setInt(i++, transDto.getOrder_status());
            cst.setTimestamp(i++, new Timestamp(new Date().getTime()));
            cst.setString(i++, transDto.getOrder_no());
            
            cst.executeUpdate();
            
        } catch (Exception e) {
            throw e;
        } finally {
            closeAll(conn,cst,null);
        }
    }

    @Override
    public BigDecimal getPlanPremium(String planCode, Date effectstarttime, Date effectendtime, Integer period, String insuredType) {
        log.debug("getPlanPremium planCode="+planCode+" insuredType="+insuredType);
        BigDecimal returnvalue = null;
        String calMethod = null;
        Integer planVersionNo = null;
        Connection conn = null;
        PreparedStatement prep = null;
        ResultSet rs = null;
        
        try {
            conn = this.getDataSource().getConnection();
            String sql = "SELECT b.base_prem, B.cal_method, PLAN.version_no " + 
            "  FROM PRL_EOPUS_PLAN_BEN_RATE B " + 
            " INNER JOIN " + 
            " (SELECT P.PLAN_ID, P.VERSION_NO, P.PLAN_CODE " + 
            "    FROM PRL_EOPUS_PLANS P " + 
            "   WHERE P.VERSION_NO = (SELECT MAX(VERSION_NO) " + 
            "                           FROM PRL_EOPUS_PLANS P1 " + 
            "                          WHERE P1.PLAN_ID = P.PLAN_ID)) PLAN " + 
            "    ON B.PLAN_ID = PLAN.PLAN_ID " + 
            "   AND B.PLAN_VERSION_NO = PLAN.VERSION_NO " + 
            " WHERE PLAN.PLAN_CODE=? " + 
            "   AND INSURED_TYPE = ?";
            if(Beans.isNotEmpty(period)){
                sql += "AND (DAYS_FROM IS NULL OR DAYS_FROM <= ?)" + 
                "   AND (DAYS_TO IS NULL OR DAYS_TO >= ?)" ;
            }
            sql += " AND B.INSTALLMENT_NUMBER IS NULL ";  //非分期
            
            //log.debug("getPlanPremium sql is: "+sql.toString());
            prep = conn.prepareStatement(sql.toString());
            prep.setString(1, planCode);
            prep.setString(2, insuredType);
            if(Beans.isNotEmpty(period)){
                prep.setInt(3, period);
                prep.setInt(4, period);
            }

            rs = prep.executeQuery();
            if(rs.next()){
                returnvalue = rs.getBigDecimal(1);
                calMethod = rs.getString("cal_method");
                planVersionNo = rs.getInt("version_no");
                if(rs.next()){//如果找到多个保费，返回空
                    log.debug("getPlanPremium 找到多个保费!! 请检查配置 sql="+sql);
                    return null;
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        } finally {
            closeAll(conn, prep, rs);
        }
        //根据不同的计算方式，计算保费
        return calculatePremium(returnvalue, calMethod, planCode, planVersionNo, period, effectstarttime, effectendtime);
        
    }
    
    @Override
    public BigDecimal getPlanSumInsured(String planCode) {
        log.debug("getPlanSumInsured planCode="+planCode);
        BigDecimal returnvalue = null;
        Connection conn = null;
        PreparedStatement prep = null;
        ResultSet rs = null;
        try {
            conn = this.getDataSource().getConnection();
            String sql = "SELECT SUM(pb.sum_insured) " + 
            "  FROM prl_eopus_plan_benefits pb " + 
            " INNER JOIN " + 
            " (SELECT P.PLAN_ID, P.VERSION_NO, P.PLAN_CODE " + 
            "    FROM PRL_EOPUS_PLANS P " + 
            "   WHERE P.VERSION_NO = (SELECT MAX(VERSION_NO) " + 
            "                           FROM PRL_EOPUS_PLANS P1 " + 
            "                          WHERE P1.PLAN_ID = P.PLAN_ID)) PLAN " + 
            "    ON pb.PLAN_ID = PLAN.PLAN_ID " + 
            "   AND pb.PLAN_VERSION_NO = PLAN.VERSION_NO " + 
            " WHERE PLAN.PLAN_CODE=?";
            log.debug("getPlanSumInsured sql is: "+sql.toString());
            prep = conn.prepareStatement(sql.toString());
            prep.setString(1, planCode);

            rs = prep.executeQuery();
            if(rs.next()){
                returnvalue = rs.getBigDecimal(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
            log.error(e.getMessage(),e);
        } finally {
            closeAll(conn, prep, rs);
        }
        return returnvalue;
    }
    
    @Override
    public String getPlanCodeFromMapping(String productCode, String sex, Integer age) {
        Connection conn = null;
        PreparedStatement prep = null;
        ResultSet result = null;
        StringBuffer sql = new StringBuffer();
        String planCode = null;
        
        sql.append("select plan_code from PRL_ANT_PLANCODE_MAPPING ");
        sql.append(" where 1=1");//防止后边参数为空时报错    
        if(Beans.isNotEmpty(productCode)){
            sql.append(" and ant_code='"+productCode.trim()+"'")  ;  
        }
        if(Beans.isNotEmpty(sex)){
            sql.append(" and (sex='"+sex+"' or sex is null)")  ;  
        }
        if(Beans.isNotEmpty(age)){
                sql.append(" and (age_from<="+age+" or age_from is null) and (age_to>="+age+" or age_to is null)")  ;  
        }
        log.info("getPlanCodeFromMapping sql is:"+sql);
        try {
            conn = this.getDataSource().getConnection();
            prep = conn.prepareStatement(sql.toString());
            
            result = prep.executeQuery();
            if (result.next()){
                planCode = result.getString(1);
                if (result.next()) 
                    planCode = null;
            }
        } catch (Exception e) {
            e.printStackTrace();
            log.error(e.getMessage(),e);
        } finally {
            this.closeAll(conn, prep, result);
        }
        return planCode;
    }
    
    public void updateWarningMail(String summary,String detail) {
        detail+="<br />详情查看 select * from prl_smsgw_mailschedule_send where title="+ANT+" Exception";
        Connection conn = null;
        Statement stmt = null;     
        
        String sql = "update prl_smsgw_mailschedule_send a set a.flag='0',a.schedule_sendtime=sysdate," +
            "a.attach_url1='"+summary+"',a.plain_content='"+detail+"'"+
            " where a.title='"+ANT+" Exception' ";
        log.debug("updateWarningMail sql is:"+sql);
        try {
            conn = this.getDataSource().getConnection();
            stmt = conn.createStatement();
            
            stmt.execute(sql);
        } catch (Exception e) {
            e.printStackTrace();
            log.error(e.getMessage(),e);
        } finally {
            try{
               if(stmt != null)
                   stmt.close();
               if(conn != null)
                   conn.close();
            }catch(Exception e){
                e.printStackTrace();
                log.error(e.getMessage(),e);
            }
        }
    }
    
    @Override
    public String getHolderMobile(String order_no) {
        Connection conn = null;
        PreparedStatement prep = null;
        ResultSet result = null;
        StringBuffer sql = new StringBuffer();
        String returnvalue = null;
        
        sql.append("SELECT h.phone FROM PRL_ANT_INF_ORDER_HOLDER H WHERE h.order_no=?");
       
        //log.info("getHolderMobile sql is:"+sql);
        try {
            conn = this.getDataSource().getConnection();
            prep = conn.prepareStatement(sql.toString());
            prep.setString(1, order_no);
            
            result = prep.executeQuery();
            if (result.next()){
                returnvalue = result.getString(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
            log.error(e.getMessage(),e);
        } finally {
            this.closeAll(conn, prep, result);
        }
        return returnvalue;
    }
    
    @Override
    public String getPolicyNo(String order_no) {
        Connection conn = null;
        PreparedStatement prep = null;
        ResultSet result = null;
        StringBuffer sql = new StringBuffer();
        String returnvalue = null;
        
        sql.append("SELECT policy_ref FROM PRL_ANT_INF_ORDER WHERE order_no=?");
        
        //log.info("getPolicyNo sql is:"+sql);
        try {
            conn = this.getDataSource().getConnection();
            prep = conn.prepareStatement(sql.toString());
            prep.setString(1, order_no);
            
            result = prep.executeQuery();
            if (result.next()){
                returnvalue = result.getString(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
            log.error(e.getMessage(),e);
        } finally {
            this.closeAll(conn, prep, result);
        }
        return returnvalue;
    }
    
    @Override
    public void addSmsSchedule(String holderMobile, String modelContent) {
        //添加是否发送短信开关
        String flag_YN = this.retrieveConfigValueByKey("ANT", Config.SMS_SEND_KEY);
        if("N".equals(flag_YN)){
            log.info("Do not send SMS. holderMobile=" + holderMobile + "modelContent="+modelContent);
            return;
        }
        
        Connection conn = null;
        PreparedStatement cst = null;     
        
        StringBuffer sql = new StringBuffer();
        sql.append(" insert into prl_smsgw_schedule_send(id,content,send_mobile,app_name,status) values(prl_smsgw_schedule_seq.nextval,?,?,'TAOBAO','0')");
        log.debug("addSmsSchedule holderMobile="+holderMobile+" modelContent="+modelContent+" sql="+sql.toString());
        try {
            conn = this.getDataSource().getConnection();
            cst = conn.prepareStatement(sql.toString());
            cst.setString(1,modelContent);
            cst.setString(2,holderMobile);
            
            
            cst.executeUpdate();
            
        } catch (Exception e) {
            e.printStackTrace();
            log.error(e.getMessage(),e);
        } finally {
            closeAll(conn,cst,null);
        }
    }
    
    @Override
    public boolean personInBlacklist(Long idType, String idNo, String name){
        boolean result = false;
        PreparedStatement cst = null;     
        ResultSet rs = null;
        Connection conn = null;
        try {
            conn = this.getDataSource().getConnection();
            cst = conn.prepareStatement(" SELECT prl_pk2_policy_validation.is_blacklist_person(?,?,?) FROM dual");
            cst.setLong(1, idType);
            cst.setString(2, idNo);
            cst.setString(3, name);
            cst.execute();
            
            rs = cst.executeQuery();
            if(rs.next())
                if(rs.getInt(1)>0)
                    result = true;
        } catch (Exception e) {
            log.error("personInBlacklist error",e);
        } finally {
            closeAll(conn, cst, null);
            try{ 
                if(cst != null)
                    cst.close();
            }catch(Exception e){
                log.error("personInBlacklist error",e);
            }
            return result;
        }
    }

    @Override
    public void beginTransaction() {
        this.createTransaction();
    }

    @Override
    public void endTransaction() {
        this.finishTransaction();
    }

    /**
     *配置表取数
     * @param appname
     * @param key
     * @return
     */
    public String getConfigValueByKey(String appname,String key){
        return this.retrieveConfigValueByKey(appname,key);
    }

    private String retrieveConfigValueByKey(String appname,String key) {
        Connection conn = null;
        PreparedStatement prep = null;
        ResultSet rs = null;
        String value = null;
        StringBuffer sqlBuff = new StringBuffer();
        sqlBuff.append("select value from prpl_app_parameter where app_name=? and status='1' and key=?  ");
        try {
            conn = this.getDataSource().getConnection();
            prep = conn.prepareStatement(sqlBuff.toString());
            prep.setString(1, appname);
            prep.setString(2, key);
            rs = prep.executeQuery();
            if (rs.next()) {
                value = rs.getString(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
            log.error(e);
        } finally {
            closeAll(conn, prep, rs);
        }
        log.debug("key: "+key+", return value is "+value);
        return value;
    }
    
    @Override
    public void updateHolder(String order_no, String extendInfos, String phone) throws Exception {
        log.info("updateHolder...order_no="+order_no+", phone="+phone);
        if(Beans.isEmpty(order_no) || Beans.isEmpty(phone)){
            log.error("updateHolderPhone...error. order_no is null, or phone is null.");
            return;
        }
        Connection conn = null;
        PreparedStatement cst = null;     
        String sql = " update prl_ant_inf_order_holder t " + 
        " set t.phone = ?, " + 
        " t.extendinfos = ? " + 
        " where t.order_no = ? " + 
        " and t.phone is null ";
        try {
            conn = this.getDataSource().getConnection();
            cst = conn.prepareStatement(sql.toString());
            cst.setString(1, phone);
            cst.setString(2, extendInfos);
            cst.setString(3, order_no);
            cst.executeUpdate();
        } catch (Exception e) {
            throw e;
        } finally {
            closeAll(conn,cst,null);
        }
    }
    
    public boolean openRenewal(){
        return "Y".equals(this.retrieveConfigValueByKey(ANT, Config.RENEWAL_OPEN_FLAG_KEY));
    }
    
    public PolicyInfoVo getPolicyInfoByPolicyNo(String policyNo){
        log.info("获取原保单续保信息，原保单PolicyNo： " + policyNo);
        String sql="SELECT p.contract_id  contractId, " +
        "       pep.cal_method            premCalMethod," +
        "       pep.plan_code             planCode, " +
        "       p.contract_status         policyStatus, " +
        "       p.branch_code             branchCode, " + 
        "       p.term_start_date         effectiveDate, " + 
        "       p.term_end_date           expireDate, " + 
        "       ppt.lop_prod_type         lopProdType, " + 
        //"       gp.group_plan_code        groupPlanCode, " +
        //"       gp.group_plan_name_zhs    groupPlanName, " + 
        //"       gp.renewable_flag         renewableFlag, " + 
        //"       gp.renewable_grace_period renewableGracePeriod," +
        "       agnIpExt.Handler_Ref      subAccount " + 
        "  FROM prl_common_quote_policy_all p, " + 
        "       PRL_PRODUCT_TYPE            ppt, " + 
        "       prl_part_plan_ext           ppe, " + 
        "       prl_eopus_plans             pep, " + 
        //"       prl_eopus_group_plans       gp," +
        "       prl_ip_ext                  agnIpExt " + 
        " where p.sub_product = ppt.product_type " + 
        "   and p.contract_id = ppe.contract_id " + 
        "   and ppe.action_code <> 'D' " + 
        "   and ppe.top_indicator = 'Y' " + 
        "   and ppe.plan_id = pep.plan_id " + 
        "   and ppe.plan_version_no = pep.version_no " + 
        "   and p.contract_id = agnIpExt.contract_id " +
        "   and agnIpExt.Ip_No = 3 " + 
        "   and agnIpExt.Action_Code <> 'D' " + 
        "   and agnIpExt.Top_Indicator = 'Y' " + 
        //"   and pep.group_plan_code = gp.group_plan_code " +
        //"   and gp.status = '1' " + 
        "   and p.contract_id = (SELECT distinct pgv.contract_id " + 
        "                          FROM prl_group_policy_versions pgv " + 
        "                         where pgv.policy_ref = ? ) "; 
        Connection conn = null;
        PreparedStatement prep = null;
        ResultSet rs = null;
        try {
            conn = this.getDataSource().getConnection();
            prep = conn.prepareStatement(sql);
            prep.setString(1, policyNo);
            rs = prep.executeQuery();
            if (rs.next()) {
                PolicyInfoVo vo = new PolicyInfoVo();
                vo.setContractId(rs.getInt("contractId"));
                vo.setPremCalMethod(rs.getString("premCalMethod"));
                vo.setPlanCode(rs.getString("planCode"));
                //vo.setGroupPlanCode(rs.getString("groupPlanCode"));
                //vo.setGroupPlanName(rs.getString("groupPlanName"));
                vo.setPolicyStatus(rs.getString("policyStatus"));
                vo.setBranchCode(rs.getString("branchCode"));
                vo.setEffectiveDate(rs.getTimestamp("effectiveDate"));
                vo.setExpireDate(rs.getTimestamp("expireDate"));
                vo.setLopProdType(rs.getString("lopProdType"));
                //vo.setRenewableFlag(rs.getString("renewableFlag"));
                //vo.setRenewableGracePeriod(rs.getInt("renewableGracePeriod"));
                vo.setSubAccount(rs.getString("subAccount"));  
                return vo;
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            closeAll(conn, prep, rs);
        }
        return null;
    }
    
    
    public String getOldContractStatus(Integer contractId){
        String sql = "select old_contract_status from prl_ren_batch_details  where old_contract_id = ? ";
        return (String)this.exeSelectValueSql(sql, contractId);
    
    }
    
    /**
     * 判断是否风险客户
     * true: 风险客户
     * false: 非风险客户
     */
    public boolean validateRiskCustomer(OrderDto orderDto, InsuredDto insuredDto, Integer oldContractId){
        String insuredName = Beans.isEmpty(insuredDto.getCertname()) ? "null" : insuredDto.getCertname().trim();
        String insuredIdNo = Beans.isEmpty(insuredDto.getCertno()) ? "null" : insuredDto.getCertno().trim();
        String effectStartTimeStr = DateUtil.dateToStringWithFormat(orderDto.getEffectstarttime(), "yyyy-MM-dd HH:mm:ss");
        String sql = "SELECT pep.customer_id " + 
        "  FROM prl_eopus_person pep, prl_eopus_customer_rule pecr " + 
        " where pep.customer_id = pecr.customer_id " + 
        "   and pep.valid_status = '1' " + 
        "   and pecr.status = '1' " + 
        "   and pecr.start_date <= to_date('"+effectStartTimeStr+"','yyyy-mm-dd hh24:mi:ss') " + 
        "   and (pecr.end_date >= to_date('"+effectStartTimeStr+"','yyyy-mm-dd hh24:mi:ss') or pecr.end_date is null) " + 
        "   and pecr.allow_auto_renewal_yn = 'N' " + 
        "   and (instr('"+insuredName+"', trim(pep.name_en)) > 0 or instr('"+insuredName+"', trim(pep.name_zhs)) > 0) " + 
        "   and (pep.card_no = '"+insuredIdNo+"' or pep.passport = '"+insuredIdNo+"' or pep.other_card_no =  '"+insuredIdNo+"') " + 
        "   and (pecr.group_plan_code = (SELECT pep.group_plan_code " + 
        "        FROM prl_eopus_plans pep " + 
        "       where pep.plan_code = '"+orderDto.getOut_product_code().trim()+"' " + 
        "         and pep.version_no = " + 
        "             (SELECT max(pp.version_no) " + 
        "                FROM prl_eopus_plans pp " + 
        "               where pp.plan_id = pep.plan_id))  or (SELECT to_char(pgv.contract_id) FROM prl_group_policy_versions pgv where pgv.policy_ref=pecr.policy_ref) = '"+oldContractId+"')";
        Integer id = null;
        Object value = this.exeSelectValueSql(sql);
        if(Beans.isNotEmpty(value)){
            id = ((BigDecimal)value).intValue();
        }
        log.info("RiskCustomer customer_id:" + id);
        if(Beans.isNotEmpty(id) && id > 0){
            return true;
        }
        return false;
    }
    
    
    private Object exeSelectValueSql(String sql, Object...args){
        Connection conn = null;
        PreparedStatement prep = null;
        ResultSet rs = null;
        try {
            conn = this.getDataSource().getConnection();
            prep = conn.prepareStatement(sql);
            if(Beans.isNotEmpty(args)){
                for(int i=0;i<args.length;i++){
                    prep.setObject(i+1, args[i]);
                }
            }
            rs = prep.executeQuery();
            if (rs.next()) {
                return rs.getObject(1);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            closeAll(conn, prep, rs);
        }
        return null;
    }
    
    /**
     * 通过产品名称，获取某计划的开放投保区域限制。
     */
    public String getRegionLimit(String planCode){
        Connection conn = null;
        PreparedStatement prep = null;
        ResultSet rs = null;
        String value = null;
        StringBuffer sqlBuff = new StringBuffer();
        sqlBuff.append("select spa.message_template " + 
        "  from prl_sendmessage_product_agent spa, " + 
        "       prl_eopus_plans ep " + 
        " where spa.message_type = ? " + 
        "   and spa.state = '1' " + 
        "   and spa.message_subject = ep.group_plan_name " + 
        "   and ep.plan_code = ? " + 
        "   and ep.version_no = (select max(t.version_no) " + 
        "                          from prl_eopus_plans t " + 
        "                         where t.plan_code = ?)");
        try {
            conn = this.getDataSource().getConnection();
            prep = conn.prepareStatement(sqlBuff.toString());
            prep.setString(1, EtravelConst.AgentMessageType.InsureRegionLimitByProductName.value); //10
            prep.setString(2, planCode);
            prep.setString(3, planCode);
            rs = prep.executeQuery();
            if (rs.next()) {
                value = rs.getString("message_template");
            }
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        } finally {
            closeAll(conn, prep, rs);
        }
        return value; 
    }
    
    
    public Integer issueHome(String order_no) throws Exception{
        this.updateOrderWaitIssue(order_no, null);
        log.info("标准接口出单...");
        OrderDto orderDto = this.findOrderByOrderNo(order_no);
        HolderDto holderDto = this.findHolderByOrderNo(order_no);
        List<InsuredDto> insuredDtoList = this.findInsuredListByOrderNo(order_no);
        Map<String, Object> reMap = this.confirmHomeAPI(orderDto,holderDto,insuredDtoList,EtravelConst.FALSEREAL);
        String policyRef = (String)reMap.get("policyRef");
        Integer contractId = 1;
        String coreFlag = this.retrieveConfigValueByKey("INTERFACE", "ig.interface.invoke");//是否走原流程
        if(Beans.isEmpty(coreFlag) || "N".equals(coreFlag)){
            contractId = this.getContractId(policyRef);
        }
        String policyStatus = (String)reMap.get("policyStatus");
        String errorMsg = (String)reMap.get("errorMsg");
        
        //接口返回成功结果
        if((Beans.isEmpty(coreFlag) || "N".equals(coreFlag)) && Beans.isNotEmpty(contractId) && contractId > 0 && Beans.isNotEmpty(policyRef)){
            if(Const.PolicyStatus.InForce.value.equals(policyStatus)){
                //保单已生效
                this.updateOrderIssueSuccess(order_no, policyRef);
            }else if(Const.PolicyStatus.WaitForPay.value.equals(policyStatus)){
                //激活保单
                log.info("激活保单...contractId:"+contractId+", order_no:"+order_no);
                Map<String, Object> resultMap = this.issueHomeAPI(contractId, order_no);
                //判断执行状态 0：调用成功；其他issue错误
                Integer returnStatus = (Integer)resultMap.get("p_return_status");
                log.info("issue返回：p_return_status=" + returnStatus);
                if (returnStatus == null || 0 != returnStatus) {
                    log.error("调用存储过程激活保单出错，返回p_return_status：" + returnStatus);
                    this.updateOrderIssueFailure(order_no, "保险公司系统错误");
                    contractId = -1;
                }else{
                    this.updateOrderIssueSuccess(order_no, policyRef);
                }
            } 
        } else if ("Y".equals(coreFlag) && Beans.isNotEmpty(policyRef)){
            log.info("调用核心接口激活保单...order_no:"+order_no);
            if(Const.PolicyStatus.InForce.value.equals(policyStatus)){
                //保单已生效
                this.updateOrderIssueSuccess(order_no, policyRef);
            }else{
                Map<String, Object> resultMap = this.coreIssueAPI(order_no,policyRef);
                //判断执行状态 70：激活成功；其他issue错误
                String returnStatus = (String)resultMap.get("policyStatus");
                log.info("issue返回：policyStatus=" + returnStatus);
                if (Beans.isEmpty(returnStatus) || !EtravelConst.PolicyStatus.InForce.value.equals(returnStatus)) {
                    log.error("调用核心接口激活保单出错，返回policyStatus：" + returnStatus);
                    this.updateOrderIssueFailure(order_no, "保险公司系统错误");
                    contractId = -1;
                } else {
                    this.updateOrderIssueSuccess(order_no, policyRef);
                }
            }
        }else{
            this.updateOrderIssueFailure(order_no, errorMsg);
            contractId = -1;
        }
        return contractId;
    }
    
    
    /**
     * 家财险出单
     * 调家财险标准出单接口
     * map keys: contractId, policyRef, policyStatus, errorMsg
     */
    private Map<String, Object> confirmHomeAPI(OrderDto orderDto,HolderDto holderDto,List<InsuredDto> insuredList, boolean isUW) {
        String order_no = orderDto.getOrder_no();
        log.info("confirmHomeAPI...start order_no:"+order_no);
        log.info("to home Packet...start");
        Map<String, Object> reMap = new HashMap<String, Object>();
//        Integer contractId = -1;
        String policyRef = null;
        String policyStatus = null;
        String errorMsg = null;
        try{
            String agencyCode = this.getHomeAgencyCode();
            String[] userAndPass = this.getUsernameAndPassword();
            if(Beans.isEmpty(agencyCode) || Beans.isEmpty(userAndPass) || userAndPass.length != 2){
                throw new Exception("获取渠道代码或登录信息失败"); 
            }
            InsuredDto insuredDto = insuredList.get(0);
            Map<String, String> rcMap = this.getRegionCodeMap(orderDto.getAddress_code());
            String requestType = CommonConst.RequestType.REQ_TYPE_POLICYCONFIRM_EHOME.value;
            if(isUW){
                requestType = CommonConst.RequestType.REQ_TYPE_UNDERWRITE_EHOME.value;
            }
            EhomeRequestPacket requestPacket = new EhomeRequestPacket();
            
            //报文-head
            RequestHead head = new RequestHead();
            head.setRequestType(requestType);
            head.setUser(userAndPass[0]);
            head.setPassword(userAndPass[1]);
            head.setRequestId(ANT+order_no+"-"+System.currentTimeMillis());
            requestPacket.setRequestHead(head);
            //标准接口报文-body
            EhmoneRequestBody body = new EhmoneRequestBody();
            
            //agency
            Agency agency = new Agency();
            agency.setAgencyCode(agencyCode);
            body.setAgency(agency);
            
            //policy base info
            Policy policy = new Policy();
            policy.setApplicationID(ANT+order_no); //prl_thirdp_interf_pol_data
            policy.setPlanCode(orderDto.getOut_product_code());
            policy.setEffectiveDate(new java.util.Date(orderDto.getEffectstarttime().getTime()));
            policy.setExpireDate(new java.util.Date(orderDto.getEffectendtime().getTime()));
            policy.setCountry(rcMap.get(RegionCode.CountryCode.value));
            policy.setProvince(rcMap.get(RegionCode.ProvinceCode.value));
            policy.setCity(rcMap.get(RegionCode.CityCode.value));
            policy.setPostcode(rcMap.get(RegionCode.Postcode.value));
            policy.setStreet(orderDto.getEhome_address());//LocHouseholds
            policy.setSubcity(null);
            policy.setArea(null);
            policy.setRemark(null);
            body.setPolicy(policy);
            
            //PolicyHolder  - 投保人
            PolicyHolder policyHolder = new PolicyHolder();
            policyHolder.setClientRef("I"); //投保人类型  I-个人,C-企业或者机构
            policyHolder.setLongName(holderDto.getCertname()); //投保人名称
            policyHolder.setRoleTypeId(holderDto.getCerttype()); //证件类型
            policyHolder.setPolicyNo(holderDto.getCertno()); //投保人证件号
            Date hBirthDay = this.formatTimeZone(holderDto.getBirth_day());
            policyHolder.setPHBirthDate(Beans.isEmpty(hBirthDay) ? null : new java.util.Date(hBirthDay.getTime()));
            policyHolder.setPHGender(this.getSexMapForHome(holderDto.getSex())); //性别.
            policyHolder.setHotlineTelNo(holderDto.getPhone());
            policyHolder.setRemark(holderDto.getEmail()); //投保人邮箱地址
            policyHolder.setArrangedByUs(null); //MailType  如果需要邮寄，则该信息必须 1-平邮, 2-快递，客户需要自己支付快递费用
            policyHolder.setInsuredBusiness(null); //InvoiceTitle 发票抬头
            policyHolder.setInsuredOverwriteFlag("0"); //ReqMail 是否邮寄发票，默认不需要 1-需要,0-不需要
            policyHolder.setOverrideAddress(null); //PHAddress 发票邮寄的地址
            policyHolder.setPartnerRef(null); //PolicyHolderCode
            policyHolder.setPeriodOfInsurance(null); //PHPostCode 发票邮寄的邮政编码
            policyHolder.setReqElecFaPiao(null); // 要求电子发票
            policyHolder.setShowCommFlag("0"); //是否需要打印发票 1-需要 0-不需要
            body.setPolicyHolder(policyHolder);
            
            //被保险人
            Insured insured = new Insured();
            insured.setClientRef("I"); //被保险人类型  I-个人, C-企业
            insured.setLongName(insuredDto.getCertname());
            insured.setRoleTypeId(insuredDto.getCerttype()); //证件类型
            insured.setPolicyNo(insuredDto.getCertno()); //证件号码
            Date inBirthDay= this.formatTimeZone(insuredDto.getBirth_day());
            insured.setBirthDate(Beans.isEmpty(inBirthDay) ? null : new java.util.Date(inBirthDay.getTime()));
            insured.setHotlineTelNo(insuredDto.getPhone()); //联系电话
            insured.setRemark(insuredDto.getEmail());  //Email  电子邮件
            insured.setGender(this.getSexMapForHome(insuredDto.getSex())); //性别.
            insured.setBeneficialType("1"); //受益类型 1-法定
            insured.setRelationShip(null); //被保险人与房屋关系
            insured.setEmergencyContactName(null); //紧急联系人姓名
            insured.setEmergencyMobile(null); //联系电话
            body.setInsured(insured);
            requestPacket.setRequestBody(body);
            log.info("to home Packet...end");
            
            String retXml = toString(this.sendXml(XmlUtil.toXml(requestPacket, "UTF-8"), this.getPostUrl(requestType)));     
            log.debug("return xml:\n"+retXml);
            log.info("return xml:\n"+retXml);
            //标准接口返回结果转换成对应的object
            ResponsePacket responsePacket = XmlUtil.fromXml(ResponsePacket.class, retXml);
            if(Beans.isNotEmpty(responsePacket)){
                if(Beans.isNotEmpty(responsePacket.getResponseHead())){
                    reMap.put("responseCode", responsePacket.getResponseHead().getResponseCode());
                    reMap.put("errorCode", responsePacket.getResponseHead().getErrorCode());
                    reMap.put("errorMsg", responsePacket.getResponseHead().getErrorMessage());
                }
                if(EtravelConst.ResponseCode.success.value.equals(responsePacket.getResponseHead().getResponseCode())){
                    if(isUW){
                        return reMap;
                    }
                    //出单成功
                    log.info("出单成功! order_no:"+order_no+", policyRef:"+responsePacket.getResponseBody().getPolicyRef()+", policyStatus:"+responsePacket.getResponseBody().getPolicyStatus());
//                    contractId = this.getContractId(responsePacket.getResponseBody().getPolicyRef());
                    policyStatus = responsePacket.getResponseBody().getPolicyStatus();
                    policyRef = responsePacket.getResponseBody().getPolicyRef();
                }else{
                    //出单失败
                    log.error("出单失败! order_no:"+order_no+", error msg:"+responsePacket.getResponseHead().getErrorMessage());
                    errorMsg = responsePacket.getResponseHead().getErrorMessage();
                }
            }else{
                //调标准接口响应出错
                log.error("调标准接口响应出错! order_no:"+order_no);
                errorMsg = "保险公司系统错误(标准接口)";
            }
        } catch (Exception e) {
            log.error("issueHome...error. order_no:"+order_no);
            log.error(e.getMessage(), e);
            errorMsg = "ANT调标准接口出错";
        }
        log.info("confirmHomeAPI...end. order_no:"+order_no);
        reMap.put("policyRef", policyRef);
        reMap.put("policyStatus", policyStatus);
        reMap.put("errorMsg", errorMsg);
        return reMap;
    }
    
    /**
     * 家财险通过标准接口出单后，保单为待支付状态，需要对保单进行激活并做settle
     * 注：参考payment gateway中支付成功激活保单生效
     */
    private Map<String, Object> issueHomeAPI(Integer contractId, String orderNo) {
        Map<String, Object> result = new HashMap<String, Object>();
        PaymentInfoDto paymentInfo = this.getPaymentInfo(contractId, orderNo);
        if(Beans.isEmpty(paymentInfo)){
            log.error("issueHomeAPI error. 没有找到支付信息 contractId:"+contractId);
            return result;
        }
        log.info("inParam----> orderNo:"+orderNo+", contractId:"+contractId+", Policy_ref:"+paymentInfo.getPolicy_ref()
                 +", Aomunt:"+paymentInfo.getAmount()+", Payment_mode:"+paymentInfo.getPayment_mode()
                 +", Endpoint_code:"+paymentInfo.getEndpoint_code()+", Drawer_bank_acc_no:"+paymentInfo.getDrawer_bank_acc_no()
                 +", Pos_location_code:"+paymentInfo.getPos_location_code()+", Paytime:"+paymentInfo.getPaytime()
                 +", To_bank_code:"+paymentInfo.getTo_bank_code());
        
        Connection conn = null;
        CallableStatement st = null;
        try {
            conn = this.getDataSource().getConnection();
            conn.setAutoCommit(false);
            st = conn.prepareCall("{call Prl_cash_bf_cover_api.issue_policy(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
            //p_contract_id            IN OUT   NUMBER,
            st.registerOutParameter(1, Types.INTEGER);
            st.setObject(1, contractId);
            //p_unionpay_ref           IN OUT   VARCHAR2,                 --银联检索号
            st.registerOutParameter(2, Types.VARCHAR);
            //p_business_ref           IN OUT   VARCHAR2,                 --业务流水号
            st.registerOutParameter(3, Types.VARCHAR);
            //p_policy_no              IN OUT   VARCHAR2,                   --投保单号
            st.registerOutParameter(4, Types.VARCHAR);
            st.setObject(4, paymentInfo.getPolicy_ref());
            //p_premium_amt            IN OUT   NUMBER,                     --应缴金额
            st.registerOutParameter(5, Types.DECIMAL);
            st.setObject(5, paymentInfo.getAmount());
            //p_payment_mode           IN       VARCHAR2, -- 付款方式 'PS' is  for POS
            st.registerOutParameter(6, Types.VARCHAR);
            st.setObject(6, paymentInfo.getPayment_mode());
            //p_endpoint_code          IN OUT   VARCHAR2,                  --POS终端号
            st.registerOutParameter(7, Types.VARCHAR);
            st.setObject(7, paymentInfo.getEndpoint_code());
            //p_payment_account_code   IN OUT   VARCHAR2,                   --缴费卡号
            st.registerOutParameter(8, Types.VARCHAR);
            st.setObject(8, paymentInfo.getDrawer_bank_acc_no());
            //p_pos_location_code      IN OUT   VARCHAR2,                     --商户号
            st.registerOutParameter(9, Types.VARCHAR);
            st.setObject(9, paymentInfo.getPos_location_code());
            //p_pos_location_desc      IN OUT   VARCHAR2,                   --商户名称
            st.registerOutParameter(10, Types.VARCHAR);
            st.setObject(10, paymentInfo.getOrder_no());
            //p_payment_time           IN       DATE,                   --交易日期时间
            st.registerOutParameter(11, Types.DATE);
            st.setObject(11, new java.sql.Date(paymentInfo.getPaytime().getTime()));
            //p_to_bank_code           IN       VARCHAR2,     -- use for bank transfer
            st.registerOutParameter(12, Types.VARCHAR);
            st.setObject(12, paymentInfo.getTo_bank_code());//'3780'  - 支付宝收款银行code
            //p_policy_holder          IN OUT   VARCHAR2,               --被保险人名称
            st.registerOutParameter(13, Types.VARCHAR);
            //p_return_status          IN OUT   NUMBER,
            st.registerOutParameter(14, Types.INTEGER);
            //p_installment_no         IN       NUMBER Default Null,
            st.registerOutParameter(15, Types.INTEGER);
            //p_voucher_remark         IN       VARCHAR2 Default Null
            st.registerOutParameter(16, Types.VARCHAR);
            boolean resultFlag = st.execute();
            if (!resultFlag) {
                //p_contract_id            IN OUT   NUMBER,
                result.put("p_contract_id", st.getLong(1));
                //p_unionpay_ref           IN OUT   VARCHAR2,                 --银联检索号
                result.put("p_unionpay_ref", st.getString(2));
                //p_business_ref           IN OUT   VARCHAR2,                 --业务流水号
                result.put("p_business_ref", st.getString(3));
                //p_policy_no              IN OUT   VARCHAR2,                   --投保单号
                result.put("p_policy_no", st.getString(4));
                //p_premium_amt            IN OUT   NUMBER,                     --应缴金额
                result.put("p_premium_amt", st.getBigDecimal(5));
                //p_endpoint_code          IN OUT   VARCHAR2,                  --POS终端号
                result.put("p_endpoint_code", st.getString(7));
                //p_payment_account_code   IN OUT   VARCHAR2,                   --缴费卡号
                result.put("p_payment_account_code", st.getString(8));
                //p_pos_location_code      IN OUT   VARCHAR2,                     --商户号
                result.put("p_pos_location_code", st.getString(9));
                //p_pos_location_desc      IN OUT   VARCHAR2,                   --商户名称
                result.put("p_pos_location_desc", st.getString(10));
                //p_policy_holder          IN OUT   VARCHAR2,               --被保险人名称
                result.put("p_policy_holder", st.getString(13));
                //p_return_status          IN OUT   NUMBER,
                result.put("p_return_status", st.getInt(14));
            }
            //判断执行状态 0：调用成功；其他issue错误
            Integer returnStatus = (Integer)result.get("p_return_status");
            if (returnStatus == null || 0 != returnStatus) {
                log.error("调用存储过程issue出错，返回p_return_status：" + returnStatus+", conn.rollback...");
                conn.rollback();
            }
            return result;
        } catch (Exception e) {
            log.error("issueHomeAPI error.", e);
            try {
                conn.rollback();
            } catch (SQLException f) {
                log.error(f.getMessage(),f);
            }
            return result;
        } finally {
            closeAll(conn, st, null);
        }
    }
    
    
    private String getPostUrl(String requestType){
        //家财核保出单地址一样
        if(CommonConst.RequestType.REQ_TYPE_POLICYCONFIRM_EHOME.value.equals(requestType) || CommonConst.RequestType.REQ_TYPE_UNDERWRITE_EHOME.value.equals(requestType)){
            return this.retrieveConfigValueByKey(CORE_IG_APP_NAME, CORE_IG_EHOME_KEY);
        }
        if(CommonConst.RequestType.REQ_TYPE_UNDERWRITE_OTI.value.equals(requestType)){
            return this.retrieveConfigValueByKey(CORE_IG_APP_NAME, CORE_IG_UW_OTI_KEY);
        }
        if(CommonConst.RequestType.REQ_TYPE_POLICYCONFIRM_OTI.value.equals(requestType)){
            return this.retrieveConfigValueByKey(CORE_IG_APP_NAME, CORE_IG_CONFIRM_OTI_KEY);
        }
        if(CommonConst.RequestType.REQ_TYPE_ISSUEPOLICY.value.equals(requestType)){
            return this.retrieveConfigValueByKey(CORE_IG_APP_NAME, CORE_IG_ISSUE_KEY);
        }
        if(CommonConst.RequestType.REQ_TYPE_POLICYRENEWAL_OTI.value.equals(requestType)){
            return this.retrieveConfigValueByKey(CORE_IG_APP_NAME, CORE_IG_CONFIRM_OTI_KEY);
        }
        log.error("get post url error! Please check config[app_name:"+CORE_IG_APP_NAME+", key:"+CORE_IG_EHOME_KEY+"]");
        return null;
    }
    
    private byte[] sendXml(String xml, String url) throws IOException, SQLException, ClassNotFoundException {
        log.info("url:" + url);
        log.info("will send this xml:\n" + xml);
        log.debug("url:" + url);
        log.debug("will send this xml:\n" + xml);
        log.debug("HttpClient.isHttps:" + HttpClient.isHttps(url));
        InputStream ins = HttpClient.postString(url, xml, "UTF-8",60000);
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        int data = ins.read();
        while (data != -1) {
            baos.write(data);
            data = ins.read();
        }
        baos.close();
        return baos.toByteArray();
    }
    
    private String toString(byte[] bytes){
        String xml=null;
        try {
            xml = new String(bytes,CommonConst.UTF8);
        } catch (UnsupportedEncodingException e) {
            log.error("转换类型失败!",e);
        }
        return xml;
    }
    
    private String getSexMapForHome(String DB_sex){
        //在holder/insured表中sex字段值("1"/"2")
        if("1".equals(DB_sex)){
            return "M";
        }else if("2".equals(DB_sex)){
            return "F";
        }else{
            return "O";
        }
        
    }
    
    private String[] getUsernameAndPassword(){
        String homeUserAndPassword = this.retrieveConfigValueByKey(ANT, Config.HOME_USER_AND_PASSWOR_KEY);
        if(Beans.isNotEmpty(homeUserAndPassword) && homeUserAndPassword.contains(",")){
            return homeUserAndPassword.split(",");
        }
        log.error("配置中获取不到渠道账号信息：AppName: ANT");
        return null;
    }
    
    private String getHomeAgencyCode(){
        return this.retrieveConfigValueByKey(ANT, Config.HOME_AGENCY_KEY);
    }
    
    /**
     * 通过“行政区划代码”获取对应的省份，城市代码
     */
    public Map<String, String> getRegionCodeMap(String addressCode) throws Exception{
        Map<String, String> map = new HashMap<String, String>();
        Connection conn = null;
        PreparedStatement prep = null;
        ResultSet rs = null;
        try {
            conn = this.getDataSource().getConnection();
            String sql = "select t.country_code, t.province_code, t.city_code, t.postcode, t.city_name_zhs from prl_ant_city_ref t where t.address_code = ? ";
            prep = conn.prepareStatement(sql.toString());
            prep.setString(1, addressCode);
            rs = prep.executeQuery();
            if(rs.next()){
                map.put(RegionCode.CountryCode.value, rs.getString("country_code"));
                map.put(RegionCode.ProvinceCode.value, rs.getString("province_code"));
                map.put(RegionCode.CityCode.value, rs.getString("city_code"));
                map.put(RegionCode.Postcode.value, rs.getString("postcode"));
                map.put(RegionCode.CityNameZhs.value, rs.getString("city_name_zhs"));
                log.info("addressCode="+addressCode + 
                         ", ProvinceCode=" + map.get(RegionCode.ProvinceCode.value) + 
                         ", CityCode=" + map.get(RegionCode.CityCode.value) + 
                         ", Postcode=" + map.get(RegionCode.Postcode.value) + 
                         ", CityName=" + map.get(RegionCode.CityNameZhs.value));
            }
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            throw e;
        } finally {
            closeAll(conn, prep, rs);
        }
        return map;
    }
    
    public OrderDto findOrderByOrderNo(String order_no) throws Exception {
        OrderDto returnvalue = new OrderDto();
        Connection conn = null;
        PreparedStatement prep = null;
        ResultSet rs = null;
        try {
            conn = this.getDataSource().getConnection();
            String sql = "select order_no, product_code, out_product_code, summary_order_no, policy_type, premium, " + 
            " actual_premium, sum_insured, insuredtime, issuetime, effectstarttime, effectendtime, " + 
            " applynum, object_type, post_address, ehome_address, destination, underwrite_flag, " +          
            " status, db_error_msg, is_issued_success, policy_ref, is_policy_cancelable, " + 
            " updatetime, extendinfos, is_renewal, old_out_policy_no, next_continuous_time, address_code " + 
            " from prl_ant_inf_order t " +
            " where t.order_no = ? ";
            prep = conn.prepareStatement(sql.toString());
            prep.setString(1, order_no);
            rs = prep.executeQuery();
            if(rs.next()){
                returnvalue.setOrder_no(rs.getString("order_no"));
                returnvalue.setProduct_code(rs.getString("product_code"));
                returnvalue.setOut_product_code(rs.getString("out_product_code"));
                returnvalue.setSummary_order_no(rs.getString("summary_order_no"));
                returnvalue.setPolicy_type(rs.getString("policy_type"));
                returnvalue.setPremium(rs.getBigDecimal("premium"));
                returnvalue.setActual_premium(rs.getBigDecimal("actual_premium"));
                returnvalue.setSum_insured(rs.getBigDecimal("sum_insured"));
                returnvalue.setInsuredtime(rs.getTimestamp("insuredtime"));
                returnvalue.setIssuetime(rs.getTimestamp("issuetime"));
                returnvalue.setEffectstarttime(rs.getTimestamp("effectstarttime"));
                returnvalue.setEffectendtime(rs.getTimestamp("effectendtime"));
                returnvalue.setApplynum(rs.getObject("applynum") == null ? null : rs.getInt("applynum"));
                returnvalue.setObject_type(rs.getObject("object_type") == null ? null : rs.getInt("object_type"));
                returnvalue.setPost_address(rs.getString("post_address"));
                returnvalue.setEhome_address(rs.getString("ehome_address"));
                returnvalue.setDestination(rs.getString("destination"));
                returnvalue.setUnderwrite_flag(rs.getObject("underwrite_flag") == null ? null : rs.getInt("underwrite_flag"));
                returnvalue.setStatus(rs.getObject("status") == null ? null : rs.getInt("status"));
                returnvalue.setDb_error_msg(rs.getString("db_error_msg"));
                returnvalue.setIs_issue_success(rs.getString("is_issued_success"));
                returnvalue.setPolicy_ref(rs.getString("policy_ref"));
                //is_policy_cancelable
                //updatetime
                //extendInfos
                returnvalue.setIs_renewal(rs.getString("is_renewal"));
                returnvalue.setOld_out_policy_no(rs.getString("old_out_policy_no"));
                returnvalue.setNext_continuous_time(rs.getTimestamp("next_continuous_time"));
                returnvalue.setAddress_code(rs.getString("address_code"));
            }
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            throw e;
        } finally {
            closeAll(conn, prep, rs);
        }
        return returnvalue;
    }
    
    
    public HolderDto findHolderByOrderNo(String order_no) throws Exception {
        HolderDto returnvalue = new HolderDto();
        Connection conn = null;
        PreparedStatement prep = null;
        ResultSet rs = null;
        try {
            conn = this.getDataSource().getConnection();
            String sql = "select t.order_no, t.personno, t.certtype, t.accounttype, t.accountno, " + 
                        " t.accountname, t.certno, t.certname, t.extendinfos, t.resident_province, " + 
                        " t.resident_city, t.address, t.birth_day, t.sex, t.phone, " + 
                        " t.email, t.name_en " + 
                        " from prl_ant_inf_order_holder t " + 
                        " where t.order_no = ? ";
            prep = conn.prepareStatement(sql.toString());
            prep.setString(1, order_no);
            rs = prep.executeQuery();
            if(rs.next()){
                returnvalue.setOrder_no(rs.getString("order_no"));
                returnvalue.setPersonno(rs.getString("personno"));
                returnvalue.setCerttype(rs.getString("certtype"));
                returnvalue.setAccounttype(rs.getString("accounttype"));
                returnvalue.setAccountno(rs.getString("accountno"));
                returnvalue.setAccountname(rs.getString("accountname"));
                returnvalue.setCertno(rs.getString("certno"));
                returnvalue.setCertname(rs.getString("certname"));
                //returnvalue.setExtendInfos(extendInfos);
                returnvalue.setResident_province(rs.getString("resident_province"));
                returnvalue.setResident_city(rs.getString("resident_city"));
                returnvalue.setAddress(rs.getString("address"));
                returnvalue.setBirth_day(rs.getTimestamp("birth_day"));
                returnvalue.setSex(rs.getString("sex"));
                returnvalue.setPhone(rs.getString("phone"));
                returnvalue.setEmail(rs.getString("email")); 
                returnvalue.setNameEn(rs.getString("name_en"));
            }
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            throw e;
        } finally {
            closeAll(conn, prep, rs);
        }
        return returnvalue;
    }
    
    public List<InsuredDto> findInsuredListByOrderNo(String order_no) throws Exception {
        List<InsuredDto> returnList = new ArrayList<InsuredDto>();
        Connection conn = null;
        PreparedStatement prep = null;
        ResultSet rs = null;
        try {
            conn = this.getDataSource().getConnection();
            String sql = "select t.order_no, t.samewithholder, t.relationwithholder, t.personno, t.certtype, " + 
            "t.accounttype, t.accountno, t.accountname, t.certno, t.certname, " + 
            "t.extendinfos, t.resident_province, t.resident_city, t.address, t.birth_day, " + 
            "t.sex, t.phone, t.insured_type, t.email, t.name_en " + 
            "  from prl_ant_inf_order_insured t " + 
            " where t.order_no = ? ";
            prep = conn.prepareStatement(sql.toString());
            prep.setString(1, order_no);
            rs = prep.executeQuery();
            if(rs.next()){
                InsuredDto dto = new InsuredDto();
                dto.setOrder_no(rs.getString("order_no"));
                dto.setSameWithholder(rs.getObject("samewithholder") == null ? null : rs.getInt("samewithholder"));
                dto.setRelationWithholder(rs.getString("relationwithholder"));
                dto.setPersonno(rs.getString("personno"));
                dto.setCerttype(rs.getString("certtype"));
                dto.setAccounttype(rs.getString("accounttype"));
                dto.setAccountno(rs.getString("accountno"));
                dto.setAccountname(rs.getString("accountname"));
                dto.setCertno(rs.getString("certno"));
                dto.setCertname(rs.getString("certname"));
                //dto.setExtendInfos(extendInfos);
                dto.setResident_province(rs.getString("resident_province"));
                dto.setResident_city(rs.getString("resident_city"));
                dto.setAddress(rs.getString("address"));
                dto.setBirth_day(rs.getTimestamp("birth_day"));
                dto.setSex(rs.getString("sex"));
                dto.setPhone(rs.getString("phone"));
                dto.setInsuredType(rs.getString("insured_type"));
                dto.setEmail(rs.getString("email"));
                dto.setNameEn(rs.getString("name_en"));
                returnList.add(dto);
            }
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            throw e;
        } finally {
            closeAll(conn, prep, rs);
        }
        return returnList;
    }
    
    /**
     * 家财险接口出单成功,并完成issue保单，更新order状态等信息
     */
    private void updateOrderIssueSuccess(String order_no, String policyRef) throws Exception {
        Connection conn = null;
        PreparedStatement cst = null;     
        StringBuffer sql = new StringBuffer();
        sql.append("UPDATE PRL_ANT_INF_ORDER PT \n" + 
        "              SET PT.IS_ISSUED_SUCCESS = 1, \n" + 
        "                  PT.STATUS            = ?, \n" + 
        "                  PT.POLICY_REF        = ?, \n" + 
        "                  PT.ISSUETIME         = SYSDATE, \n" + 
        "                  pt.IS_POLICY_CANCELABLE = 0 \n" + 
        "             WHERE PT.ORDER_NO         = ? ");
        try {
            conn = this.getDataSource().getConnection();
            cst = conn.prepareStatement(sql.toString());
            cst.setString(1, Const.AntOrderStatus.IssueSuccess.value+"");
            cst.setString(2, policyRef);
            cst.setString(3, order_no);
            cst.executeUpdate();
        } catch (Exception e) {
            throw e;
        } finally {
            closeAll(conn,cst,null);
        }
    }
    
    /**
     * 更新order状态等信息
     */
    private void updateOrderWaitIssue(String order_no, String policyRef) throws Exception {
        Connection conn = null;
        PreparedStatement cst = null;     
        StringBuffer sql = new StringBuffer();
        sql.append("UPDATE PRL_ANT_INF_ORDER PT \n" + 
        "              SET PT.STATUS            = ?, \n" + 
        "                  PT.POLICY_REF        = ? \n" + 
        "             WHERE PT.ORDER_NO         = ? ");
        try {
            conn = this.getDataSource().getConnection();
            cst = conn.prepareStatement(sql.toString());
            cst.setString(1, Const.AntOrderStatus.WaitIssue.value+"");
            cst.setString(2, policyRef);
            cst.setString(3, order_no);
            cst.executeUpdate();
        } catch (Exception e) {
            throw e;
        } finally {
            closeAll(conn,cst,null);
        }
    }
    
    /**
     * 家财险接口出单失败，更新order状态等信息
     */
    private void updateOrderIssueFailure(String order_no, String errorMsg) throws Exception {
        Connection conn = null;
        PreparedStatement cst = null;     
        StringBuffer sql = new StringBuffer();
        sql.append("UPDATE PRL_ANT_INF_ORDER pt \n" + 
        "          SET PT.IS_ISSUED_SUCCESS = 0, \n" + 
        "              PT.STATUS = ?, \n" + 
        "              PT.DB_ERROR_MSG = ? \n" + 
        "        WHERE PT.ORDER_NO = ? ");
        try {
            conn = this.getDataSource().getConnection();
            cst = conn.prepareStatement(sql.toString());
            cst.setString(1, Const.AntOrderStatus.IssueFail.value+"");
            cst.setString(2, errorMsg);
            cst.setString(3, order_no);
            cst.executeUpdate();
        } catch (Exception e) {
            throw e;
        } finally {
            closeAll(conn,cst,null);
        }
    }
    
    public boolean isHomePlan(String planCode, Date effetiveDate) {
        return Const.SubProduct.Home.value.equals(this.getPlanProductCode(planCode, effetiveDate));
    }
    
    private String getPlanProductCode(String planCode, Date effetiveDate) {
        Connection conn = null;
        PreparedStatement cst = null;     
        ResultSet rs = null;
        StringBuffer sql = new StringBuffer();
        sql.append("SELECT S.PRODUCT_CODE \n" + 
        "             FROM PRL_EOPUS_PLANS S \n" + 
        "            WHERE S.PLAN_CODE = ? \n" + 
        "              AND S.STATUS = '1' \n" + 
        "              AND s.start_date<=? \n" + 
        "              AND (s.end_date IS NULL OR s.end_date+1>?)");
        try {
            conn = this.getDataSource().getConnection();
            cst = conn.prepareStatement(sql.toString());
            cst.setString(1, planCode);
            cst.setTimestamp(2, new Timestamp(effetiveDate.getTime()));
            cst.setTimestamp(3, new Timestamp(effetiveDate.getTime()));
            rs = cst.executeQuery();
            if (rs.next()) {
                return rs.getString("PRODUCT_CODE");
            }
        } catch (Exception e) {
            log.error("getPlanProductCode error...", e);
            return null;
        } finally {
            closeAll(conn,cst,rs);
        }
        return null;
    }
    
    private Date formatTimeZone(Date inDate){
        if(Beans.isEmpty(inDate)){
            return inDate;
        }
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String inStr = sdf.format(inDate);
            sdf.setTimeZone(TimeZone.getTimeZone("GMT+8"));
            return sdf.parse(inStr);
        } catch (ParseException e) {
            log.error("formatTimeZone error...", e);
        }
        return null;
    }
    
    private Integer getContractId(String policyRef){                                                             
        Connection conn = null;
        PreparedStatement prep = null;
        ResultSet result = null;
        StringBuffer sql = new StringBuffer();
        sql.append("select t.contract_id from prl_group_policy_versions t where t.policy_ref = ? ")
            .append("union all ")
            .append("select t.contract_id from prl_common_quote_policy_all t where t.policy_ref = ? ");
        try {
            conn = this.getDataSource().getConnection();
            prep = conn.prepareStatement(sql.toString());
            prep.setString(1, policyRef);
            prep.setString(2, policyRef);
            result = prep.executeQuery();
            if (result.next()){
                return result.getInt(1);
            }
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        } finally {
            this.closeAll(conn, prep, result);
        }
        return -1;
    }
    
    //保单状态查询
    public Integer getNewPolicyStatus(String policyRef){                                                             
        Connection conn = null;
        PreparedStatement prep = null;
        ResultSet result = null;
        StringBuffer sql = new StringBuffer();
        sql.append("select t.CONTRACT_STATUS from prl_common_quote_policy_all t where t.contract_id = ");
        sql.append("(SELECT CONTRACT_ID FROM prl_group_policy_versions where policy_ref = ?)");
        try {
            conn = this.getDataSource().getConnection();
            prep = conn.prepareStatement(sql.toString());
            prep.setString(1, policyRef);
            result = prep.executeQuery();
            if (result.next()){
                return result.getInt(1);
            }
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        } finally {
            this.closeAll(conn, prep, result);
        }
        return -1;
    }
    
    private PaymentInfoDto getPaymentInfo(Integer contractId, String orderNo){
        Connection conn = null;
        PreparedStatement prep = null;
        ResultSet result = null;
        StringBuffer sql = new StringBuffer();
        PaymentInfoDto dto = null;
        sql.append(" SELECT a.contract_id, \n" + 
        "  a.installment_no, \n" + 
        "  b.policy_ref,\n" + 
        "  a.payer payer_partner_ref, \n" + 
        "  a.amount_swf currency, \n" + 
        "  b.bill_type_method_of_payment payment_mode,\n" + 
        "  NULL endpoint_code,\n" + 
        "  NULL drawer_bank_acc_no,\n" + 
        "  NULL pos_location_code \n" + 
        "FROM prl_installment_plan a, \n" + 
        "     wip_policy_bases b \n" + 
        "WHERE a.contract_id = ? \n" + 
        "AND a.contract_id = b.contract_id \n" + 
        "AND NOT EXISTS (select 1 \n" + 
        "                  from prl_acc_soa \n" + 
        "                 where contract_id = a.contract_id \n" + 
        "                   and process = 'Y' \n" + 
        "                   and installment_no = a.installment_no) \n");
        try {
            conn = this.getDataSource().getConnection();
            prep = conn.prepareStatement(sql.toString());
            prep.setInt(1, contractId);
            result = prep.executeQuery();
            if (result.next()){
                dto = new PaymentInfoDto();
                dto.setContract_id(result.getInt("contract_id"));
                dto.setInstallment_no(result.getString("installment_no"));
                dto.setPolicy_ref(result.getString("policy_ref"));
                dto.setPayer_partner_ref(result.getString("payer_partner_ref"));
                dto.setCurrency(result.getString("currency"));
                dto.setPayment_mode(result.getString("payment_mode"));
                dto.setEndpoint_code(result.getString("endpoint_code"));
                dto.setDrawer_bank_acc_no(result.getString("drawer_bank_acc_no"));
                dto.setTo_bank_code(Const.ALIPAY_BANK_CODE);
                dto.setPos_location_code(result.getString("pos_location_code"));
            }
            
            String sqlOrd = "select bill.order_no, bill.fee/100 amount, bill.paytime from prl_ant_inf_order_bill bill where bill.order_no = ? ";
            prep = conn.prepareStatement(sqlOrd);
            prep.setString(1, orderNo);
            result = prep.executeQuery();
            if (result.next() && Beans.isNotEmpty(dto)){
                dto.setAmount(result.getBigDecimal("amount"));
                dto.setPaytime(result.getTimestamp("paytime"));
                dto.setOrder_no(result.getString("order_no"));
            }
            return dto;
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        } finally {
            this.closeAll(conn, prep, result);
        }
        return null;
    }
    /**
     *获取bill信息
     * @param orderNo
     * @return
     */
    private PaymentInfoDto getBillInfo(String orderNo){
        log.info("获取支付订单getBillInfo-orderNo: " + orderNo);
        Connection conn = null;
        PreparedStatement prep = null;
        ResultSet result = null;
        PaymentInfoDto dto = new PaymentInfoDto();
        try {
            conn = this.getDataSource().getConnection();      
            String sqlOrd = "select bill.order_no, bill.fee/100 amount, bill.paytime from prl_ant_inf_order_bill bill where bill.order_no = ? ";
            prep = conn.prepareStatement(sqlOrd);
            prep.setString(1, orderNo);
            result = prep.executeQuery();
            if (result.next()){
                dto.setAmount(result.getBigDecimal("amount"));
                dto.setPaytime(result.getTimestamp("paytime"));
                dto.setOrder_no(result.getString("order_no"));
            }
            return dto;
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        } finally {
            this.closeAll(conn, prep, result);
        }
        return null;
    }
    
    /**
     * 判断是否超过配置的投保次数(成功出单，不看承保区间)
     * 配置表 prpl_app_parameter
     * key： limitTimes. + palnCode  
     */
    public boolean overLimitTimes(String outProductCode, String holderCertno){
        String val = this.retrieveConfigValueByKey("ANT", "limitTimes."+outProductCode);
        if(Beans.isEmpty(val)){
            log.info("limitTimes is not config. OutProductCode:"+outProductCode);
            return false;
        }else{
            try{
                Integer times = Integer.parseInt(val);
                int insureTimes = this.getInsureTimes(outProductCode, holderCertno);
                if(insureTimes >= times){
                    log.info("超过配置的出单次数. OutProductCode:"+outProductCode + ", limitTimes:" + times + ", insureTimes:" + insureTimes);
                    return true;
                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }
        return false;
    }
    
    
    private int getInsureTimes(String outProductCode, String holderCertno){
        Connection conn = null;
        PreparedStatement prep = null;
        ResultSet rs = null;
        int times = 0;
        String sql = "select count(*) from prl_ant_inf_order o, \n" + 
        "prl_ant_inf_order_holder h " + 
        "where o.order_no = h.order_no " + 
        "and o.out_product_code = ? " + 
        "and h.certno = ? " + 
        "and o.policy_ref is not null ";
        try {
            conn = this.getDataSource().getConnection();
            prep = conn.prepareStatement(sql);
            prep.setString(1, outProductCode);
            prep.setString(2, holderCertno);
            rs = prep.executeQuery();
            if (rs.next()) {
                times = rs.getInt(1);
            }
        } catch (Exception e) {
            log.error(e);
        } finally {
            closeAll(conn, prep, rs);
        }
        log.info("outProductCode="+outProductCode+", holder Certno="+holderCertno+", InsureTimes="+times);
        return times;
    }
    
    
    public String getOTIInsuredType(String planCode, int age, Date effStartDate){
        Connection conn = null;
        PreparedStatement prep = null;
        ResultSet rs = null;
        String insuredType = null;
        log.info("planCode="+planCode+", age="+age+", effStartDate="+effStartDate);
        String sql = "select itype.insured_type from prl_eopus_plans plans, \n" + 
                "prl_eopus_plan_ben_rate rate, \n" + 
                "prl_eopus_insured_type itype \n" + 
                "where plans.plan_code = ? \n" + 
                "and plans.status = '1' \n" + 
                "and plans.start_date <= ? \n" + 
                "and (plans.end_date is null or plans.end_date >= ?) \n" + 
                "and plans.plan_id = rate.plan_id \n" + 
                "and plans.version_no = rate.plan_version_no \n" + 
                "and plans.plan_type = rate.plan_type \n" + 
                "and rate.insured_type = itype.insured_type  \n" + 
                "and itype.age_from <= ? \n" + 
                "and itype.age_to >= ? ";
        try {
            conn = this.getDataSource().getConnection();
            prep = conn.prepareStatement(sql);
            prep.setString(1, planCode);
            prep.setDate(2, DateUtil.convertUtilDateToSQLDate(effStartDate));
            prep.setDate(3, DateUtil.convertUtilDateToSQLDate(effStartDate));
            prep.setInt(4, age);
            prep.setInt(5, age);
            rs = prep.executeQuery();
            if (rs.next()) {
                insuredType = rs.getString("insured_type");
            }
        } catch (Exception e) {
            log.error(e);
        } finally {
            closeAll(conn, prep, rs);
        }
        log.info("insuredType="+insuredType);
        return insuredType;
    }
    
    
    public boolean checkPlanAssignment(int planId, String planCode, Date effStartDate){
        //是否开启了校验计划授权校验
        if(!"Y".equals(this.retrieveConfigValueByKey(ANT, Config.CHECK_PLAN_ASSIGNMENT_KEY))){
            log.info("Do NOT check plan assignment!  Close by config");
            return true;
        }
        //是否开启线上退保？开启后，需要校验授权新增字段
        boolean isOpenOnlineCancel = "Y".equals(this.retrieveConfigValueByKey(ANT, Config.OPEN_ONLINE_CANCEL_POLICY_KEY));
        
        log.info("Check plan assignment! planCode:"+planCode+", planId="+planId+", effStartDate="+effStartDate);
        Connection conn = null;
        PreparedStatement prep = null;
        ResultSet rs = null;
        String sql = "select 1 \n" + 
        "from prl_reference pr, \n" + 
        "prl_eopus_plan_assignment pa, \n" + 
        "prl_intermediary_v_search vs \n" + 
        "where pr.reference_name = 'TAOBAO_CHANNEL_ID' \n" + 
        "and pr.status = 'A' \n" + 
        "and pr.value_number = vs.Part_id \n" + 
        "and pa.int_id = vs.Int_id \n" + 
        "and pa.status = '1' \n" + 
        "and pa.plan_id = ? \n" + 
        "and pa.start_date <= ? \n" + 
        "and (pa.end_date is null or pa.end_date >= ?) ";
        if(isOpenOnlineCancel){
            //Inforce_fee_flag 生效前不计提，生效后计提标记    1.默认为空 - 生效前/生效后都以endorse_fee_flag字段为准      2.Y - 生效前不计提， 生效后计提
            //operate_right    默认值为：#，  #NC# - 该渠道该计划保单不能通过保司进行退保 （如：对接 支付宝线上退保计划，不允许通过保司任何方式退保）
            sql = sql + " and pa.operate_right is not null "; 
            log.info("开启线上退保功能! 计划授权表必须配置operate_right / inforce_fee_flag 等信息");
        }
        
        try {
            conn = this.getDataSource().getConnection();
            prep = conn.prepareStatement(sql);
            prep.setInt(1, planId);
            prep.setDate(2, DateUtil.convertUtilDateToSQLDate(effStartDate));
            prep.setDate(3, DateUtil.convertUtilDateToSQLDate(effStartDate));
            rs = prep.executeQuery();
            if (rs.next()) {
                return true;
            }
        } catch (Exception e) {
            log.error(e);
        } finally {
            closeAll(conn, prep, rs);
        }
        log.info("plan Not assignment!");
        return false;
    }
    
    
    public boolean isCheckOTIPremium(boolean isRenewalFlag){
        if(isRenewalFlag){
            return "Y".equals(this.retrieveConfigValueByKey(ANT, Config.CHECK_OTI_PREMIUM_RENEWAL_KEY)); //续保
        }
        return "Y".equals(this.retrieveConfigValueByKey(ANT, Config.CHECK_OTI_PREMIUM_NEW_KEY)); //新单
    }
    
    //不需校验保费 白名单
    public boolean isCheckOTIPremiumWhiteList(String planCode){
        String reval = this.retrieveConfigValueByKeyAndSubValue(ANT, Config.CHECK_OTI_PREMIUM_WHITE_LIST_KEY, ","+planCode+","); //计划代码前后都要有逗号(,)
        if(Beans.isNotEmpty(reval)){
            return true;
        }
        return false;
    }
    
    public GroupPlanInfoDto getGroupPlanInfo(String groupPlanCode){
        GroupPlanInfoDto dto = null;
        Connection conn = null;
        PreparedStatement prep = null;
        ResultSet rs = null;
        String sql = "select t.group_plan_code, \n" + 
        "t.renewable_max_age \n" + 
        "from prl_eopus_group_plans t \n" + 
        "where t.group_plan_code = ? \n" + 
        "and t.status = '1'";
        try {
            conn = this.getDataSource().getConnection();
            prep = conn.prepareStatement(sql);
            prep.setString(1, groupPlanCode);
            rs = prep.executeQuery();
            if (rs.next()) {
                dto = new GroupPlanInfoDto();
                dto.setGroupPlanCode(groupPlanCode);
                dto.setRenewableMaxAge(rs.getInt("renewable_max_age"));
                log.info("groupPlanCode:" + groupPlanCode+ ", max age:"+rs.getInt("renewable_max_age"));
            }
        } catch (Exception e) {
            log.error(e);
        } finally {
            closeAll(conn, prep, rs);
        }
        return dto;
    }
    
    /**
     * Common限制校验
     * 1.如臻爱产品的投保次数(校验投保人的手机号码，证件号码)
     * 2. ....
     * return "" - 通过校验
     */
    public String validateCommonLimit(OrderDto orderDto, HolderDto holderDto, List<InsuredDto> insuredDtoList, PlanInfoDto planinfo){
        //校验投保次数
        if("Y".equals(this.retrieveConfigValueByKey("ANT", Config.CHECK_INSURE_TIMES_KEY))){
            log.info("开启校验投保次数...");
            if(Beans.isNotEmpty(insuredDtoList)){
                for(InsuredDto insuredDto : insuredDtoList){
                    //投保人 投保次数
                    String relationship_AZ = Const.relationshipMap.get(insuredDto.getRelationWithholder());
                    if(!this.validateInsureTimes(orderDto, holderDto, planinfo, relationship_AZ)){
                        return "overTimeLimit";
                    }
                    //被保险人 投保次数
                    if(!this.validateInsurantTimes(orderDto, insuredDto, planinfo)){
                        return "overInsurantTimeLimit";
                    }
                }
            }
        }else{
            log.info("关闭校验投保次数...");
        }
        
        return "";
    }
    
    
    /**
     *  校验 投保人投保次数
     *  true - 通过校验
     *  false - 不通过校验
     */
    private boolean validateInsureTimes(OrderDto orderDto, HolderDto holderDto, PlanInfoDto planinfo, String relationship_AZ){
        //获取投保次数与被保人关系映射
        List<Map<String, String>> insureTimeLimitList = this.getInsureTimeLimitList(planinfo.getPlanCode(), planinfo.getGroupPlanName());
        if(Beans.isNotEmpty(insureTimeLimitList)){
            for(Map<String, String> map : insureTimeLimitList){
                String relation = map.get("relation");
                int insureTimeLimit = -1;
                try{
                    insureTimeLimit = Integer.parseInt(map.get("times"));
                }catch(Exception e){
                    log.error(e.getMessage(), e);
                }
                if(Beans.isEmpty(relation) || relation.equals(relationship_AZ)){
                    //投保人 手机号码
                    String sql = "SELECT count(distinct ins.contract_id) " + 
                                "  FROM prl_part_plan_ins_ext ins, prl_eopus_plans p, prl_ip_ext pie " + 
                                " where ins.action_code <> 'D' " + 
                                "   and ins.top_indicator = 'Y' " + 
                                "   and ins.plan_id = p.plan_id " + 
                                "   and ins.plan_version_no = p.version_no " + 
                                (Beans.isNotEmpty(map.get("planCode")) ? " and p.plan_code = ? " : " and p.group_plan_name = ? ") + 
                                "   and ins.contract_id = pie.contract_id " + 
                                "   and pie.ip_no = 2 " + 
                                "   and pie.action_code <> 'D' " + 
                                "   and pie.top_indicator = 'Y' " + 
                                "   and pie.hotline_tel_no = ? " + 
                                (Beans.isNotEmpty(relation) ? " and ins.policyholder_relation = '"+relationship_AZ+"' " : "") + 
                                "   and exists (SELECT ppa.contract_status " + 
                                "          FROM prl_common_quote_policy_all ppa " + 
                                "         where ppa.contract_id = ins.contract_id " + 
                                "           and ppa.contract_status <> '80' and ppa.term_start_date > to_date(? , 'yyyy-mm-dd hh24:mi:ss') )";
                    String planCodeOrGroupPlanName = Beans.isNotEmpty(map.get("planCode")) ? map.get("planCode") : map.get("groupPalnName");
                    BigDecimal hasinsureTime = (BigDecimal)this.exeSelectValueSql(sql, planCodeOrGroupPlanName, holderDto.getPhone(), DateUtils.formatTimeStamp(DateUtils.getDateTimeOfLastYear(orderDto.getEffectstarttime())));
                    if(Beans.isNotEmpty(hasinsureTime) && insureTimeLimit != -1 && hasinsureTime.intValue() >= insureTimeLimit){
                        log.info("手机号码 - 超过投保次数! order_no=" + orderDto.getOrder_no() + ", holderPhone=" + holderDto.getPhone() + ", hasinsureTime=" + hasinsureTime + ", insureTimeLimit=" +insureTimeLimit);
                        return false;
                    }
                    //投保人 证件号码
                    sql = "SELECT count(distinct ins.contract_id) " + 
                        "  FROM prl_part_plan_ins_ext ins, prl_eopus_plans p, prl_ip_ext pie " + 
                        " where ins.action_code <> 'D' " + 
                        "   and ins.top_indicator = 'Y' " + 
                        "   and ins.plan_id = p.plan_id " + 
                        "   and ins.plan_version_no = p.version_no " + 
                        (Beans.isNotEmpty(map.get("planCode")) ? " and p.plan_code = ? " : " and p.group_plan_name = ? ") + 
                        "   and ins.contract_id = pie.contract_id " + 
                        "   and pie.ip_no = 2 " + 
                        "   and pie.action_code <> 'D' " + 
                        "   and pie.top_indicator = 'Y' " + 
                        "   and pie.policy_no = ? " + 
                        (Beans.isNotEmpty(relation) ? " and ins.policyholder_relation = '"+relationship_AZ+"' " : "") + 
                        "   and exists (SELECT ppa.contract_status " + 
                        "          FROM prl_common_quote_policy_all ppa " + 
                        "         where ppa.contract_id = ins.contract_id " + 
                        "           and ppa.contract_status <> '80' and ppa.term_start_date > to_date(? , 'yyyy-mm-dd hh24:mi:ss') )";
                    hasinsureTime = (BigDecimal)this.exeSelectValueSql(sql, planCodeOrGroupPlanName, holderDto.getCertno(), DateUtils.formatTimeStamp(DateUtils.getDateTimeOfLastYear(orderDto.getEffectstarttime())));
                    if(Beans.isNotEmpty(hasinsureTime) && insureTimeLimit != -1 && hasinsureTime.intValue() >= insureTimeLimit){
                        log.info("证件号 - 超过投保次数! order_no=" + orderDto.getOrder_no() + ", holderCertno=" + holderDto.getCertno() + ", hasinsureTime=" + hasinsureTime + ", insureTimeLimit=" +insureTimeLimit);
                        return false;
                    }
                }
            }
        }      
        return true;
    }
    
    
    /**
     *  校验 被保险人投保次数
     *  true - 通过校验
     *  false - 不通过校验
     */
    private boolean validateInsurantTimes(OrderDto orderDto, InsuredDto insuredDto, PlanInfoDto planinfo){
        //获取被保险人限制投保次数
        Integer timeLimit = this.getInsurantTimeLimitList(planinfo.getGroupPlanName());
        if(Beans.isNotEmpty(timeLimit) && Beans.isNotEmpty(insuredDto.getCertno())){
            //被保险人 证件号
            String sql = "select count(*) " + 
                        "  from prl_part_plan_ins_ext ins, prl_eopus_plans p " + 
                        " where ins.action_code <> 'D' " + 
                        "   and ins.top_indicator = 'Y' " + 
                        "   and ins.plan_id = p.plan_id " + 
                        "   and ins.plan_version_no = p.version_no " + 
                        "   and p.group_plan_name = ? " + 
                        "   and ins.id_no = ? " + 
                        "   and ins.end_date >= to_date(? , 'yyyy-mm-dd hh24:mi:ss') " + 
                        "   and ins.start_date <= to_date(? , 'yyyy-mm-dd hh24:mi:ss') " + 
                        "   and exists (SELECT ppa.contract_status " + 
                        "                from  prl_common_quote_policy_all ppa " + 
                        "               where ppa.contract_id = ins.contract_id " + 
                        "                 and ppa.contract_status <> '80') ";
            
            BigDecimal hasinsureTime = (BigDecimal)this.exeSelectValueSql(sql, planinfo.getGroupPlanName(), insuredDto.getCertno().trim(), DateUtils.formatTimeStamp(orderDto.getEffectstarttime()), DateUtils.formatTimeStamp(orderDto.getEffectendtime()));
            if(Beans.isNotEmpty(hasinsureTime) && timeLimit != -1 && hasinsureTime.intValue() >= timeLimit){
                log.info("被保险人【"+insuredDto.getCertname()+"】- 超过投保次数! order_no=" + orderDto.getOrder_no() + ", Certno=" + insuredDto.getCertno() + ", hasinsureTime=" + hasinsureTime + ", timeLimit=" +timeLimit);
                return false;
            }
        }      
        return true;
    }
    
    
    /**
     * 获取配置的被保险人关系投保次数
     */
    private List<Map<String, String>> getInsureTimeLimitList(String planCode, String groupPlanName){
        //投保次数限制：产品(可配置调整)plan_code  被保险人与投保人关系policy_type 次数(可配置调整)agent_part_id
        List<Map<String, String>> list = new ArrayList<Map<String, String>>();
        Connection conn = null;
        PreparedStatement prep = null;
        ResultSet rs = null;
        String sql = "select  spa.agent_part_id as times, " + 
        "spa.plan_code as plan_code, " + 
        "spa.message_template as group_paln_name, " + 
        "spa.policy_type as relation " + 
        "from  prl_sendmessage_product_agent spa " + 
        "where spa.state = ? " + 
        "and spa.message_type = ? " + 
        "and (spa.plan_code = ? or spa.message_template= ? )";
        try {
            conn = this.getDataSource().getConnection();
            prep = conn.prepareStatement(sql);
            prep.setString(1, EtravelConst.TRUE);
            prep.setString(2, EtravelConst.AgentMessageType.InsureTimeLimit.value); //06
            prep.setString(3, planCode);
            prep.setString(4, groupPlanName);
            rs = prep.executeQuery();
            while (rs.next()) {
                Map<String, String> map = new HashMap<String, String>();
                map.put("times", rs.getString("times"));
                map.put("planCode", rs.getString("plan_code"));
                map.put("groupPalnName", rs.getString("group_paln_name"));
                map.put("relation", rs.getString("relation"));
                list.add(map);
            }
        } catch (Exception e) {
            log.error(e);
        } finally {
            closeAll(conn, prep, rs);
        }
        return list;
    }
    
    
    /**
     * 获取配置的被保险人投保次数
     * 被保人重复投保校验,按证件号。根据产品名称维度配置，可配置重复次数，需支持多产品名称的情况，比如配置“臻爱医疗2016，2次”。
     */
    private Integer getInsurantTimeLimitList(String groupPlanName){
        //InsuredInsurancePeriodDuplicateLimit("12");//产品(可配置调整)message_template 次数(可配置调整)agent_part_id;
        Integer times = null;
        Connection conn = null;
        PreparedStatement prep = null;
        ResultSet rs = null;
        String sql = "select spa.agent_part_id " + 
        " from  prl_sendmessage_product_agent spa " + 
        " where spa.state = ? " + 
        " and spa.message_type = ? " + 
        " and spa.message_template = ? ";
        try {
            conn = this.getDataSource().getConnection();
            prep = conn.prepareStatement(sql);
            prep.setString(1, EtravelConst.TRUE);
            prep.setString(2, EtravelConst.AgentMessageType.InsuredInsurancePeriodDuplicateLimit.value); //12
            prep.setString(3, groupPlanName);
            rs = prep.executeQuery();
            while (rs.next()) {
                times = rs.getInt("agent_part_id");
            }
        } catch (Exception e) {
            log.error(e);
        } finally {
            closeAll(conn, prep, rs);
        }
        return times;
    }
    
    /**
     *  Order表中添加错误信息
     */
    public void updateErrorMsgToOrder(String order_no, String errorMg){
        Connection conn = null;
        PreparedStatement cst = null;     
        String sql = "update prl_ant_inf_order t set t.db_error_msg = substr(?, 0, 299) where t.order_no = ? ";
        try {
            conn = this.getDataSource().getConnection();
            cst = conn.prepareStatement(sql.toString());
            cst.setString(1, errorMg);
            cst.setString(2, order_no);
            cst.executeUpdate();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            closeAll(conn,cst,null);
        }
    }
    
    
    //根据不同的计算方式，计算保费
    private BigDecimal calculatePremium(BigDecimal basePremium, String calMethod, String planCode, Integer planVersionNo, Integer period, Date startDate, Date endDate){
        /*
        按区间计算  保费 = 配置
        按天计算    保费 = 配置 * 天数
        按月计算    保费 = 配置 * 月数
        按年计算    保费 = 配置 
        按比例计算  保费 = 配置/365 * 承保天数
        按短期费率计算  保费 = 配置 * 匹配到的比率(prl_eopus_factors)
        按年计算新      保费= 配置 * 匹配到的比率(prl_eopus_factors)
        按年计算(宠物)  --暂不支持
        固定保费（原613计算方式） 保费 = 配置
         */
        String calMethodDesc = null;
        BigDecimal reValue = basePremium;
        BigDecimal basePrem = basePremium;
        if(Const.CalMethod.Period.value.equals(calMethod)){
            calMethodDesc = "按区间计算";
            reValue = basePrem;
        }else if(Const.CalMethod.Day.value.equals(calMethod)){
            calMethodDesc = "按天计算";
            reValue = basePrem.multiply(new BigDecimal(period));
        }else if(Const.CalMethod.Month.value.equals(calMethod)){
            calMethodDesc = "按月计算";
            Integer months = AntModelUtil.getBetweenMonth(startDate, endDate);
            reValue = basePrem.multiply(new BigDecimal(months));
        }else if(Const.CalMethod.Year.value.equals(calMethod)){
            calMethodDesc = "按年计算";
            reValue = basePrem;
        }else if(Const.CalMethod.Rate.value.equals(calMethod)){
            //按比例计算  (保费 = 配置/365 * 承保天数)
            calMethodDesc = "按比例计算";
            int yearDays = AntModelUtil.isLeapYear(startDate, endDate) ? 366 : 365;
            reValue = basePrem.divide(new BigDecimal(Long.toString(yearDays)),10,RoundingMode.HALF_UP).multiply(new BigDecimal(period));
        }else if(Const.CalMethod.Term.value.equals(calMethod)){
            calMethodDesc = "按短期费率计算";
            BigDecimal factors = getFactors(planCode, period, planVersionNo);
            reValue = factors == null ? basePrem : basePrem.multiply(factors);
        }else if(Const.CalMethod.NewYear.value.equals(calMethod)){
            calMethodDesc = "按年计算新";
            BigDecimal factors = getFactors(planCode, period, planVersionNo);
            reValue = factors == null ? basePrem : basePrem.multiply(factors);
        }else if(Const.CalMethod.YearForPet.value.equals(calMethod)){
            calMethodDesc = "按年计算(宠物)";
            //614宠物险，CGB接口暂不支持， 计算该保费需要提供宠物性别，宠物类型用于prl_eopus_plan_ben_rate.sex, prl_eopus_plan_ben_rate.object_type判断
        }else if(Const.CalMethod.Fixed.value.equals(calMethod)){
            calMethodDesc = "固定保费（原613计算方式）";
            reValue = basePrem;
        }
        reValue = reValue.setScale(2, RoundingMode.HALF_UP);
        log.info("calMethod: " + calMethod + "("+calMethodDesc+"), 基础费率：" + basePremium + ", 计算后保费：" + reValue);
        return reValue;
    }
    
    
    /**
     *  获取费率因素值
     * --短期费率、按年计算新  计算保费比率， 计算方式：保费=计划配置费率 * 匹配到的比率
       SELECT * FROM prl_eopus_factors  WHERE factor_type = (select distinct p.product_code from prl_eopus_plans p where p.plan_code = 'xxxxx');
     */
    private BigDecimal getFactors(String planCode, Integer period, Integer planVersionNo){
        BigDecimal reval = null;
        String sql = "SELECT f.VALUE \n" + 
        "  FROM prl_eopus_factors f \n" + 
        " WHERE (f.number_from is null or f.number_from <= ?) \n" + 
        "  and (f.number_to is null or f.number_to >= ?) \n" + 
        "  and f.factor_type = (select distinct p.product_code \n" + 
        "                        from prl_eopus_plans p \n" + 
        "                       where p.plan_code = ? \n" + 
        "                        and p.version_no = ? ) ";
        Connection conn = null;
        PreparedStatement prep = null;
        ResultSet rs = null;
        try {
            conn = this.getDataSource().getConnection();
            prep = conn.prepareStatement(sql);
            prep.setInt(1, period);
            prep.setInt(2, period);
            prep.setString(3, planCode);
            prep.setInt(4, planVersionNo);
            rs = prep.executeQuery();
            while (rs.next()) {
                reval = rs.getBigDecimal("VALUE");
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            this.closeAll(conn, prep, rs);
        }
        log.info("getFactors planCode=: " + planCode + ", period=" + period + ", value=" +reval);
        return reval;
    }
    
    
    private String retrieveConfigValueByKeyAndSubValue(String appname,String key, String subValue) {
        Connection conn = null;
        PreparedStatement prep = null;
        ResultSet rs = null;
        String value = null;
        StringBuffer sqlBuff = new StringBuffer();
        sqlBuff.append("select value from prpl_app_parameter where app_name=? and status='1' and key=? and value like '%" + subValue + "%'");
        try {
            conn = this.getDataSource().getConnection();
            prep = conn.prepareStatement(sqlBuff.toString());
            prep.setString(1, appname);
            prep.setString(2, key);
            rs = prep.executeQuery();
            if (rs.next()) {
                value = rs.getString(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
            log.error(e);
        } finally {
            closeAll(conn, prep, rs);
        }
        return value;
    }
    /**
     *计算退保保费
     * @return
     */
    @Override
    public BigDecimal getCancelFee(String cancleOrderNo,Date EndorseTime){
        Integer contractId = 0;
        Map<String, Object> result = new HashMap<String, Object>();
        OrderDto orderDto = null;
        Connection conn = null;
        CallableStatement st = null;
        try {
            orderDto = findOrder(cancleOrderNo);
            if(Beans.isEmpty(orderDto)){
                log.error("getCancelFee error. 没有找到保单信息 rderNo:"+cancleOrderNo);
                return null;
            }
            contractId = this.getContractId(orderDto.getPolicy_ref());
            log.info("inParam----> orderNo:"+cancleOrderNo+", contractId:"+contractId+", Policy_ref:"+orderDto.getPolicy_ref()
                 +", EndorseTime:"+EndorseTime.toString());
            conn = this.getDataSource().getConnection();
            conn.setAutoCommit(false);
            st = conn.prepareCall("{? = call Prl_pk2_oti.get_ocp_cancel_premium(?,?,?,?)}");
            st.registerOutParameter(1, Types.FLOAT);
            //p_contract_id    IN NUMBER
            st.setObject(2, contractId);
            //p_effective_date IN DATE,
            st.setObject(3, Beans.isNotEmpty(EndorseTime)? new java.sql.Timestamp(EndorseTime.getTime()) : null);
            //p_return_prem    OUT NUMBER
            st.registerOutParameter(4, Types.DECIMAL);
            //p_error_message  OUT VARCHAR2
            st.registerOutParameter(5, Types.VARCHAR);
            st.execute();
            boolean resultFlag = st.getBoolean(1);
            log.info("p_return_prem-->" + st.getObject(4));
            log.info("p_error_message-->"+st.getObject(5));
            //p_error_message         OUT   VARCHAR2
            result.put("p_error_message", st.getString(5));
            if (!resultFlag) {
                //p_return_prem           OUT   Decimal,
                result.put("p_return_prem", st.getBigDecimal(4));
                return st.getBigDecimal(4);
            } else {
                log.error("调用存储过程calculate refund premium出错，返回p_error_message：" + result.get("p_error_message"));
                return null;
            }
        } catch (Exception e) {
            log.error("calculate refund premium error.", e);
            try {
                conn.rollback();
            } catch (SQLException f) {
                log.error(f.getMessage(),f);
            }
            return null;
        } finally {
            closeAll(conn, st, null);
        }
    }
    /**
     *退保package
     * @param info
     * @return
     * @throws Exception
     */
    @Override
    public Object endorsementCancellation(EndorsementInfo info) throws Exception {
        log.info("---policy_cancellation---start---");
        String p_result = null;
        CallableStatement cbStatment = null;
        PreparedStatement prepFind = null;
        Connection conn = null;
        try {
            conn = this.getDataSource().getConnection();//Prl_pk2_oti.policy_cancellation
            cbStatment = conn.prepareCall("begin Prl_pk2_oti.policy_cancellation(?,?,?,?,?,?,?,?,?,?,?,?);end;");
            cbStatment.setObject(1, info.getContractId());
            cbStatment.setObject(2, Beans.isNotEmpty(info.getEffectiveDate())? new java.sql.Timestamp(info.getEffectiveDate().getTime()) : null);
            cbStatment.setObject(3, info.getEndorCode());
            cbStatment.setObject(4, info.getReason());
            cbStatment.setObject(5, info.getBankAccount());
            cbStatment.setObject(6, info.getBankName());
            cbStatment.setObject(7, info.getUserName());
            cbStatment.registerOutParameter(8, Types.VARCHAR);
            cbStatment.setObject(9, Beans.isNotEmpty(info.getCancelDate())? new java.sql.Timestamp(info.getCancelDate().getTime()) : null);
            cbStatment.setObject(10, null);
            cbStatment.setObject(11, Const.ANT_APPNAME);
            cbStatment.setObject(12, Beans.isNotEmpty(info.getLopProdType()) ? info.getLopProdType() : null);
            log.info("p_contract_id=" + info.getContractId() + ", p_endor_date=" + info.getEffectiveDate() + ", p_endor_code=" + info.getEndorCode()
                + ", p_reason=" + info.getReason() + ", p_fix_return_prem=" + info.getLopProdType());
            cbStatment.execute();
            
            p_result = cbStatment.getString(8);
            log.info("---p_result---start---" + p_result);
        } catch (Exception e) {
            throw e;
        } finally {
            closeAll(conn, prepFind, null);
            try{ 
                if(cbStatment != null)
                    cbStatment.close();
            }catch(Exception e){
                e.printStackTrace();
            }
        }
        return p_result;
    }
    /**
     *更新prl_ant_inf_order by ORDER_NO
     * @param orderDto
     * @throws Exception
     */
    @Override
    public void updateOrder(OrderDto orderDto) throws Exception {
        Connection conn = this.getDataSource().getConnection();
        PreparedStatement cst = null;            
        StringBuffer sql = null;
        sql = new StringBuffer("update prl_ant_inf_order set PRODUCT_CODE = ?, OUT_PRODUCT_CODE = ?, SUMMARY_ORDER_NO = ?,POLICY_TYPE = ?, PREMIUM = ?, ACTUAL_PREMIUM = ?, SUM_INSURED = ?,EFFECTSTARTTIME = ?," + 
        " EFFECTENDTIME = ?, APPLYNUM = ?, OBJECT_TYPE = ?, UNDERWRITE_FLAG = ?, STATUS = ?,post_address = ?,ehome_address = ?,DESTINATION = ?,address_code = ?," + 
        " EXTENDINFOS = ?, IS_RENEWAL = ?, OLD_OUT_POLICY_NO = ? " + 
        " where ORDER_NO = ? ");
        try {
            cst = conn.prepareStatement(sql.toString());   
            cst.setString(1, orderDto.getProduct_code());
            cst.setString(2, orderDto.getOut_product_code());
            cst.setString(3, orderDto.getSummary_order_no());
            cst.setString(4, orderDto.getPolicy_type());
            cst.setBigDecimal(5, orderDto.getPremium());
            cst.setBigDecimal(6, orderDto.getActual_premium());
            cst.setBigDecimal(7, orderDto.getSum_insured());
            cst.setTimestamp(8, Beans.isEmpty(orderDto.getEffectstarttime())? null : new Timestamp(orderDto.getEffectstarttime().getTime()));
            cst.setTimestamp(9, Beans.isEmpty(orderDto.getEffectendtime())? null : new Timestamp(orderDto.getEffectendtime().getTime()));
            cst.setInt(10, orderDto.getApplynum());
            cst.setInt(11, orderDto.getObject_type());
            cst.setInt(12, orderDto.getUnderwrite_flag());
            cst.setInt(13, orderDto.getStatus());
            cst.setString(14, orderDto.getPost_address());
            cst.setString(15, orderDto.getEhome_address());
            cst.setString(16, orderDto.getDestination());
            cst.setString(17, orderDto.getAddress_code());
            cst.setString(18, Beans.isEmpty(orderDto.getExtendInfos())? null : orderDto.getExtendInfos().toString());
            cst.setString(19, orderDto.getIs_renewal());
            cst.setString(20, orderDto.getOld_out_policy_no());
            cst.setString(21, orderDto.getOrder_no());
            cst.executeUpdate();      
        } catch (Exception e) {
            throw e; 
        } finally {
            closeAll(conn,cst,null);
        }
    }

    /**
     *更新prl_ant_inf_order_bill by ORDER_NO和PAYFLOWID
     * @param billDto
     * @throws Exception
     */
    @Override
    public void updateBill(BillDto billDto) throws Exception {
        Connection conn = this.getDataSource().getConnection();
        PreparedStatement cst = null;
        StringBuffer sql = new StringBuffer();
        sql.append("update prl_ant_inf_order_bill set MERCHANTACCOUNTTYPE = ?, MERCHANTACCOUNTID = ?," +
                   " OTHERACCOUNTTYPE = ?, OTHERACCOUNTID = ?, PAYTIME = ?, FEE = ?, updatetime = ?, DISCOUNTFEE = ?" +
                   " where ORDER_NO = ? and PAYFLOWID = ? ");
        try {
            cst = conn.prepareStatement(sql.toString());
            cst.setInt(1, billDto.getMerchantaccounttype());
            cst.setString(2, billDto.getMerchantaccountid());
            cst.setInt(3, billDto.getOtheraccounttype());
            cst.setString(4, billDto.getOtheraccountid());
            cst.setTimestamp(5, new Timestamp(billDto.getPaytime().getTime()));
            cst.setBigDecimal(6, billDto.getFee());
            cst.setTimestamp(7, new Timestamp(new Date().getTime()));
            cst.setBigDecimal(8, billDto.getDiscountFee());
            cst.setString(9, billDto.getOrder_no());
            cst.setString(10, billDto.getPayflowid());

            cst.executeUpdate();
        } catch (Exception e) {
            throw e;
        } finally {
            closeAll(conn, cst, null);
        }
    }
    
    @Override
    public Integer getContractIdByPolicyRef(String policyRef){                                                             
       return this.getContractId(policyRef);
    }
    
    @Override
    public Integer getInstallmentNo(String contractId) {
        Connection conn = null;
        PreparedStatement prep = null;
        ResultSet result = null;
        StringBuffer sql = new StringBuffer();
        sql.append(" select max(inp.installment_no) from prl_installment_plan inp");
        sql.append(" where inp.contract_id =").append(contractId);
        try {
            conn = this.getDataSource().getConnection();
            prep = conn.prepareStatement(sql.toString());
            result = prep.executeQuery();
            if (result.next()){
                return result.getInt(1);
            }
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        } finally {
            this.closeAll(conn, prep, result);
        }
        return -1;
    }
    
    @Override
    public List<ResponseBigObject> getinstallList(String contractId, Integer install_No) throws Exception {
        List<ResponseBigObject> returnList = new ArrayList<ResponseBigObject>();
        Connection conn = null;
        PreparedStatement prep = null;
        ResultSet rs = null;
        try {
            conn = this.getDataSource().getConnection();
            StringBuffer sql = new StringBuffer();
            sql.append(" SELECT contract_id contractId,installment_no versionNo,amount ,amount_swf premium ");
            sql.append(" FROM prl_installment_plan where contract_id =").append(contractId).append(" and installment_no > ").append(install_No);
            prep = conn.prepareStatement(sql.toString());
            rs = prep.executeQuery();
            if(rs.next()){
                ResponseBigObject reObject = new ResponseBigObject();
                reObject.setContractId(rs.getString("contractId"));
                reObject.setVersionNo(rs.getString("versionNo"));
                reObject.setAmount(rs.getBigDecimal("amount"));
                reObject.setPremium(rs.getString("premium"));
                returnList.add(reObject);
            }
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            throw e;
        } finally {
            closeAll(conn, prep, rs);
        }
        return returnList;
    }
    
    @Override
    public Integer settlementForPolicyCancel(Integer contractId,Integer installmentNo,BigDecimal amount,String currency ,String bankCode,String transType) throws Exception {
        log.info("contractId+installmentNo+amount+currency+bankCode+transType: "+contractId+"-"+installmentNo+"-"+amount+"-"+currency+"-"+bankCode+"-"+transType);
        String p_result = null;
        CallableStatement cbStatment = null;
        PreparedStatement prepFind = null;
        Connection conn = null;
        try {
            conn = this.getDataSource().getConnection();
            cbStatment = conn.prepareCall("begin ?:= Prl_pk2_oti.settlement_for_cancel(?,?,?,?,?,?);end;");
            cbStatment.registerOutParameter(1, Types.INTEGER);
            cbStatment.setObject(2, contractId);
            cbStatment.setObject(3, installmentNo);
            cbStatment.setObject(4, currency);
            cbStatment.setObject(5, amount);
            cbStatment.setObject(6, bankCode);
            cbStatment.setObject(7, transType);
            cbStatment.execute();
            p_result = cbStatment.getString(1);
            log.info("contractId+installmentNo Prl_pk2_oti.settlement_for_cancel ret val: "+contractId+"-"+installmentNo+"-"+p_result);
        } catch (Exception e) {
            throw e;
        } finally {
            closeAll(conn, prepFind, null);
            try{ 
                if(cbStatment != null)
                    cbStatment.close();
            }catch(Exception e){
                e.printStackTrace();
            }
        }
        return new Integer(p_result);
    }
    
    @Override
    public Date getPolicyStartDate(String policyRef) throws Exception {
        Connection conn = null;
        PreparedStatement prep = null;
        ResultSet rs = null;
        Date resDate = null;
        try {
            conn = this.getDataSource().getConnection();
            StringBuffer sql = new StringBuffer();
            sql.append(" select min(t.start_date) start_date from prl_part_plan_ext t, prl_group_policy_versions ver WHERE t.top_indicator = 'Y' ");
            sql.append(" and t.contract_id = ver.contract_id and ver.policy_ref = ?");
            prep = conn.prepareStatement(sql.toString());
            prep.setString(1, policyRef);
            rs = prep.executeQuery();
            if(rs.next()){
               resDate = rs.getTimestamp("START_DATE");
               log.info("----StartDate---" + resDate);
            }
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            throw e;
        } finally {
            closeAll(conn, prep, rs);
        }
        return resDate;
    }
    
    //保单截止日期
    @Override
    public Date getPolicyEndDate(String policyRef){                                                             
        Connection conn = null;
        PreparedStatement prep = null;
        ResultSet result = null;
        Date resDate = null;
        StringBuffer sql = new StringBuffer();
        sql.append("select t.TERM_END_DATE from prl_common_quote_policy_all t where t.contract_id = ");
        sql.append("(SELECT CONTRACT_ID FROM prl_group_policy_versions where policy_ref = ?)");
        try {
            conn = this.getDataSource().getConnection();
            prep = conn.prepareStatement(sql.toString());
            prep.setString(1, policyRef);
            result = prep.executeQuery();
                if(result.next()){
                   resDate = result.getTimestamp("TERM_END_DATE");
                   log.info("----EndDate---" + resDate);
                }
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        } finally {
            this.closeAll(conn, prep, result);
        }
        return resDate;
    }
    
    //mailInfo
    @Override
    public QueryResultBean getMailInfo(String mailKey){                                                             
        Connection conn = null;
        PreparedStatement prep = null;
        ResultSet result = null;
        QueryResultBean qr = new QueryResultBean();
        StringBuffer sql = new StringBuffer();
        sql.append("select MAIL_HOST value, MAIL_USER description, MAIL_PASSWORD result, MAIL_ADDRESS agencyCode, MAIL_ALIAS lopProdType");
        sql.append(" from prl_smsgw_mailconfig where MAIL_KEY=?");
        try {
            conn = this.getDataSource().getConnection();
            prep = conn.prepareStatement(sql.toString());
            prep.setString(1, mailKey);
            result = prep.executeQuery();
            if(result.next()){
                qr.setValue(result.getString("value"));
                qr.setDescription(result.getString("description"));
                qr.setResult(result.getString("result"));
                qr.setAgencyCode(result.getString("agencyCode"));
                qr.setLopProdType(result.getString("lopProdType"));
               log.info("emailHost=" + result.getString("value") + ", emailUser=" + result.getString("description") + ", emailPassword=" + result.getString("result")
                   + ", emailAddress=" + result.getString("agencyCode") + ", emailAlias=" + result.getString("lopProdType"));
            }
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        } finally {
            closeAll(conn, prep, result);
        }
        return qr;
    }
    
    @Override
    public void saveOrderForCancel(OrderDto orderDto) throws Exception {
        Connection conn = this.getDataSource().getConnection();
        PreparedStatement cst = null;     
        
        StringBuffer sql = null;
        sql = new StringBuffer(" insert into prl_ant_inf_order (ORDER_NO, PRODUCT_CODE, OUT_PRODUCT_CODE, SUMMARY_ORDER_NO, " +
            "POLICY_TYPE, PREMIUM, ACTUAL_PREMIUM, SUM_INSURED, " +
            "EFFECTSTARTTIME, EFFECTENDTIME, APPLYNUM, OBJECT_TYPE, UNDERWRITE_FLAG, STATUS,post_address,ehome_address,DESTINATION,address_code, " + 
            "EXTENDINFOS, IS_RENEWAL, OLD_OUT_POLICY_NO) " + 
            "values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        try {
            cst = conn.prepareStatement(sql.toString());
            cst.setString(1, orderDto.getOrder_no());
            cst.setString(2, orderDto.getProduct_code());
            cst.setString(3, orderDto.getOut_product_code());
            cst.setString(4, orderDto.getSummary_order_no());
            cst.setString(5, orderDto.getPolicy_type());
            cst.setBigDecimal(6, orderDto.getPremium());
            cst.setBigDecimal(7, orderDto.getActual_premium());
            cst.setBigDecimal(8, orderDto.getSum_insured());
            cst.setTimestamp(9, Beans.isEmpty(orderDto.getEffectstarttime())? null : new Timestamp(orderDto.getEffectstarttime().getTime()));
            cst.setTimestamp(10, Beans.isEmpty(orderDto.getEffectendtime())? null : new Timestamp(orderDto.getEffectendtime().getTime()));
            cst.setInt(11, orderDto.getApplynum());
            cst.setInt(12, Beans.isEmpty(orderDto.getInsObjectDto())? orderDto.getObject_type() : orderDto.getInsObjectDto().getType());
            cst.setInt(13, orderDto.getUnderwrite_flag());
            cst.setInt(14, orderDto.getStatus());
            cst.setString(15, orderDto.getPost_address());
            cst.setString(16, orderDto.getEhome_address());
            cst.setString(17, orderDto.getDestination());
            cst.setString(18, orderDto.getAddress_code());
            cst.setString(19, Beans.isEmpty(orderDto.getExtendInfos())? null : orderDto.getExtendInfos().toString());
            cst.setString(20, orderDto.getIs_renewal());
            cst.setString(21, orderDto.getOld_out_policy_no());
            
            cst.executeUpdate();
        } catch (Exception e) {
            throw e; 
        } finally {
            closeAll(conn,cst,null);
        }
    }
    
    //select
    @Override
    public Object fetchResult(String sql, Object... args) throws Exception{
        Connection conn = this.getDataSource().getConnection();
        ResultSet rs = null;
        PreparedStatement pst = null;
        try {
            pst = conn.prepareStatement(sql);
            if(Beans.isNotEmpty(args)){
                for(int i=0;i<args.length;i++){
                    pst.setObject(i+1,args[i]);
                }
            }
            rs = pst.executeQuery();
            if(rs.next()){
                return rs.getObject(1);
            }else{
                return null;
            }
        } catch (SQLException ex) {
           log.error(ex);
           throw new RuntimeException(ex);
        } finally {
            closeAll(conn, pst, rs);
        }
    }
    @Override
    public void commonSaveLog(InterfaceLogBean logBean)throws Exception {
        final String reqMess = logBean.getReqMessage();
        String commonSql = "Select nvl(t.WHETHER_SEND,1) iseffective from prl_sendmessage_product_agent t where t.message_type =? and t.state=? ";
        String flagSql = commonSql + "and t.MESSAGE_SUBJECT = 'wLog' order by t.whether_send desc nulls last";
        
        String resFlag = (String)this.fetchResult(flagSql, EtravelConst.AgentMessageType.InterfaceInvokeRecordLog.value, EtravelConst.TRUE);
        log.info("resFlag---" + resFlag);
        if(Beans.isNotEmpty(resFlag) && "1".equals(resFlag)){
            this.saveInterfaceLog(logBean);
        }
        String queryUrlSql = "Select t.message_template remark from prl_sendmessage_product_agent t where t.message_type =? and t.state=? and t.MESSAGE_SUBJECT = 'sUrl'";
        final String sUrl = (String)this.fetchResult(queryUrlSql, EtravelConst.AgentMessageType.InterfaceInvokeRecordLog.value, EtravelConst.TRUE);
        if(Beans.isNotEmpty(sUrl) && Beans.isNotEmpty(reqMess)){//异步post到指定地址
            new Thread(new Runnable(){  
                public void run(){  
                    log.info("同步post报文-send-" + sUrl);
                    HttpClient.postString(sUrl, reqMess, EtravelConst.UTF8, 10000);
                    log.info("post报文-complete");
                        }}).start();
        }
    }
    @Override
    public void saveInterfaceLog(InterfaceLogBean logBean) throws Exception {
        Connection conn = this.getDataSource().getConnection();
        PreparedStatement cst = null;     
        
        StringBuffer sBuffRecord = new StringBuffer();
        sBuffRecord.append("insert into prl_interface_visit_log ");
        sBuffRecord.append(" (Requset_Id,Request_Type,Type_Desc,User_Code,Agency_Code,Agency_Code_Mes,Plan_Code,Plan_Code_Mes,");
        sBuffRecord.append(" Agency_Policy_Ref,Agency_Policy_Ref_Mes,Policy_Ref,policy_Ref_Mes,Total_Premium,");
        sBuffRecord.append(" Req_Message,Res_Message,Req_URL)");
        sBuffRecord.append(" values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
        try {
            cst = conn.prepareStatement(sBuffRecord.toString());
            cst.setString(1, logBean.getRequsetId());
            cst.setString(2, logBean.getRequestType());
            cst.setString(3, logBean.getTypeDesc());
            cst.setString(4, logBean.getUserCode());
            cst.setString(5, logBean.getAgencyCode());
            cst.setString(6, logBean.getAgencyCodeMes());
            cst.setString(7, logBean.getPlanCode());
            cst.setString(8, logBean.getPlanCodeMes());
            cst.setString(9, logBean.getAgencyPolicyRef());
            cst.setString(10, logBean.getAgencyPolicyRefMes());
            cst.setString(11, logBean.getPolicyRef());
            cst.setString(12, logBean.getPolicyRefMes());
            cst.setString(13, logBean.getTotalPremium());
            cst.setString(14, logBean.getReqMessage());
            cst.setString(15, logBean.getResMessage());
            cst.setString(16, logBean.getReqURL());
            
            cst.executeUpdate();
        } catch (Exception e) {
            throw e; 
        } finally {
            closeAll(conn,cst,null);
        }
    }
    
    /**
     *核心保单激活
     * @param issueParam
     * @return
     */
    private Map<String, Object> coreIssueAPI(String order_no, String policyRef) throws Exception{
        OrderDto orderDto = this.findOrderByOrderNo(order_no);
        PaymentInfoDto billInfo = getBillInfo(order_no);
        String orderNo = orderDto.getOrder_no();
        Map<String, Object> result = new HashMap<String, Object>();
//        String policyRef = policyRef;
        String policyStatus = null;
        String errorMsg = null;
        IssuePacket requestPacket = new IssuePacket();
        //报文-head
        RequestHead head = new RequestHead();
        IssuePolicyBody body = new IssuePolicyBody();
        String requestType = CommonConst.RequestType.REQ_TYPE_ISSUEPOLICY.value;
        head.setRequestType(requestType);
        String agencyCode = this.getHomeAgencyCode();
        String[] userAndPass = this.getUsernameAndPassword();
        if(Beans.isEmpty(agencyCode) || Beans.isEmpty(userAndPass) || userAndPass.length != 2){
            throw new Exception("获取渠道代码或登录信息失败"); 
        }
        head.setUser(userAndPass[0]);
        head.setPassword(userAndPass[1]);
        head.setRequestId(ANT+orderNo+"-"+System.currentTimeMillis());
        requestPacket.setRequestHead(head);
        try {
            PaymentInfo paymentInfo = new PaymentInfo();
            paymentInfo.setPolicyRef(policyRef);
//            paymentInfo.setPaymentMethod("alipay");//新核心测试修改--！！！切记一定要改回来
            paymentInfo.setPaymentMethod("BT_" + Const.ALIPAY_BANK_CODE);//BT_3780: 阿里系的通过标准接口激活，前序为“BT_” - Bank Transfer
            paymentInfo.setPayTime(new java.util.Date(billInfo.getPaytime().getTime()));
            paymentInfo.setPremium(billInfo.getAmount());
            paymentInfo.setPlatformSerialNumber(orderNo);
            body.setPaymentInfo(paymentInfo);
            requestPacket.setIssuePolicyBody(body);
            String retXml = toString(this.sendXml(XmlUtil.toXml(requestPacket, "UTF-8"), this.getPostUrl(requestType)));     
            log.info("return xml:\n"+retXml);
            //标准接口返回结果转换成对应的object
            ResponsePacket responsePacket = XmlUtil.fromXml(ResponsePacket.class, retXml);
            if(Beans.isNotEmpty(responsePacket)){
                if(EtravelConst.ResponseCode.success.value.equals(responsePacket.getResponseHead().getResponseCode())){
                    //出单成功
                    log.info("激活成功! order_no:"+orderNo+", policyRef:"+responsePacket.getResponseBody().getPolicyRef()+", policyStatus:"+responsePacket.getResponseBody().getPolicyStatus());
                    policyStatus = responsePacket.getResponseBody().getPolicyStatus();
                    policyRef = responsePacket.getResponseBody().getPolicyRef();
                }else{
                    //出单失败
                    log.error("激活失败! order_no:"+orderNo+", error msg:"+responsePacket.getResponseHead().getErrorMessage());
                    errorMsg = responsePacket.getResponseHead().getErrorMessage();
                }
            }else{
                //调标准接口响应出错
                log.error("调标准接口响应出错! order_no:" + orderNo);
                errorMsg = "保险公司系统错误(标准接口)";
            }
        } catch (Exception e) {
            log.error("coreIssueAPI...error. order_no:"+orderNo);
            log.error(e.getMessage(), e);
            errorMsg = "ANT调标准接口出错";
        }
        log.info("coreIssueAPI...end. order_no:"+orderNo);
        result.put("policyRef", policyRef);
        result.put("policyStatus", policyStatus);
        result.put("errorMsg", errorMsg);
        return result;
    }
    
    /**
     *调用核心接口出单流程
     * @param orderNo
     * @return
     * @throws Exception
     */
    private Integer commonOTIConfirm(String orderNo) throws Exception{
        OrderDto orderDto = this.findOrderByOrderNo(orderNo);
        HolderDto holderDto = this.findHolderByOrderNo(orderNo);
        List<InsuredDto> insuredDtoList = this.findInsuredListByOrderNo(orderNo);
        this.updateOrderWaitIssue(orderNo, null);
        log.info("标准接口出单...");
        Map<String, Object> reMap = this.confirmOTIAPI(orderDto,holderDto,insuredDtoList,EtravelConst.FALSEREAL); 
        String policyRef = (String)reMap.get("policyRef");
        String policyStatus = (String)reMap.get("policyStatus");
        String errorMsg = (String)reMap.get("errorMsg");
        String responseCode = (String)reMap.get("responseCode");
        
        //接口返回成功结果
        if(EtravelConst.ResponseCode.success.value.equals(responseCode) && Beans.isNotEmpty(policyRef)){
            if(Const.PolicyStatus.InForce.value.equals(policyStatus)){
                //保单已生效
                this.updateOrderIssueSuccess(orderNo, policyRef);
            }else if(Const.PolicyStatus.WaitForPay.value.equals(policyStatus)){//待激活状态
                log.info("调用核心接口激活保单...order_no:"+orderNo);
                Map<String, Object> resultMap = this.coreIssueAPI(orderNo,policyRef);
                //判断执行状态 70：激活成功；其他issue错误
                String returnStatus = (String)resultMap.get("policyStatus");
                log.info("issue返回：policyStatus=" + returnStatus);
                if (Beans.isEmpty(returnStatus) || !EtravelConst.PolicyStatus.InForce.value.equals(returnStatus)) {
                    log.error("调用核心接口激活保单出错，返回policyStatus：" + returnStatus);
                    this.updateOrderIssueFailure(orderNo, "保险公司系统错误" + returnStatus);
                } else {
                    this.updateOrderIssueSuccess(orderNo, policyRef);
                }
            } 
        }else{
            this.updateOrderIssueFailure(orderNo, errorMsg);
        }
        return -1;
    }
    
    /**
     *核心出单、核保接口-0002、1000
     * @param OrderDto orderDto,HolderDto holderDto,List<InsuredDto> InsuredDtoList
     * @param isUW-是否核保 true-核保
     * @return
     */
    private Map<String, Object> confirmOTIAPI(OrderDto orderDto,HolderDto holderDto,List<InsuredDto> insuredDtoList, boolean isUW) {
        String order_no = orderDto.getOrder_no();
        Map<String, Object> reMap = new HashMap<String, Object>();
        String policyRef = null;
        String policyStatus = null;
        String errorMsg = null;
        try{
            String agencyCode = this.getHomeAgencyCode();
            String[] userAndPass = this.getUsernameAndPassword();
            if(Beans.isEmpty(agencyCode) || Beans.isEmpty(userAndPass) || userAndPass.length != 2){
                throw new Exception("获取渠道代码或登录信息失败"); 
            }
           
            String requestType = CommonConst.RequestType.REQ_TYPE_POLICYCONFIRM_OTI.value;
            if(Beans.isNotEmpty(orderDto.getOld_out_policy_no())){
                requestType = CommonConst.RequestType.REQ_TYPE_POLICYRENEWAL_OTI.value;
            }
            if(isUW){
                requestType = CommonConst.RequestType.REQ_TYPE_UNDERWRITE_OTI.value;
            }
            OTIPacket requestPacket = new OTIPacket();
            //报文-head
            OTIHead head = new OTIHead();
            head.setRequestType(requestType);
            head.setUser(userAndPass[0]);
            head.setPassword(userAndPass[1]);
            head.setRequestId(ANT+order_no+"-"+System.currentTimeMillis());
            requestPacket.setHead(head);
            //标准接口报文-body
            OTIBody body = new OTIBody();
            //agency
            OTIAgency agency = new OTIAgency();
            agency.setAgencyCode(agencyCode);
            body.setAgency(agency);
            //policy base info
            OTIPolicy policy = new OTIPolicy();
            //存在原保单记录
            if(Beans.isNotEmpty(orderDto.getOld_out_policy_no())){
                policy.setOriginalPolicyRef(orderDto.getOld_out_policy_no());
            }
            policy.setGroupSize(insuredDtoList.size()+"");
            policy.setAgencyPolicyRef(ANT+order_no); //prl_thirdp_interf_pol_data
            policy.setPlanCode(orderDto.getOut_product_code());
            policy.setEffectiveDate(new java.util.Date(orderDto.getEffectstarttime().getTime()));
            policy.setExpireDate(new java.util.Date(orderDto.getEffectendtime().getTime()));
            policy.setIssueDate(new java.util.Date(orderDto.getInsuredtime().getTime()));//orderDto.getInsuredtime() 
            policy.setRemark(null);
            if(Beans.isNotEmpty(orderDto.getPremium())){
                policy.setTotalPremium(orderDto.getPremium().divide(new BigDecimal(100), 2, RoundingMode.HALF_UP));
            }
            body.setPolicy(policy);
            //PolicyHolder  - 投保人
            OTIPolicyHolder policyHolder = new OTIPolicyHolder();
            policyHolder.setClientRef("I"); //投保人类型  I-个人,C-企业或者机构
            policyHolder.setLongName(holderDto.getCertname()); //投保人名称
            policyHolder.setRoleTypeId(holderDto.getCerttype()); //证件类型
            policyHolder.setPolicyNo(holderDto.getCertno()); //投保人证件号
            Date hBirthDay = this.formatTimeZone(holderDto.getBirth_day());
            policyHolder.setPHBirthDate(Beans.isEmpty(hBirthDay) ? null : new java.util.Date(hBirthDay.getTime()));
            policyHolder.setHotlineTelNo(holderDto.getPhone());
            policyHolder.setRemark(holderDto.getEmail()); //投保人邮箱地址
            policyHolder.setInsuredOverwriteFlag("0"); //ReqMail 是否邮寄发票，默认不需要 1-需要,0-不需要
            policyHolder.setShowCommFlag("0"); //是否需要打印发票 1-需要 0-不需要
            body.setPolicyHolder(policyHolder);
            OTIInsuredList oTIInsuredList = new OTIInsuredList();
            List<OTIInsured> oinsList = new ArrayList<OTIInsured>();
            for(InsuredDto insuredDto:insuredDtoList){
                //被保险人
                OTIInsured insured = new OTIInsured();
                insured.setInsuredId("1");
                insured.setClientRef(insuredDto.getInsuredType()); //被保险人类型
                insured.setLongName(insuredDto.getCertname());
                insured.setRoleTypeId(insuredDto.getCerttype()); //证件类型
                insured.setPolicyNo(insuredDto.getCertno()); //证件号码
                Date inBirthDay= this.formatTimeZone(insuredDto.getBirth_day());
                insured.setBirthDate(Beans.isEmpty(inBirthDay) ? null : new java.util.Date(inBirthDay.getTime()));
                insured.setHotlineTelNo(insuredDto.getPhone()); //联系电话
                insured.setRemark(insuredDto.getEmail());  //Email  电子邮件
                insured.setGender(this.getSexMapForHome(insuredDto.getSex())); //性别.
                insured.setBeneficialType("1"); //受益类型 1-法定
                if(Beans.isNotEmpty(insuredDto.getRelationWithholder())){
                    insured.setPolicyholderInsuredRelation(Const.relationshipMap.get(insuredDto.getRelationWithholder()));
                }
//                insured.setOccupationCode("C01");
                oinsList.add(insured);
            }
            oTIInsuredList.setInsured(oinsList);
            body.setInsuredList(oTIInsuredList);
            requestPacket.setBody(body);
            String retXml = toString(this.sendXml(XmlUtil.toXml(requestPacket, "UTF-8"), this.getPostUrl(requestType)));     
            log.info("return xml-OTI:\n"+retXml);
            //标准接口返回结果转换成对应的object
            ResponsePacket responsePacket = XmlUtil.fromXml(ResponsePacket.class, retXml);
            if(Beans.isNotEmpty(responsePacket)){
                if(Beans.isNotEmpty(responsePacket.getResponseHead())){
                    reMap.put("responseCode", responsePacket.getResponseHead().getResponseCode());
                    reMap.put("errorCode", responsePacket.getResponseHead().getErrorCode());
                    reMap.put("errorMsg", responsePacket.getResponseHead().getErrorMessage());
                }
                if(EtravelConst.ResponseCode.success.value.equals(responsePacket.getResponseHead().getResponseCode())){
                    if(isUW){//核保
                        return reMap;
                    }
                    //出单成功
                    log.info("出单成功! order_no:"+order_no+", policyRef:"+responsePacket.getResponseBody().getPolicyRef()+", policyStatus:"+responsePacket.getResponseBody().getPolicyStatus());
                    policyStatus = responsePacket.getResponseBody().getPolicyStatus();
                    policyRef = responsePacket.getResponseBody().getPolicyRef();
                }else{
                    //出单失败
                    log.error("出单失败! order_no:"+order_no+", error msg:"+responsePacket.getResponseHead().getErrorMessage());
                    errorMsg = responsePacket.getResponseHead().getErrorMessage();
                }
            }else{
                //调标准接口响应出错
                log.error("调标准接口响应出错! order_no:"+order_no);
                errorMsg = "保险公司系统错误(标准接口)";
            }
        } catch (Exception e) {
            log.error("confirm_OTI...error. order_no:"+order_no);
            log.error(e.getMessage(), e);
            errorMsg = "ANT调标准接口出错";
        }
        log.info("confirmAPI...end. order_no:"+order_no);
        reMap.put("policyRef", policyRef);
        reMap.put("policyStatus", policyStatus);
        reMap.put("errorMsg", errorMsg);
        return reMap;
    }
    
    /**
     *公共核保接口
     * @param orderDto
     * @param holderDto
     * @param insuredDtoList
     * @return
     */
    public Map<String, Object> underWriteByAPI(OrderDto orderDto,HolderDto holderDto,List<InsuredDto> insuredDtoList) {
        Map<String, Object> reMap = new HashMap<String, Object>();
        //家财核保
        if(isHomePlan(orderDto.getOut_product_code(), orderDto.getEffectstarttime())){
            reMap = this.confirmHomeAPI(orderDto,holderDto,insuredDtoList,EtravelConst.TRUEREAL);
        } else {
            //标准核保
            reMap = this.confirmOTIAPI(orderDto, holderDto, insuredDtoList, EtravelConst.TRUEREAL);
        }
        return reMap;
    }

}



package com.allianz.cn.pc.ant.services;


import com.allianz.cn.pc.utils.DataSourceClient;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


import javax.sql.DataSource;

import org.apache.log4j.Logger;


public class AntAbstractService{
    private static Logger log = Logger.getLogger(AntAbstractService.class);
    
    protected final static String ANT_DS_Name = "jdbc/eProductServiceDS";
    protected final static String ANT = "ANT";
    protected final static String BDXZAPP = "BDXZApp";
    
    private Connection conn = null;
    
    protected DataSource getDataSource(){
//        log.debug("getDSByName name=" + ANT_DS_Name);
        return DataSourceClient.getInstanceByName(ANT_DS_Name).getDataSource();
    }
    
    protected Connection getConnection() {
        if(null == conn){
            try {
                conn = this.getDataSource().getConnection();
            } catch (SQLException e) {
                e.printStackTrace();
                log.error("getConnection error "+e);
            }
        }
        return conn;
    }
    
    protected void createTransaction() {
        conn = this.getConnection();
        try {
            conn.setAutoCommit(false);
            log.error("开始数据库事务-----------");
        } catch (Exception e) {
            log.error("beginTransaction",e);
        }
    }
    
    protected void finishTransaction(){
        conn = this.getConnection();
        try {
            conn.commit();
            log.error("结束数据库事务！----------");
        } catch (SQLException e) {
            log.error("endTransaction",e);
        }finally {
            try {
                if (conn != null){
                    conn.close();
                    this.conn=null;
                }
            } catch (Exception e) {
                log.error("endTransaction error:", e);
            }
        }
    }
    
    protected void closeAll(Connection conn, PreparedStatement prep, ResultSet result) {
        try {
            if (result != null)
                result.close();
            if (prep != null)
                prep.close();
            if (conn != null)
                conn.close();
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        }
    }
}

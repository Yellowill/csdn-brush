package com.allianz.cn.pc.ant.dto;

import java.math.BigDecimal;

import java.sql.Timestamp;


/**
 * 家财险激活保单生效+settle， 支付信息dto
 */
public class PaymentInfoDto {
    
    private Integer contract_id;
    private String installment_no;
    private String policy_ref;
    private String payer_partner_ref;
    private String currency;
    private String payment_mode;
    private String endpoint_code;
    private String drawer_bank_acc_no;
    private String to_bank_code;
    private String pos_location_code;
    private BigDecimal  amount;
    private Timestamp paytime;
    private String order_no;

    public void setContract_id(Integer contract_id) {
        this.contract_id = contract_id;
    }

    public Integer getContract_id() {
        return contract_id;
    }

    public void setInstallment_no(String installment_no) {
        this.installment_no = installment_no;
    }

    public String getInstallment_no() {
        return installment_no;
    }

    public void setPolicy_ref(String policy_ref) {
        this.policy_ref = policy_ref;
    }

    public String getPolicy_ref() {
        return policy_ref;
    }

    public void setPayer_partner_ref(String payer_partner_ref) {
        this.payer_partner_ref = payer_partner_ref;
    }

    public String getPayer_partner_ref() {
        return payer_partner_ref;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getCurrency() {
        return currency;
    }

    public void setPayment_mode(String payment_mode) {
        this.payment_mode = payment_mode;
    }

    public String getPayment_mode() {
        return payment_mode;
    }

    public void setEndpoint_code(String endpoint_code) {
        this.endpoint_code = endpoint_code;
    }

    public String getEndpoint_code() {
        return endpoint_code;
    }

    public void setDrawer_bank_acc_no(String drawer_bank_acc_no) {
        this.drawer_bank_acc_no = drawer_bank_acc_no;
    }

    public String getDrawer_bank_acc_no() {
        return drawer_bank_acc_no;
    }

    public void setTo_bank_code(String to_bank_code) {
        this.to_bank_code = to_bank_code;
    }

    public String getTo_bank_code() {
        return to_bank_code;
    }

    public void setPos_location_code(String pos_location_code) {
        this.pos_location_code = pos_location_code;
    }

    public String getPos_location_code() {
        return pos_location_code;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setPaytime(Timestamp paytime) {
        this.paytime = paytime;
    }

    public Timestamp getPaytime() {
        return paytime;
    }

    public void setOrder_no(String order_no) {
        this.order_no = order_no;
    }

    public String getOrder_no() {
        return order_no;
    }
}

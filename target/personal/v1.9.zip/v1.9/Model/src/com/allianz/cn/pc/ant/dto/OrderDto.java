package com.allianz.cn.pc.ant.dto;

import java.math.BigDecimal;

import java.util.Date;
import java.util.Map;


/**
 * prl_ant_inf_order POJO
 * Sat Apr 30 15:34:02 CST 2016
 */ 


public class OrderDto{
	private String order_no;
	private String product_code;
	private String out_product_code;
	private String summary_order_no;
	private String policy_type;
	private BigDecimal premium;
	private BigDecimal actual_premium;
	private BigDecimal sum_insured;
	private Date insuredtime;
	private Date issuetime;
	private Date effectstarttime;
	private Date effectendtime;
	private Integer applynum;
	private Integer object_type;
	private Integer underwrite_flag;
	private Integer status;
        private String post_address;
        private String ehome_address;
        private String destination;
        private Map<String,String> extendInfos;
        private InsObjectDto insObjectDto;
        
        private String policy_ref;
        private String is_issue_success;
        private String db_error_msg;
        private String policy_url;
        //�����ֶ�
        private String is_renewal;
        private String old_out_policy_no;
        private Date next_continuous_time;
        
        private String address_code;
        
    public void setAddress_code(String address_code) {
        this.address_code = address_code;
    }

    public String getAddress_code() {
        return address_code;
    }

    public void setOrder_no(String order_no) {
        this.order_no = order_no;
    }

    public String getOrder_no() {
        return order_no;
    }

    public void setProduct_code(String product_code) {
        this.product_code = product_code;
    }

    public String getProduct_code() {
        return product_code;
    }

    public void setOut_product_code(String out_product_code) {
        this.out_product_code = out_product_code;
    }

    public String getOut_product_code() {
        return out_product_code;
    }

    public void setSummary_order_no(String summary_order_no) {
        this.summary_order_no = summary_order_no;
    }

    public String getSummary_order_no() {
        return summary_order_no;
    }

    public void setPolicy_type(String policy_type) {
        this.policy_type = policy_type;
    }

    public String getPolicy_type() {
        return policy_type;
    }

    public void setPremium(BigDecimal premium) {
        this.premium = premium;
    }

    public BigDecimal getPremium() {
        return premium;
    }

    public void setActual_premium(BigDecimal actual_premium) {
        this.actual_premium = actual_premium;
    }

    public BigDecimal getActual_premium() {
        return actual_premium;
    }

    public void setSum_insured(BigDecimal sum_insured) {
        this.sum_insured = sum_insured;
    }

    public BigDecimal getSum_insured() {
        return sum_insured;
    }

    public void setInsuredtime(Date insuredtime) {
        this.insuredtime = insuredtime;
    }

    public Date getInsuredtime() {
        return insuredtime;
    }

    public void setIssuetime(Date issuetime) {
        this.issuetime = issuetime;
    }

    public Date getIssuetime() {
        return issuetime;
    }

    public void setEffectstarttime(Date effectstarttime) {
        this.effectstarttime = effectstarttime;
    }

    public Date getEffectstarttime() {
        return effectstarttime;
    }

    public void setEffectendtime(Date effectendtime) {
        this.effectendtime = effectendtime;
    }

    public Date getEffectendtime() {
        return effectendtime;
    }

    public void setApplynum(Integer applynum) {
        this.applynum = applynum;
    }

    public Integer getApplynum() {
        return applynum;
    }

    public void setObject_type(Integer object_type) {
        this.object_type = object_type;
    }

    public Integer getObject_type() {
        return object_type;
    }

    public void setUnderwrite_flag(Integer underwrite_flag) {
        this.underwrite_flag = underwrite_flag;
    }

    public Integer getUnderwrite_flag() {
        return underwrite_flag;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getStatus() {
        return status;
    }

    public void setExtendInfos(Map<String, String> extendInfos) {
        this.extendInfos = extendInfos;
    }

    public Map<String, String> getExtendInfos() {
        return extendInfos;
    }

    public void setInsObjectDto(InsObjectDto insObjectDto) {
        this.insObjectDto = insObjectDto;
    }

    public InsObjectDto getInsObjectDto() {
        return insObjectDto;
    }

    public void setIs_issue_success(String is_issue_success) {
        this.is_issue_success = is_issue_success;
    }

    public String getIs_issue_success() {
        return is_issue_success;
    }

    public void setPolicy_ref(String policy_ref) {
        this.policy_ref = policy_ref;
    }

    public String getPolicy_ref() {
        return policy_ref;
    }

    public void setDb_error_msg(String db_error_msg) {
        this.db_error_msg = db_error_msg;
    }

    public String getDb_error_msg() {
        return db_error_msg;
    }

    public void setPolicy_url(String policy_url) {
        this.policy_url = policy_url;
    }

    public String getPolicy_url() {
        return policy_url;
    }

    public void setPost_address(String post_address) {
        this.post_address = post_address;
    }

    public String getPost_address() {
        return post_address;
    }

    public void setEhome_address(String ehome_address) {
        this.ehome_address = ehome_address;
    }

    public String getEhome_address() {
        return ehome_address;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getDestination() {
        return destination;
    }

    public void setIs_renewal(String is_renewal) {
        this.is_renewal = is_renewal;
    }

    public String getIs_renewal() {
        return is_renewal;
    }

    public void setOld_out_policy_no(String old_out_policy_no) {
        this.old_out_policy_no = old_out_policy_no;
    }

    public String getOld_out_policy_no() {
        return old_out_policy_no;
    }

    public void setNext_continuous_time(Date next_continuous_time) {
        this.next_continuous_time = next_continuous_time;
    }

    public Date getNext_continuous_time() {
        return next_continuous_time;
    }
}


package com.allianz.cn.pc.ant.services;


import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.log4j.Logger;


public class Config extends AntAbstractService {
    private static Logger log = Logger.getLogger(Config.class);

    private static Config instance = null;
    private Map<String, String> mapValue = new HashMap<String,String>();
    private static final String RSA_PRI_KEY_1="key.private.1";
    private static final String RSA_PRI_KEY_2="key.private.2";
    private static final String RSA_PRI_KEY_3="key.private.3";
    private static final String RSA_PRI_KEY_4="key.private.4";
    private static final String RSA_PRI_KEY_5="key.private.5";
    private static final String RSA_PUB_KEY_1="key.public.1";
    private static final String RSA_PUB_KEY_2="key.public.2";
    private static final String ACCOUNT_ID_KEY="account.id";
    private static final String TIMEOUT_KEY="issue.time.out";
    private static final String THREADPOOL_SIZE_KEY="threadpool.size";
    private static final String POLICY_DOWNLOAD_URL_KEY="policy.download.url";
    private static final String SMS_MODEL_KEY="ant.issue";
    
    public static final String SMS_SEND_KEY="sms.send.flag";
    public static final String HOME_AGENCY_KEY="home.agency.code";
    public static final String HOME_USER_AND_PASSWOR_KEY="home.user.and.password";
    public static final String RENEWAL_OPEN_FLAG_KEY="renewal.open.flag";
    public static final String CHECK_PLAN_ASSIGNMENT_KEY="check.plan.assignment.flag";
    public static final String CHECK_OTI_PREMIUM_NEW_KEY="check.oti.premium.new.flag";
    public static final String CHECK_OTI_PREMIUM_RENEWAL_KEY="check.oti.premium.renewal.flag";
    public static final String CHECK_OTI_PREMIUM_WHITE_LIST_KEY="check.oti.premium.white.list";
    public static final String CHECK_INSURE_TIMES_KEY="check.insure.times.flag";
    public static final String OPEN_ONLINE_CANCEL_POLICY_KEY="open.online.cancel.policy.flag";
    
    
    private static String privateKey = null;
    private static String publicKey = null;
    private static String accountID = null;
    private static Integer timeOut = null;
    private static Integer threadPoolSize = null;   
    private static String policyDownloadUrl = null;
    private static String smsModel = null;

    private Config() {
        this.retrieveAppConfig(ANT);
        
        StringBuilder sb1 = new StringBuilder();
        sb1.append(mapValue.get(RSA_PRI_KEY_1));
        sb1.append(mapValue.get(RSA_PRI_KEY_2));
        sb1.append(mapValue.get(RSA_PRI_KEY_3));
        sb1.append(mapValue.get(RSA_PRI_KEY_4));
        sb1.append(mapValue.get(RSA_PRI_KEY_5));
        privateKey=sb1.toString().trim();
        
        StringBuilder sb2 = new StringBuilder();
        sb2.append(mapValue.get(RSA_PUB_KEY_1));
        sb2.append(mapValue.get(RSA_PUB_KEY_2));
        publicKey = sb2.toString().trim();
        
        accountID=mapValue.get(ACCOUNT_ID_KEY);
        timeOut=Integer.parseInt(mapValue.get(TIMEOUT_KEY));
        threadPoolSize=Integer.parseInt(mapValue.get(THREADPOOL_SIZE_KEY));
        
        this.retrieveAppConfigWithKey(BDXZAPP, POLICY_DOWNLOAD_URL_KEY);
        policyDownloadUrl = mapValue.get(POLICY_DOWNLOAD_URL_KEY);
        
        String sql = "SELECT VALUE FROM prl_smsgw_sms_model WHERE KEY='"+SMS_MODEL_KEY+"'";
        this.retrieveConfigBySql(sql, SMS_MODEL_KEY);
        smsModel = mapValue.get(SMS_MODEL_KEY);
    }

    public synchronized static Config getInstance() {

        if (instance == null) {
            instance = new Config();
        }
        return instance;
    }

    public static void updateConfig() throws Exception {
        instance = new Config();
    }

    private void retrieveAppConfig(String appName) {
        log.debug("retrieveAppConfig appName="+appName );
        Connection conn = null;
        Statement cst = null;
        ResultSet rs = null;

        String sql =
            "SELECT KEY, VALUE" + 
            "  FROM PRPL_APP_PARAMETER" + 
            " WHERE STATUS = '1'" + 
            "   AND APP_NAME = '"+appName+"'";
        log.debug("sql is: "+sql);
        try {
            DataSource opusSource = this.getDataSource();
            conn = opusSource.getConnection();
            cst = conn.createStatement();

            rs = cst.executeQuery(sql);
            while (rs.next()) {
                mapValue.put(rs.getString("key"), rs.getString("value"));
            }
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        } finally {
            try {
                if (rs != null)
                    rs.close();
                if (cst != null)
                    cst.close();
                if (conn != null)
                    conn.close();
            } catch (Exception e) {
                log.error(e.getMessage(),e);
            }
        }
    }
    
    private void retrieveAppConfigWithKey(String appName,String key) {
        log.debug("retrieveAppConfigWithKey appName="+appName+" key="+key );
        Connection conn = null;
        Statement cst = null;
        ResultSet rs = null;

        String sql =
            "SELECT KEY, VALUE" + 
            "  FROM PRPL_APP_PARAMETER" + 
            " WHERE STATUS = '1'" + 
            "   AND APP_NAME = '"+appName+"' and key='"+key+"'";
        log.debug("retrieveAppConfig sql is: "+sql);
        try {
            DataSource opusSource = this.getDataSource();
            conn = opusSource.getConnection();
            cst = conn.createStatement();

            rs = cst.executeQuery(sql);
            while (rs.next()) {
                mapValue.put(rs.getString("key"), rs.getString("value"));
            }
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        } finally {
            try {
                if (rs != null)
                    rs.close();
                if (cst != null)
                    cst.close();
                if (conn != null)
                    conn.close();
            } catch (Exception e) {
                log.error(e.getMessage(),e);
            }
        }
    }
    
    private void retrieveConfigBySql(String sql,String key) {
        log.debug("retrieveConfigBySql sql is:"+sql);
        Connection conn = null;
        Statement cst = null;
        ResultSet rs = null;

        try {
            DataSource opusSource = this.getDataSource();
            conn = opusSource.getConnection();
            cst = conn.createStatement();

            rs = cst.executeQuery(sql);
            while (rs.next()) {
                mapValue.put(key, rs.getString(1));
            }
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        } finally {
            try {
                if (rs != null)
                    rs.close();
                if (cst != null)
                    cst.close();
                if (conn != null)
                    conn.close();
            } catch (Exception e) {
                log.error(e.getMessage(),e);
            }
        }
    }

    public static void setPrivateKey(String privateKey) {
        Config.privateKey = privateKey;
    }

    public static String getPrivateKey() {
        return privateKey;
    }

    public static void setPublicKey(String publicKey) {
        Config.publicKey = publicKey;
    }

    public static String getPublicKey() {
        return publicKey;
    }

    public static String getPolicyDownloadUrl() {
        return policyDownloadUrl;
    }

    public static void setAccountID(String accountID) {
        Config.accountID = accountID;
    }

    public static String getAccountID() {
        return accountID;
    }

    public static void setTimeOut(Integer timeOut) {
        Config.timeOut = timeOut;
    }

    public static Integer getTimeOut() {
        return timeOut;
    }

    public static void setThreadPoolSize(Integer threadPoolSize) {
        Config.threadPoolSize = threadPoolSize;
    }

    public static Integer getThreadPoolSize() {
        return threadPoolSize;
    }

    public static String getSmsModel() {
        return smsModel;
    }

}

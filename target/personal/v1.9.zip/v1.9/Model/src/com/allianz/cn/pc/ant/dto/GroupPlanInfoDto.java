package com.allianz.cn.pc.ant.dto;

public class GroupPlanInfoDto {
    private String groupPlanCode;
    private Integer renewableMaxAge;


    public void setGroupPlanCode(String groupPlanCode) {
        this.groupPlanCode = groupPlanCode;
    }

    public String getGroupPlanCode() {
        return groupPlanCode;
    }

    public void setRenewableMaxAge(Integer renewableMaxAge) {
        this.renewableMaxAge = renewableMaxAge;
    }

    public Integer getRenewableMaxAge() {
        return renewableMaxAge;
    }
}

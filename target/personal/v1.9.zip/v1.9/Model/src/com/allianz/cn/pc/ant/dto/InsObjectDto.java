package com.allianz.cn.pc.ant.dto;


import java.util.HashMap;
import java.util.Map;

public class InsObjectDto {
    private Integer type;

    private Map<String,String> extendInfos=new HashMap<String,String>();

    public void setType(Integer type) {
        this.type = type;
    }

    public Integer getType() {
        return type;
    }

    public void setExtendInfos(Map<String, String> extendInfos) {
        this.extendInfos = extendInfos;
    }

    public Map<String, String> getExtendInfos() {
        return extendInfos;
    }
}

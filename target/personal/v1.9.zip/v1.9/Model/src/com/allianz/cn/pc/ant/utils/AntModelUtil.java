package com.allianz.cn.pc.ant.utils;

import com.allianz.cn.pc.utils.DateUtil;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import java.util.Calendar;
import java.util.Date;

import org.apache.log4j.Logger;

public class AntModelUtil {
    static Logger log = Logger.getLogger(AntModelUtil.class);
    
    
    public static Date stringToDate(String strDate, String format){
        SimpleDateFormat formatter = new SimpleDateFormat(format);
        try {
            return formatter.parse(strDate);
        } catch (ParseException e) {
            log.error(e);
            return null;
        }
    }
    
    
    /**
     * 得到两个日期之间的月份数
     */
    public static int getBetweenMonth(Date date1, Date date2){
        Calendar bef = Calendar.getInstance();
        Calendar aft = Calendar.getInstance();
        bef.setTime(date1);
        aft.setTime(date2);
        int years = (aft.get(Calendar.YEAR) - bef.get(Calendar.YEAR));
        int months = aft.get(Calendar.MONTH) - bef.get(Calendar.MONTH);
        //比较日期中的 日，时，分，秒
        bef.setTime(stringToDate("2018-12-"+DateUtil.dateToStringWithFormat(date1, "dd HH:mm:ss"), "yyyy-MM-dd HH:mm:ss"));
        aft.setTime(stringToDate("2018-12-"+DateUtil.dateToStringWithFormat(date2, "dd HH:mm:ss"), "yyyy-MM-dd HH:mm:ss"));
        int overTime = (aft.getTime().getTime()+1 - bef.getTime().getTime() > 0) ? 1 : 0;
        int result = Math.abs(years * 12 + months + overTime);
        log.info("years：" + years + ", months: " + months + ", overTime: " + overTime + ", 月份数: " + result);
        return result;
    }
    
    //判断区间内是否跨越闰年2月
    public static boolean isLeapYear(Date startDate, Date endDate){
        try {
            String startDateStr = DateUtil.dateToStringWithFormat(startDate, "yyyy-MM-dd"); //yyyy-MM-dd
            String endDateStr = DateUtil.dateToStringWithFormat(endDate, "yyyy-MM-dd");

            Integer startDateYear = Integer.parseInt(startDateStr.substring(0, 4));
            Integer startDateMonth = Integer.parseInt(startDateStr.substring(5, 7));
            Integer startDateDay = Integer.parseInt(startDateStr.substring(8));

            Integer endDateYear = Integer.parseInt(endDateStr.substring(0, 4));
            Integer endDateMonth = Integer.parseInt(endDateStr.substring(5, 7));
            Integer endDateDay = Integer.parseInt(endDateStr.substring(8));

            if (!isLeapYear(startDateYear) && !isLeapYear(endDateYear)) {
                return false;
            } else if (isLeapYear(startDateYear) && !isLeapYear(endDateYear)) {
                if (startDateMonth < 2) {
                    return true;
                } else if (startDateMonth == 2 && startDateDay < 29) {
                    return true;
                }
            } else if (!isLeapYear(startDateYear) && isLeapYear(endDateYear)) {
                if (endDateMonth > 2) {
                    return true;
                } else if (endDateMonth == 2 && endDateDay == 29) {
                    return true;
                }
            } else if (isLeapYear(startDateYear) && isLeapYear(endDateYear)) {
                if (startDateMonth < 2 || endDateMonth > 2) {
                    return true;
                } else if (startDateMonth == 2 && startDateDay < 29) {
                    return true;
                } else if (endDateMonth == 2 && endDateDay == 29) {
                    return true;
                }
            }
        } catch (Exception e) {
            log.error(e);
        }
        return false;
    }
    
    
    public static boolean isLeapYear(int year) {
        return (year % 400) == 0 || ((year % 4) == 0 && (year % 100)!= 0 );
    }
    
}

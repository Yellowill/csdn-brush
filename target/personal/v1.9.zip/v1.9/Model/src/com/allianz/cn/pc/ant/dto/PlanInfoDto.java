package com.allianz.cn.pc.ant.dto;

import java.math.BigDecimal;

import java.util.Date;

public class PlanInfoDto {
    
    private String planCode;
    
    private String status;
    
    private Date startDate;
    
    private Date endDate;
    
    private Double startAge;
    
    private Double endAge;
    
    private String subProduct;
    
    private BigDecimal premium;
    
    private Integer planId;
    
    private String groupPlanCode;
    
    private String groupPlanName;

    public void setPlanCode(String planCode) {
        this.planCode = planCode;
    }

    public String getPlanCode() {
        return planCode;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStatus() {
        return status;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setStartAge(Double startAge) {
        this.startAge = startAge;
    }

    public Double getStartAge() {
        return startAge;
    }

    public void setEndAge(Double endAge) {
        this.endAge = endAge;
    }

    public Double getEndAge() {
        return endAge;
    }

    public void setSubProduct(String subProduct) {
        this.subProduct = subProduct;
    }

    public String getSubProduct() {
        return subProduct;
    }

    public void setPremium(BigDecimal premium) {
        this.premium = premium;
    }

    public BigDecimal getPremium() {
        return premium;
    }

    public void setPlanId(Integer planId) {
        this.planId = planId;
    }

    public Integer getPlanId() {
        return planId;
    }

    public void setGroupPlanCode(String groupPlanCode) {
        this.groupPlanCode = groupPlanCode;
    }

    public String getGroupPlanCode() {
        return groupPlanCode;
    }

    public void setGroupPlanName(String groupPlanName) {
        this.groupPlanName = groupPlanName;
    }

    public String getGroupPlanName() {
        return groupPlanName;
    }
}

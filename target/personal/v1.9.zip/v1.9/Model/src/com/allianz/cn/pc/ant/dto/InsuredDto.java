package com.allianz.cn.pc.ant.dto;

import java.util.Date;
import java.util.Map;

/**
 * prl_ant_inf_order_insured POJO
 * Sat Apr 30 15:35:26 CST 2016
 */ 


public class InsuredDto{
	private String order_no;
	private Integer sameWithholder;
	private String relationWithholder;
	private String personno;
	private String certtype;
	private String accounttype;
	private String accountno;
	private String accountname;
	private String certno;
	private String certname;
	private String resident_province;
	private String resident_city;
        
        private Map<String,String> extendInfos;
	private String address;
	private String sex;
	private String phone;
        private Date birth_day;
        private String email;
        private String nameEn;
    
        private String insuredType;

    public void setOrder_no(String order_no) {
        this.order_no = order_no;
    }

    public String getOrder_no() {
        return order_no;
    }

    public void setSameWithholder(Integer samewithholder) {
        this.sameWithholder = samewithholder;
    }

    public Integer getSameWithholder() {
        return sameWithholder;
    }

    public void setRelationWithholder(String relationwithholder) {
        this.relationWithholder = relationwithholder;
    }

    public String getRelationWithholder() {
        return relationWithholder;
    }

    public void setPersonno(String personno) {
        this.personno = personno;
    }

    public String getPersonno() {
        return personno;
    }

    public void setCerttype(String certtype) {
        this.certtype = certtype;
    }

    public String getCerttype() {
        return certtype;
    }

    public void setAccounttype(String accounttype) {
        this.accounttype = accounttype;
    }

    public String getAccounttype() {
        return accounttype;
    }

    public void setAccountno(String accountno) {
        this.accountno = accountno;
    }

    public String getAccountno() {
        return accountno;
    }

    public void setBirth_day(Date birth_day) {
        this.birth_day = birth_day;
    }

    public Date getBirth_day() {
        return birth_day;
    }

    public void setAccountname(String accountname) {
        this.accountname = accountname;
    }

    public String getAccountname() {
        return accountname;
    }

    public void setCertno(String certno) {
        this.certno = certno;
    }

    public String getCertno() {
        return certno;
    }

    public void setCertname(String certname) {
        this.certname = certname;
    }

    public String getCertname() {
        return certname;
    }

    public void setResident_province(String resident_province) {
        this.resident_province = resident_province;
    }

    public String getResident_province() {
        return resident_province;
    }

    public void setResident_city(String resident_city) {
        this.resident_city = resident_city;
    }

    public String getResident_city() {
        return resident_city;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getAddress() {
        return address;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getSex() {
        return sex;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getPhone() {
        return phone;
    }

    public void setExtendInfos(Map<String, String> extendInfos) {
        this.extendInfos = extendInfos;
    }

    public Map<String, String> getExtendInfos() {
        return extendInfos;
    }

    public void setInsuredType(String insuredType) {
        this.insuredType = insuredType;
    }

    public String getInsuredType() {
        return insuredType;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getEmail() {
        return email;
    }

    public void setNameEn(String nameEn) {
        this.nameEn = nameEn;
    }

    public String getNameEn() {
        return nameEn;
    }
}


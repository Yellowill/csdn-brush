package com.allianz.cn.pc.ant;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Const {
    public static final String TRUE = "1";
    public static final String FALSE = "0";
    public static final String AES_KEY = "TaobaoAL"; //解密打印保单号的AES算法的key
    public static final String issue_smsmodel = "5"; //出单短信模版
    public static final String ANT_APPNAME = "ANT"; //当前应用
    public static final String ANT_DATE_FORMAT = "yyyyMMdd"; //ant的日期格式
    public static final String ANT_TIME_FORMAT = "yyyyMMddHHmmss"; //ant的时间格式
    public static final String FLIGHT_SUBPRODUCT = "504,595"; //ant的时间格式
    public static final String YES="Y";
    public static final String NO="N";

    public static final String FUNCTION_CODE_UNDERWRITE = "ant.bxcloud.core.underwrite";
    public static final String FUNCTION_CODE_POLICYCONFIRM = "ant.bxcloud.core.issue";
    public static final String FUNCTION_CODE_ENDORSEMENT = "ant.bxcloud.info.surrenderNotify";//"ant.bxcloud.info.endorseNotify";
    
    public static final String ENDORSE_POLICY_SURRENDER = "402";//退保
    public static final String CANCLE_FLAG = "-C";//退保标识
    
    public static final String ALIPAY_BANK_CODE = "3780"; //家财险保单issue+settle时，银行代码
    
    public final static List<String> functionTypeList = new ArrayList<String>();
    public final static Map<String, String> allianzErrorMap = new HashMap<String, String>();
    public final static Map<String, String> antErrorMap = new HashMap<String, String>();
    public final static Map<String, String> genderMap = new HashMap<String, String>();
    public final static Map<String, String> relationshipMap = new HashMap<String, String>();
    
    public final static String ANT_RELATIONSHIP_SELF = "1"; //ant端被保人与投保人关系  1 - 本人
    
    static {
        //被保人与投保人关系
        relationshipMap.put(ANT_RELATIONSHIP_SELF, "01");//本人
        relationshipMap.put("3", "02");//父母
        relationshipMap.put("4", "03");//子女
        relationshipMap.put("2", "04");//配偶
        relationshipMap.put("5", "07");//其他
        
        //性别,后台表要求存1/2
        genderMap.put("M", "1");
        genderMap.put("F", "2");
        
        functionTypeList.add(FUNCTION_CODE_UNDERWRITE);
        functionTypeList.add(FUNCTION_CODE_POLICYCONFIRM);
        //成功
        allianzErrorMap.put("0000", "成功");
        //逻辑错误
        allianzErrorMap.put("1000", "系统错误，请联系客服");
        //
        allianzErrorMap.put("1444", "指定错误message返回");
//        allianzErrorMap.put("1001", "报文格式错误");
//        allianzErrorMap.put("1002", "请求类型错误");
//        allianzErrorMap.put("1003", "请求ID重复");
        allianzErrorMap.put("1004", "找不到保险产品");
        allianzErrorMap.put("1005", "保单有效期超出了产品有效期");
        allianzErrorMap.put("1006", "该保险产品无效");
        allianzErrorMap.put("1007", "投保人未满18岁，不允许投保");
        allianzErrorMap.put("1008", "被保险人年龄不在该计划允许的范围内");
        allianzErrorMap.put("1009", "订单不存在");
        allianzErrorMap.put("1010", "订单未核保");
        allianzErrorMap.put("1011", "被保险人证件类型不正确");
        allianzErrorMap.put("1012", "付款金额与订单金额不一致");
        allianzErrorMap.put("1013", "起保日期不能早于当前日期");
        allianzErrorMap.put("1014", "与系统计算保费不匹配，请联系客服");
        allianzErrorMap.put("1015", "保额不正确");
        allianzErrorMap.put("1016", "出单失败");
        allianzErrorMap.put("1017", "机构账号类型不正确");
//        allianzErrorMap.put("1018", "机构账号ID不正确");
        allianzErrorMap.put("1019", "付款时间不能晚于起保时间");
        allianzErrorMap.put("1020", "交易失败，请重新购买");
        allianzErrorMap.put("1021", "投保不成功");
        allianzErrorMap.put("1022", "该保险产品暂未授权，请联系客服");
        allianzErrorMap.put("1023", "投保次数已达上限，不能再投保");
        allianzErrorMap.put("1024", "被保险人保险区间重复保单数量已达上限，不能再投保!");
        
        //这部分转换成ant的 验签错误
        allianzErrorMap.put("1200", "RSA校验失败");
        //这部分转换成ant的 受理中
        allianzErrorMap.put("1300", "受理中");
        //空值错误--11开头这部分转换成ant的 报文必传字段为空
        allianzErrorMap.put("1101", "起保时间不能为空");
        allianzErrorMap.put("1102", "产品编码不能为空");
        allianzErrorMap.put("1103", "总保费不能为空");
        allianzErrorMap.put("1104", "客户证件号码不能为空");
        allianzErrorMap.put("1105", "被保险人姓名不能为空");
        allianzErrorMap.put("1107", "终保日期不能早于起保日期");
        allianzErrorMap.put("1108", "订单号不能为空");
        allianzErrorMap.put("1109", "付款金额不能为空");
        allianzErrorMap.put("1110", "投保时间不能为空");
        allianzErrorMap.put("1111", "出单时间不能为空");
        allianzErrorMap.put("1112", "终保时间不能为空");
        allianzErrorMap.put("1113", "投保人出生日期不能为空");
        allianzErrorMap.put("1114", "被保险人出生日期不能为空");
        //续保
        allianzErrorMap.put("2000", "原保单号不能为空");
        allianzErrorMap.put("2001", "获取续保信息失败，请确认原保单是否支持续保");
        allianzErrorMap.put("2002", "该产品不能续保");
        allianzErrorMap.put("2003", "非年单不能续保");
        allianzErrorMap.put("2004", "原保单的状态为非生效，不能续保");
        allianzErrorMap.put("2005", "超过产品续保宽限期天，请联系客服");
        allianzErrorMap.put("2006", "续保起保时间必须大于原保单的结束时间");
        allianzErrorMap.put("2007", "存在续保记录，不能再次续保");
        allianzErrorMap.put("2008", "不能续保"); //风险客户
        allianzErrorMap.put("2009", "与系统计算保费不匹配，请联系客服");
        
        //家财险
        allianzErrorMap.put("3001", "被保人数量只能为1");
        allianzErrorMap.put("3002", "城市与详细地址必填");
        allianzErrorMap.put("3003", "获取地区信息错误，请联系客服");
        allianzErrorMap.put("3004", "该地区不在承保范围");
        allianzErrorMap.put("3005", "与系统计算保费不符，请联系客服");
        allianzErrorMap.put("3006", "保险计划投保时间不能超过一年");
        
        //其他
        allianzErrorMap.put("9901", "超出承保次数限制");
        //核保
        antErrorMap.put("AE10316060001002", "验签错误");
        antErrorMap.put("AE10316060001003", "时间转换错误");
        antErrorMap.put("AE10316060001004", "报文必传字段为空");
        antErrorMap.put("AE10316060001005", "保险公司自定义描述");
        //出单
        antErrorMap.put("AE10316060002001", "受理中");
        antErrorMap.put("AE10316060002002", "验签错误");
        antErrorMap.put("AE10316060002003", "时间转换错误");
        antErrorMap.put("AE10316060002004", "报文必传字段为空");
        antErrorMap.put("AE10316060002005", "保险公司自定义描述");
        
    }
    
    /**
     * 资金账户类型
     */
    public enum AccountType {
        alipay(1),
        bank(2);
        public Integer value;

        AccountType(Integer value) {
            this.value = value;
        }
    }
    
    /**
     * 被保险人类型
     */
    public enum InsuredType {
        adult("1"),
        child("2"),
        aged("3");
        public String value;

        InsuredType(String value) {
            this.value = value;
        }
    }
    /**
     * ANT证件类型
     */
    public enum AntCardType {
        IDCard("100"),
        Passport("102"),
        HKCard("105"),
        TaiWanCard("106");
        public String value;

        AntCardType(String value) {
            this.value = value;
        }
    }
    
    /**
     * 证件类型
     */
    public enum CardType {
        IDCard("1"),
        Passport("2"),
        Other("3");
        public String value;

        CardType(String value) {
            this.value = value;
        }
    }

    public enum CustomerExtendInfoKey {
        birthday("birthday"),
        phone("phone"),
        address("address"),
        email("email"),
        englishName("englishName"),
        gender("gender");
        public final String value;

        CustomerExtendInfoKey(String value) {
            this.value = value;
        }
    }
    
    public enum PolicyExtendInfoKey {
        address("address"),//邮寄地址
        isRenewal("isRenewal"),//续保标记
        oldOutPolicyNo("oldOutPolicyNo");//老外部（机构）保单号

        public final String value;

        PolicyExtendInfoKey(String value) {
            this.value = value;
        }
    }
    
    public enum InsObjectExtendInfoKey {
        addressCode("adress"),//家财险城市代码(行政区划代码)
        addressDetail("adressDetail"),//家财险地址  
        destination("destination"),//旅游目的地 
        passportNo("passportNo"); //护照号码(被保险人)
        public final String value;

        InsObjectExtendInfoKey(String value) {
            this.value = value;
        }
    }

    public enum PolicyStatus {
        WIPPolicy("30"),
        WaitForPay("60"),
        InForce("70"),
        CancelToBeCheck("75"),
        Cancelled("80"),
        Endorsement("35"),
        EndorsementToBeCheck("40");
        
        public final String value;

        PolicyStatus(String value) {
            this.value = value;
        }
    }
    
    /**
     * 核保状态
     */
    public enum UnderWriteStatus {
        success(1),
        fail(0);
        public final int value;

        UnderWriteStatus(int value) {
            this.value = value;
        }
    }

    /**
     * 订单状态
     */
    public enum AntOrderStatus {
        NoRecord(0),
        WaitUW(1),
        UWSuccess(2),
        UWFail(3),
        WaitIssue(4),
        IssueSuccess(5),
        IssueFail(6),
        WaitCancel(7),//退保中
        CancelSuccess(8),//退保成功
        CancelFail(9);//退保失败
        public final int value;

        AntOrderStatus(int value) {
            this.value = value;
        }
    }


    /**
     * 请求是否成功
     * 0:成功
     * 1:失败
     */
    public enum RequestProcStatus {
        success("0"),
        fail("-1");
        public String value;

        RequestProcStatus(String value) {
            this.value = value;
        }
    }
    
    /**
     * ANT返回结果
     * 000000--业务返回成功
     * 900000--业务返回失败
     * S-处理结果（通过）
     * F-处理结果（不通过）
     */
    public enum ResponseStatus {
        successCode("000000"),
        failCode("900000"),
        success("S"),
        fail("F");
        public String value;

        ResponseStatus(String value) {
            this.value = value;
        }
    }
    
    /**
     * 续保标识，1代表续保，0代表非续保
     */
    public enum IsRenewal {
        Renewal("1"),
        NonRenewal("0");
        public String value;

        IsRenewal(String value) {
            this.value = value;
        }
    }
    
    //计算方式
    public enum CalMethod { 
        Period("1"), //按区间计算
        Day("2"),    //按天计算
        Month("3"),  //按月计算
        Year("4"),   //按年计算
        Rate("5"),   //按比例计算
        Term("6"),   //按短期费率计算
        NewYear("7"), //按年计算新
        YearForPet("8"), //按年计算(宠物)
        Fixed("9"); //固定保费（原613计算方式）
        public String value;

        CalMethod(String value) {
            this.value = value;
        }
    }

         
    /**
     * Home: 613
     */
    public enum SubProduct {
        Personal("593"),//个人意外保险
        Travel("594"),//旅行保险
        FlightDelay("595"),//航班延误保险
        Group("543"),
        EL("304"),
        Home("613"),//家财险
        Pet("614");//AWP宠物险
        public String value;

        SubProduct(String value) {
            this.value = value;
        }
    }
         
    /**
     * 地区映射key
     */
    public enum RegionCode {
        CountryCode("countryCode"),//国家
        ProvinceCode("provinceCode"),//省
        CityCode("cityCode"),//城市
        CityNameZhs("cityNameZhs"),//城市名称
        Postcode("postcode");//邮编
        
        public String value;
        RegionCode(String value) {
            this.value = value;
        }
    }

}

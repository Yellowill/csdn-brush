package com.allianz.cn.pc.ant.services;


import com.allianz.cn.pc.ant.dto.AntTransDto;
import com.allianz.cn.pc.ant.dto.BillDto;
import com.allianz.cn.pc.ant.dto.GroupPlanInfoDto;
import com.allianz.cn.pc.ant.dto.HolderDto;
import com.allianz.cn.pc.ant.dto.InsuredDto;
import com.allianz.cn.pc.ant.dto.OrderDto;
import com.allianz.cn.pc.ant.dto.PlanInfoDto;

import com.allianz.cn.pc.ant.vo.PolicyInfoVo;

import com.allianz.cn.pc.common.model.bean.InterfaceLogBean;
import com.allianz.oti.common.util.vo.QueryResultBean;
import com.allianz.oti.model.dto.commonsearch.endorsement.EndorsementInfo;

import com.allianz.oti.model.thirdparty.vo.ResponseBigObject;

import java.math.BigDecimal;

import java.sql.SQLException;

import java.util.Date;
import java.util.List;
import java.util.Map;


public interface AntService {
    
    public void saveTrans(AntTransDto dto) throws Exception;;
    
    public boolean isDuplicateRequestId(String reqId) throws Exception;;
    
    public OrderDto findOrder(String order_no) throws Exception;;
    
    public BillDto findBill(String order_no, String payFlowId) throws Exception;
    
    public PlanInfoDto findPlanInfoByPlanCode(String planCode,Date effetiveDate) throws Exception;;
    
    public void beginTransaction() throws Exception;
    
    public void endTransaction();
    
    public void saveOrder(OrderDto orderDto) throws Exception;

    public void saveHolder(HolderDto holderDto) throws Exception;

    public void saveInsured(InsuredDto insuredDto) throws Exception;
    
    public void saveBill(BillDto billDto) throws Exception;
    
    public Integer issue(String order_no) throws Exception;
    
    public Integer doSettlement(Integer contractId) throws Exception;
    
    public void updateOrder(OrderDto orderDto) throws Exception;
    
    public void updateBill(BillDto billDto) throws Exception;
    
    public void updateTrans(AntTransDto trans) throws Exception;
    
    public BigDecimal getPlanPremium(String planCode, Date effectstarttime, Date effectendtime, Integer period, String insuredType)throws Exception;
    
    public BigDecimal getPlanSumInsured(String planCode)throws Exception;
    
    public String getPlanCodeFromMapping(String productCode, String sex, Integer age);
    
    public void updateWarningMail(String summary,String detail);
    
    public String getHolderMobile(String order_no);
    
    public String getPolicyNo(String order_no);
    
    public void addSmsSchedule(String holderMobile,String modelContent);
    
    public boolean personInBlacklist(Long idType, String idNo, String name);
    
    public void updateHolder(String order_no, String extendInfos, String phone) throws Exception;
    
    public PolicyInfoVo getPolicyInfoByPolicyNo(String policyNo);
    
    public boolean openRenewal();
    
    public String getOldContractStatus(Integer contractId);
    
    public boolean validateRiskCustomer(OrderDto orderDto, InsuredDto insuredDto, Integer oldContractId);
    
    public String getRegionLimit(String planCode);
    
    public Map<String, String> getRegionCodeMap(String addressCode) throws Exception;
    
    public Integer issueHome(String order_no) throws Exception;
    
    public OrderDto findOrderByOrderNo(String order_no) throws Exception;
    
    public HolderDto findHolderByOrderNo(String order_no) throws Exception;
    
    public List<InsuredDto> findInsuredListByOrderNo(String order_no) throws Exception;
    
    public boolean isHomePlan(String planCode, Date effetiveDate);
    
    public boolean overLimitTimes(String outProductCode, String holderCertno);
    
    public String getOTIInsuredType(String planCode, int age, Date effStartDate);
    
    public boolean checkPlanAssignment(int planId, String planCode, Date effStartDate);
    
    public boolean isCheckOTIPremium(boolean isRenewalFlag);
    
    public boolean isCheckOTIPremiumWhiteList(String planCode);
    
    public GroupPlanInfoDto getGroupPlanInfo(String groupPlanCode);
    
    public String validateCommonLimit(OrderDto orderDto, HolderDto holderDto, List<InsuredDto> insuredDtoList, PlanInfoDto planinfo);
    
    public void updateErrorMsgToOrder(String order_no, String errorMg);

    public Integer getNewPolicyStatus(String policyRef);
    
    public String getConfigValueByKey(String appname,String key);
    
    public BigDecimal getCancelFee(String cancleOrderNo,Date EndorseTime);
    
    public Object endorsementCancellation(EndorsementInfo info) throws Exception;
    
    public Integer getContractIdByPolicyRef(String policyRef);
    
    public Integer getInstallmentNo(String contractId);
    
    public List<ResponseBigObject> getinstallList(String contractId, Integer install_No) throws Exception;
    
    public Integer settlementForPolicyCancel(Integer contractId,Integer installmentNo,BigDecimal amount,String currency ,String bankCode,String transType) throws Exception;
    
    public Date getPolicyStartDate(String policyRef) throws Exception;
    
    public Date getPolicyEndDate(String policyRef);
    
    public QueryResultBean getMailInfo(String mailKey);
    
    public void saveOrderForCancel(OrderDto orderDto) throws Exception;
    
    public Object fetchResult(String sql, Object... args) throws Exception;
    
    public void commonSaveLog(InterfaceLogBean logBean)throws Exception;
    
    public void saveInterfaceLog(InterfaceLogBean logBean) throws Exception;
    
    public Map<String, Object> underWriteByAPI(OrderDto orderDto,HolderDto holderDto,List<InsuredDto> insuredDtoList);
}

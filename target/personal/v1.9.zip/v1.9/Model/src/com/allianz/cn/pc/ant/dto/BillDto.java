package com.allianz.cn.pc.ant.dto;

import java.math.BigDecimal;

import java.util.Date;


/**
 * prl_ant_inf_order_bill POJO
 * Sat Apr 30 18:01:38 CST 2016
 */ 


public class BillDto{
	private String order_no;
	private Integer merchantaccounttype;
	private String merchantaccountid;
	private Integer otheraccounttype;
	private String otheraccountid;
	private Date paytime;
	private String payflowid;
	private BigDecimal fee;
        private BigDecimal discountFee;


    public void setOrder_no(String order_no) {
        this.order_no = order_no;
    }

    public String getOrder_no() {
        return order_no;
    }

    public void setMerchantaccounttype(Integer merchantaccounttype) {
        this.merchantaccounttype = merchantaccounttype;
    }

    public Integer getMerchantaccounttype() {
        return merchantaccounttype;
    }

    public void setMerchantaccountid(String merchantaccountid) {
        this.merchantaccountid = merchantaccountid;
    }

    public String getMerchantaccountid() {
        return merchantaccountid;
    }

    public void setOtheraccounttype(Integer otheraccounttype) {
        this.otheraccounttype = otheraccounttype;
    }

    public Integer getOtheraccounttype() {
        return otheraccounttype;
    }

    public void setOtheraccountid(String otheraccountid) {
        this.otheraccountid = otheraccountid;
    }

    public String getOtheraccountid() {
        return otheraccountid;
    }

    public void setPaytime(Date paytime) {
        this.paytime = paytime;
    }

    public Date getPaytime() {
        return paytime;
    }

    public void setPayflowid(String payflowid) {
        this.payflowid = payflowid;
    }

    public String getPayflowid() {
        return payflowid;
    }

    public void setFee(BigDecimal fee) {
        this.fee = fee;
    }

    public BigDecimal getFee() {
        return fee;
    }

    public void setDiscountFee(BigDecimal discountFee) {
        this.discountFee = discountFee;
    }

    public BigDecimal getDiscountFee() {
        return discountFee;
    }
}


package com.allianz.cn.pc.ant.vo.standard.requestvo.ehome;

import com.allianz.oti.model.thirdparty.vo.ehome.request.policyconfirm.PolicyConfirmRequestBody;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("Body")
public class EhmoneRequestBody extends PolicyConfirmRequestBody {
    public EhmoneRequestBody() {
        super();
    }
}

package com.allianz.cn.pc.ant.vo;

import java.util.Date;

public class PolicyInfoVo {
    private Integer contractId;
    private String premCalMethod;
    private String planCode;
    private String groupPlanCode;
    private String groupPlanName;
    private String policyStatus;
    private String branchCode;
    private Date effectiveDate;
    private Date expireDate;
    private String lopProdType;
    private String renewableFlag;
    private Integer renewableGracePeriod;
    private String subAccount;
    
    
    public void setContractId(Integer contractId) {
        this.contractId = contractId;
    }

    public Integer getContractId() {
        return contractId;
    }

    public void setPremCalMethod(String premCalMethod) {
        this.premCalMethod = premCalMethod;
    }

    public String getPremCalMethod() {
        return premCalMethod;
    }

    public void setPlanCode(String planCode) {
        this.planCode = planCode;
    }

    public String getPlanCode() {
        return planCode;
    }

    public void setGroupPlanCode(String groupPlanCode) {
        this.groupPlanCode = groupPlanCode;
    }

    public String getGroupPlanCode() {
        return groupPlanCode;
    }

    public void setGroupPlanName(String groupPlanName) {
        this.groupPlanName = groupPlanName;
    }

    public String getGroupPlanName() {
        return groupPlanName;
    }

    public void setPolicyStatus(String policyStatus) {
        this.policyStatus = policyStatus;
    }

    public String getPolicyStatus() {
        return policyStatus;
    }

    public void setBranchCode(String branchCode) {
        this.branchCode = branchCode;
    }

    public String getBranchCode() {
        return branchCode;
    }

    public void setEffectiveDate(Date effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    public Date getEffectiveDate() {
        return effectiveDate;
    }

    public void setExpireDate(Date expireDate) {
        this.expireDate = expireDate;
    }

    public Date getExpireDate() {
        return expireDate;
    }

    public void setLopProdType(String lopProdType) {
        this.lopProdType = lopProdType;
    }

    public String getLopProdType() {
        return lopProdType;
    }

    public void setRenewableFlag(String renewableFlag) {
        this.renewableFlag = renewableFlag;
    }

    public String getRenewableFlag() {
        return renewableFlag;
    }

    public void setRenewableGracePeriod(Integer renewableGracePeriod) {
        this.renewableGracePeriod = renewableGracePeriod;
    }

    public Integer getRenewableGracePeriod() {
        return renewableGracePeriod;
    }

    public void setSubAccount(String subAccount) {
        this.subAccount = subAccount;
    }

    public String getSubAccount() {
        return subAccount;
    }
}

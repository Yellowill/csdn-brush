package com.allianz.cn.pc.ant.vo.standard.requestvo.ehome;

import com.allianz.oti.model.thirdparty.config.XmlConfig;
import com.allianz.oti.model.thirdparty.vo.ehome.RequestHead;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("Packet")
public class EhomeRequestPacket implements java.io.Serializable{
    
    @XmlConfig(require = true,type = Object.class)
    @XStreamAlias("Head")
    private RequestHead requestHead;
    
    @XmlConfig(require = true,type = Object.class)
    @XStreamAlias("Body")
    private EhmoneRequestBody requestBody;


    public void setRequestHead(RequestHead requestHead) {
        this.requestHead = requestHead;
    }

    public RequestHead getRequestHead() {
        return requestHead;
    }

    public void setRequestBody(EhmoneRequestBody requestBody) {
        this.requestBody = requestBody;
    }

    public EhmoneRequestBody getRequestBody() {
        return requestBody;
    }
}

